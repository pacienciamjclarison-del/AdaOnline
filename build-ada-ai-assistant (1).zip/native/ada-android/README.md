# Ada for Android — native notification companion

This is a small Android WebView app for the hosted Ada website. Unlike a PWA, the companion can use Android's `NotificationListenerService` after the device owner explicitly grants **Notification access** in Android Settings.

## Build an installable debug APK

Requirements: Android Studio (or Android SDK), JDK 17, and Gradle 8.11.1 or newer.

From this folder:

```bash
gradle :app:assembleDebug -PADA_WEB_URL=https://YOUR-ADA-SITE.example
```

APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

Install it on your own Android device with:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Or open this folder in Android Studio and build `app` > `assembleDebug`. Replace the URL with the Ada site you control; do not install an APK built against an unknown site.

## Build without installing Android Studio on your own computer

The repository contains `.github/workflows/build-android.yml`. Push the project to a private GitHub repository, open **Actions → Build Ada Android APK → Run workflow**, and enter the HTTPS URL of your Ada deployment. GitHub Actions builds `app-debug.apk` and attaches it as a downloadable workflow artifact. Never put an API key in the app URL or GitHub workflow.

## Notification privacy and controls

1. Open the installed Ada Android app.
2. In Ada Settings, choose **Review notifications** or **Automatic reactions**. The default is **Off**.
3. Tap **Open Android Notification Access Settings** and explicitly enable Ada.
4. Return to Ada. Review mode previews notices and waits for your tap. Automatic mode sends eligible notification text to Ada's currently selected AI provider; alerts classified as OTP/security, bank/payment, or health/medical still require review.
5. Turn the setting back to **Off** to stop monitoring and clear the app's pending local queue. Revoke the Android permission at any time in system settings.

The Android service uses a short-lived, on-device queue (up to 20 notices, up to 30 minutes). It does not upload, log, or persist notification text in a server database. When you choose React (or enable Automatic reactions), the notification text is sent to your chosen AI provider for that response. Ada does not automatically open links or execute commands from notification text.

## Platform limits

- Android's operating system requires the user to grant Notification Access. This permission can expose notification text from multiple apps; keep the Ada in-app mode Off unless you want the companion to monitor.
- Android may stop background services or delay delivery to the open WebView because of battery restrictions.
- This native listener does not work on iPhone. iOS does not let third-party apps read other apps' notification tray; copy/share text to Ada instead.
- The hosted Next.js site still needs a reachable internet connection for cloud weather/news and cloud AI. The notification queue itself is on-device.
