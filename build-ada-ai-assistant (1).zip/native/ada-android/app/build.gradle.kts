plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val adaWebUrl = providers.gradleProperty("ADA_WEB_URL")
    .orElse(providers.environmentVariable("ADA_WEB_URL"))
    .orElse("https://ada.example.com")
    .get()
    .trimEnd('/')
val escapedAdaWebUrl = adaWebUrl.replace("\\", "\\\\").replace("\"", "\\\"")

android {
    namespace = "app.ada.android"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.ada.android"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
        buildConfigField("String", "ADA_WEB_URL", "\"$escapedAdaWebUrl\"")
    }

    buildFeatures {
        buildConfig = true
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
