package app.ada.android

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.webkit.JavascriptInterface

/** Narrow bridge exposed only inside the trusted Ada WebView. */
class AdaBridge(private val appContext: Context) {
    @JavascriptInterface
    fun version(): String = "1"

    @JavascriptInterface
    fun isNotificationListenerEnabled(): Boolean = NotificationAccess.isGranted(appContext)

    @JavascriptInterface
    fun isNotificationMonitoringEnabled(): Boolean = NotificationAccess.isMonitoringEnabled(appContext)

    @JavascriptInterface
    fun openNotificationAccessSettings(): Boolean {
        return try {
            val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            appContext.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }

    /** Monitoring only starts when both the explicit in-app toggle and Android permission are on. */
    @JavascriptInterface
    fun setNotificationMonitoringEnabled(enabled: Boolean): Boolean {
        val allowed = enabled && NotificationAccess.isGranted(appContext)
        appContext.getSharedPreferences("ada_notification_consent", Context.MODE_PRIVATE)
            .edit()
            .putBoolean("enabled", allowed)
            .apply()
        if (!allowed) AdaNotificationBuffer.clear(appContext)
        return allowed
    }

    @JavascriptInterface
    fun takeNextNotification(): String {
        if (!NotificationAccess.isGranted(appContext) || !NotificationAccess.isMonitoringEnabled(appContext)) {
            return "null"
        }
        return AdaNotificationBuffer.takeNext(appContext)
    }

    @JavascriptInterface
    fun clearPendingNotifications() {
        AdaNotificationBuffer.clear(appContext)
    }
}
