package app.ada.android

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Short-lived local queue. Notification text is never uploaded by this class. */
object AdaNotificationBuffer {
    private const val PREFS = "ada_notification_queue"
    private const val QUEUE_KEY = "queue"
    private const val MAX_ITEMS = 20
    private const val MAX_AGE_MS = 30L * 60L * 1000L

    @Synchronized
    fun enqueue(context: Context, item: JSONObject) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val key = item.optString("dedupeKey")
        val retained = mutableListOf<JSONObject>()
        val existing = try {
            JSONArray(prefs.getString(QUEUE_KEY, "[]") ?: "[]")
        } catch (_: Exception) {
            JSONArray()
        }

        for (i in 0 until existing.length()) {
            val old = existing.optJSONObject(i) ?: continue
            if (now - old.optLong("postedAt", 0L) > MAX_AGE_MS) continue
            if (key.isNotEmpty() && old.optString("dedupeKey") == key) return
            retained.add(old)
        }

        retained.add(item)
        while (retained.size > MAX_ITEMS) retained.removeAt(0)
        val result = JSONArray()
        retained.forEach { value -> result.put(value) }
        prefs.edit().putString(QUEUE_KEY, result.toString()).commit()
    }

    @Synchronized
    fun takeNext(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val existing = try {
            JSONArray(prefs.getString(QUEUE_KEY, "[]") ?: "[]")
        } catch (_: Exception) {
            JSONArray()
        }
        val retained = mutableListOf<JSONObject>()
        var next: JSONObject? = null
        for (i in 0 until existing.length()) {
            val item = existing.optJSONObject(i) ?: continue
            if (now - item.optLong("postedAt", 0L) > MAX_AGE_MS) continue
            if (next == null) next = item else retained.add(item)
        }
        val result = JSONArray()
        retained.forEach { value -> result.put(value) }
        prefs.edit().putString(QUEUE_KEY, result.toString()).commit()
        return next?.toString() ?: "null"
    }

    @Synchronized
    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(QUEUE_KEY, "[]")
            .commit()
    }
}
