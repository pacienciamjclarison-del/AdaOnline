package app.ada.android

import android.content.ComponentName
import android.content.Context
import android.provider.Settings

object NotificationAccess {
    fun isGranted(context: Context): Boolean {
        val enabled = Settings.Secure.getString(
            context.contentResolver,
            "enabled_notification_listeners"
        ) ?: return false
        return enabled.split(':').any { flattened ->
            ComponentName.unflattenFromString(flattened)?.packageName == context.packageName
        }
    }

    fun isMonitoringEnabled(context: Context): Boolean =
        context.getSharedPreferences("ada_notification_consent", Context.MODE_PRIVATE)
            .getBoolean("enabled", false)
}
