package app.ada.android

import android.app.Notification
import android.content.pm.PackageManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONObject

/**
 * Android invokes this service only after the device owner grants Notification Access.
 * Ada additionally requires her in-app monitoring switch. Sensitive authentication,
 * banking and health notices are marked review-only in the WebView.
 */
class AdaNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val notice = sbn ?: return
        if (!NotificationAccess.isMonitoringEnabled(this)) return
        if (notice.packageName == packageName || notice.packageName == "android" || notice.packageName == "com.android.systemui") return

        val notification = notice.notification ?: return
        if (notification.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        if (notification.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        val extras = notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim().orEmpty()
        val normalText = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        val lines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
            ?.map { it.toString().trim() }
            ?.filter { it.isNotBlank() }
            ?.joinToString("\n")
            .orEmpty()
        val body = sequenceOf(bigText, normalText, lines).firstOrNull { it.isNotBlank() }.orEmpty()
        if (title.isBlank() && body.isBlank()) return

        val appName = try {
            @Suppress("DEPRECATION")
            val info = packageManager.getApplicationInfo(notice.packageName, 0)
            packageManager.getApplicationLabel(info).toString()
        } catch (_: Exception) {
            notice.packageName
        }

        val sensitiveText = "$title\n$body"
        if (CREDENTIAL_PATTERN.containsMatchIn(sensitiveText)) return
        val needsReview = SENSITIVE_PATTERN.containsMatchIn(sensitiveText)
        val event = JSONObject()
            .put("title", title.take(300))
            .put("text", body.take(1800))
            .put("appName", appName.take(120))
            .put("packageName", notice.packageName.take(180))
            .put("postedAt", System.currentTimeMillis())
            .put("needsReview", needsReview)
            .put("dedupeKey", "${notice.key}:${notice.postTime}")

        // No notification content is logged or sent to the network here.
        AdaNotificationBuffer.enqueue(this, event)
    }

    companion object {
        private val CREDENTIAL_PATTERN = Regex(
            "\\b(otp|one[- ]time password|verification code|authentication code|security code|passcode|password reset|login code|sign[- ]in code)\\b",
            RegexOption.IGNORE_CASE,
        )
        private val SENSITIVE_PATTERN = Regex(
            "\\b(bank|banking|balance|transaction|payment|medical|doctor|hospital|clinic|prescription|medication|diagnosis|test result|health|therapy|mental health)\\b",
            RegexOption.IGNORE_CASE,
        )
    }
}
