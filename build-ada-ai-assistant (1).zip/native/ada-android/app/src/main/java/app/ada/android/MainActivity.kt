package app.ada.android

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val adaUri: Uri by lazy { Uri.parse(BuildConfig.ADA_WEB_URL) }

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 11, 22)
        window.navigationBarColor = Color.rgb(7, 11, 22)
        window.decorView.setBackgroundColor(Color.rgb(7, 11, 22))

        webView = WebView(this).apply {
            setBackgroundColor(Color.rgb(7, 11, 22))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.userAgentString = "${settings.userAgentString} AdaAndroid/1"
            addJavascriptInterface(AdaBridge(applicationContext), "AdaAndroid")
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return true
                    if (uri.scheme == "https" && uri.host.equals(adaUri.host, ignoreCase = true)) return false
                    if (uri.scheme == "http" || uri.scheme == "https" || uri.scheme == "mailto" || uri.scheme == "tel") {
                        try {
                            startActivity(Intent(Intent.ACTION_VIEW, uri))
                        } catch (_: Exception) {
                            // No compatible external activity; keep the Ada shell open.
                        }
                    }
                    return true
                }
            }
        }

        setContentView(
            webView,
            ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT),
        )
        webView.loadUrl(urlForLaunchIntent(intent))
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (::webView.isInitialized) webView.loadUrl(urlForLaunchIntent(intent))
    }

    private fun urlForLaunchIntent(source: Intent?): String {
        if (source?.action != Intent.ACTION_SEND || source.type != "text/plain") return BuildConfig.ADA_WEB_URL
        val subject = source.getStringExtra(Intent.EXTRA_SUBJECT)?.take(500).orEmpty()
        val text = source.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()?.take(6000).orEmpty()
        val sharedUrl = Regex("https?://\\S+", RegexOption.IGNORE_CASE).find(text)?.value?.take(1000).orEmpty()
        return adaUri.buildUpon()
            .appendQueryParameter("share_title", subject)
            .appendQueryParameter("share_text", text)
            .appendQueryParameter("share_url", sharedUrl)
            .build()
            .toString()
    }

    override fun onResume() {
        super.onResume()
        if (::webView.isInitialized) {
            webView.post {
                webView.evaluateJavascript("window.dispatchEvent(new Event('ada-android-resume'));", null)
            }
        }
    }

    @Deprecated("Use system back gesture")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack() && webView.url?.startsWith(BuildConfig.ADA_WEB_URL) == true) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            webView.removeJavascriptInterface("AdaAndroid")
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }
}
