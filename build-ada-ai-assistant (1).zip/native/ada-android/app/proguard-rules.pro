# Keep the JavaScript bridge methods used by the embedded Ada website.
-keepclassmembers class app.ada.android.AdaBridge {
    @android.webkit.JavascriptInterface <methods>;
}
