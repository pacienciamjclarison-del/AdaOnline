"use client";

import { useCallback, useEffect, useRef, useState } from "react";

// Minimal typings for the (still prefixed) Web Speech recognition API.
interface RecAlt {
  transcript: string;
}
interface RecResult {
  isFinal: boolean;
  0: RecAlt;
}
interface RecEvent {
  resultIndex: number;
  results: ArrayLike<RecResult>;
}
interface Recognizer {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: ((e: RecEvent) => void) | null;
  onerror: ((e: { error: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  abort: () => void;
}
type RecCtor = new () => Recognizer;

function getCtor(): RecCtor | null {
  if (typeof window === "undefined") return null;
  const w = window as unknown as { SpeechRecognition?: RecCtor; webkitSpeechRecognition?: RecCtor };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

type Opts = {
  lang: string;
  paused: boolean;
  onFinal: (text: string) => void;
  onInterim: (text: string) => void;
};

/** Continuous speech-to-text that auto-restarts and can be paused while Ada talks. */
export function useRecognition({ lang, paused, onFinal, onInterim }: Opts) {
  const [supported, setSupported] = useState(false);
  const [listening, setListening] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const recRef = useRef<Recognizer | null>(null);
  const activeRef = useRef(false);
  const wantRef = useRef(false);
  const pausedRef = useRef(paused);
  const langRef = useRef(lang);
  const cbRef = useRef({ onFinal, onInterim });
  const restartTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    cbRef.current = { onFinal, onInterim };
  });
  useEffect(() => {
    setSupported(getCtor() !== null);
  }, []);

  const begin = useCallback(() => {
    const Ctor = getCtor();
    if (!Ctor || activeRef.current || !wantRef.current || pausedRef.current) return;
    const rec = new Ctor();
    rec.continuous = true;
    rec.interimResults = true;
    rec.lang = langRef.current;
    rec.onresult = (e) => {
      let interim = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const r = e.results[i];
        const text = r[0].transcript;
        if (r.isFinal) {
          const clean = text.trim();
          if (clean) cbRef.current.onFinal(clean);
          cbRef.current.onInterim("");
        } else {
          interim += text;
        }
      }
      if (interim) cbRef.current.onInterim(interim.trim());
    };
    rec.onerror = (e) => {
      if (e.error === "not-allowed" || e.error === "service-not-allowed") {
        wantRef.current = false;
        setListening(false);
        setError("Microphone permission was blocked. Allow it in your browser's address bar.");
      } else if (e.error === "audio-capture") {
        wantRef.current = false;
        setListening(false);
        setError("No microphone found.");
      } else if (e.error === "network") {
        wantRef.current = false;
        setListening(false);
        setError("Speech recognition needs an internet connection in this browser.");
      }
    };
    rec.onend = () => {
      activeRef.current = false;
      cbRef.current.onInterim("");
      if (wantRef.current && !pausedRef.current) {
        restartTimer.current = setTimeout(begin, 250);
      }
    };
    recRef.current = rec;
    try {
      rec.start();
      activeRef.current = true;
    } catch {
      activeRef.current = false;
    }
  }, []);

  const halt = useCallback(() => {
    if (restartTimer.current) clearTimeout(restartTimer.current);
    const rec = recRef.current;
    if (rec) {
      rec.onend = null;
      try {
        rec.abort();
      } catch {
        /* ignore */
      }
    }
    activeRef.current = false;
    recRef.current = null;
    cbRef.current.onInterim("");
  }, []);

  const start = useCallback(() => {
    setError(null);
    wantRef.current = true;
    setListening(true);
    begin();
  }, [begin]);

  const stop = useCallback(() => {
    wantRef.current = false;
    setListening(false);
    halt();
  }, [halt]);

  useEffect(() => {
    pausedRef.current = paused;
    if (paused) {
      halt();
    } else if (wantRef.current) {
      restartTimer.current = setTimeout(begin, 450);
    }
  }, [paused, begin, halt]);

  useEffect(() => {
    langRef.current = lang;
    if (wantRef.current && !pausedRef.current) {
      halt();
      restartTimer.current = setTimeout(begin, 300);
    }
  }, [lang, begin, halt]);

  useEffect(() => () => halt(), [halt]);

  return { supported, listening, error, start, stop };
}
