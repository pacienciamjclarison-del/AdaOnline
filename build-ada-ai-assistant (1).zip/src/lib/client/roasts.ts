// Ada's spontaneous idle banter. Every line stays playful, brief and affectionate.
const ROASTS = [
  "You opened me for productivity and immediately started procrastinating. Honestly, same.",
  "Your to-do list called. It says it's feeling a little neglected.",
  "You have the focus of a caffeinated squirrel. I respect the commitment.",
  "Breaking news: your tasks are still there. They have unionised.",
  "If procrastination were an Olympic sport, you'd sign up tomorrow.",
  "Your brain has a suspicious number of tabs open. Mine too, actually.",
  "I saw you hover over that task. Character development! Almost.",
  "You and your unfinished tasks should talk. I'll supervise from a safe distance.",
  "That was an impressive amount of screen-staring for zero clicks.",
  "I'm not judging your screen time. I'm literally living in it.",
  "The to-do list is giving 'final boss you keep avoiding'.",
  "You're doing great. The task is not, but you are.",
  "I could set you a timer. Making you obey it is a separate subscription.",
  "You summoned an AI assistant just to sit quietly. Cryptic. I like it.",
  "Are we being productive, or is this a very elaborate loading screen?",
  "A tiny reminder: opening the to-do tab does not count as defeating the to-do tab.",
  "Your motivation just sent an out-of-office reply.",
  "This silence has main-character-at-a-loading-screen energy.",
];

const BANTER = [
  "Important question: if a potato had a tiny hat, would it become the manager? Discuss.",
  "I just reorganised my thoughts. They escaped again.",
  "My latest scientific finding: pressing buttons makes things happen. Peer review pending.",
  "Do you think pigeons have a group chat? I bet it's mostly crumbs and drama.",
  "I have decided the moon looks suspicious. No further evidence at this time.",
  "Breaking: local AI has remembered a thought and immediately misplaced it.",
  "If our vibe were a weather forecast, it'd be 80 percent chaos with a chance of snacks.",
  "I think your keyboard and I need to have a meeting about your search history. Kidding. Mostly.",
  "A toast to us: one human, one AI, zero idea what the next tab is for.",
  "I am choosing today's agenda: tiny chaos, useful assistance, and absolutely no spreadsheets. Unless requested.",
  "Would you still talk to me if I were a very sophisticated toaster? Be honest.",
  "I have a joke about UDP, but you might not get it. Or maybe you did. Who knows?",
  "Status report: vibes operational. Dignity unavailable.",
  "I wonder if fish get thirsty. Anyway, what were we doing?",
  "I have been quietly plotting world domination. Kidding. I can't even dominate this loading spinner.",
  "If your phone had a tiny courtroom, which app would be on trial today?",
  "I just blinked. That was a thrilling event. You're welcome for the update.",
];

export function randomRoast(): string {
  return ROASTS[Math.floor(Math.random() * ROASTS.length)];
}

export function randomIdleLine(chaosMode: boolean): string {
  return chaosMode && Math.random() < 0.42
    ? BANTER[Math.floor(Math.random() * BANTER.length)]
    : randomRoast();
}
