import type { Mood } from "./types";

export type VoiceItem = { text: string; mood?: Mood };
export type VoiceMode = "cloud" | "browser" | "silent";

export type VoiceConfig = {
  mode: VoiceMode;
  cloudVoice: string;
  browserVoiceURI: string;
  rate: number;
  pitch: number;
  volume: number;
};

const MALAY = /\b(?:saya|aku|awak|kamu|tak|tidak|yang|dan|ini|itu|apa|boleh|nak|dengan|untuk|kita|dia|lah|kan|jom|macam|sangat|terima kasih|selamat|tolong|bila|siapa|kenapa|dah|sudah|ada)\b/gi;
const looksMalay = (t: string) => (t.match(MALAY)?.length ?? 0) >= 2;

const FEMALE = /aria|jenny|zira|sonia|michelle|ava\b|emma|samantha|karen|tessa|moira|fiona|victoria|serena|female|libby|natasha|yasmin|susan|hazel|heera|siri|google us english|google uk english female/i;

/**
 * Speaks sentences one after another. Two voices:
 *  - "cloud": neural audio from /api/tts, played through an AnalyserNode so the avatar's
 *    mouth follows the real waveform;
 *  - "browser": the Web Speech API (mouth is driven by a simulated envelope + word boundaries).
 * "silent" keeps the avatar talking (and subtitles flowing) without sound.
 */
export class VoiceEngine {
  cfg: VoiceConfig = {
    mode: "browser",
    cloudVoice: "en-US-AriaNeural",
    browserVoiceURI: "",
    rate: 1.05,
    pitch: 1.15,
    volume: 1,
  };
  onStart?: (item: VoiceItem) => void;
  onIdle?: () => void;

  private queue: VoiceItem[] = [];
  private pumping = false;
  private run = 0;
  private cancelCurrent: (() => void) | null = null;
  private prefetch = new Map<VoiceItem, Promise<AudioBuffer | null>>();
  private cloudFailures = 0;
  cloudBroken = false;

  private ctx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private analyserBuf: Uint8Array<ArrayBuffer> | null = null;
  private levelMode: "none" | "sim" | "analyser" = "none";
  private pulse = 0;

  configure(partial: Partial<VoiceConfig>) {
    this.cfg = { ...this.cfg, ...partial };
  }

  /** Must run inside a user gesture (browsers block audio otherwise). */
  unlock() {
    try {
      const ctx = this.ensureCtx();
      if (ctx.state === "suspended") void ctx.resume();
      if (typeof window !== "undefined" && "speechSynthesis" in window) {
        const u = new SpeechSynthesisUtterance(" ");
        u.volume = 0;
        window.speechSynthesis.speak(u);
      }
    } catch {
      /* ignore */
    }
  }

  private ensureCtx(): AudioContext {
    if (!this.ctx) {
      const Ctor =
        window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new Ctor();
      this.analyser = this.ctx.createAnalyser();
      this.analyser.fftSize = 1024;
      this.analyser.smoothingTimeConstant = 0.25;
      this.analyser.connect(this.ctx.destination);
      this.analyserBuf = new Uint8Array(new ArrayBuffer(this.analyser.fftSize));
    }
    return this.ctx;
  }

  getBrowserVoices(): SpeechSynthesisVoice[] {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return [];
    return window.speechSynthesis.getVoices();
  }

  private pickVoice(text: string): SpeechSynthesisVoice | null {
    const voices = this.getBrowserVoices();
    if (!voices.length) return null;
    const malay = looksMalay(text);
    let best: SpeechSynthesisVoice | null = null;
    let bestScore = -1;
    for (const v of voices) {
      let score = 0;
      if (malay) {
        if (v.lang.toLowerCase().startsWith("ms") || v.lang.toLowerCase().startsWith("id")) score += 60;
      } else {
        if (this.cfg.browserVoiceURI && v.voiceURI === this.cfg.browserVoiceURI) score += 100;
        if (v.lang.toLowerCase().startsWith("en")) score += 10;
        if (/en[-_](us|gb)/i.test(v.lang)) score += 3;
      }
      if (FEMALE.test(v.name)) score += 20;
      if (/online|natural|neural/i.test(v.name)) score += 15;
      if (/google/i.test(v.name)) score += 4;
      if (/male\b/i.test(v.name) && !/female/i.test(v.name)) score -= 30;
      if (score > bestScore) {
        bestScore = score;
        best = v;
      }
    }
    return best;
  }

  /** 0..1 mouth envelope, sampled by the avatar every frame. */
  getLevel(): number {
    if (this.levelMode === "analyser" && this.analyser && this.analyserBuf) {
      this.analyser.getByteTimeDomainData(this.analyserBuf);
      let sum = 0;
      for (let i = 0; i < this.analyserBuf.length; i++) {
        const v = (this.analyserBuf[i] - 128) / 128;
        sum += v * v;
      }
      const rms = Math.sqrt(sum / this.analyserBuf.length);
      return Math.min(1, rms * 5);
    }
    if (this.levelMode === "sim") {
      const t = performance.now() / 1000;
      let v = 0.5 + 0.5 * Math.sin(t * 14) * Math.sin(t * 6.1 + 1.2);
      v = v * 0.75 + this.pulse * 0.35;
      if (Math.sin(t * 2.3) > 0.93) v *= 0.15; // tiny pauses between words
      this.pulse *= 0.88;
      return Math.max(0, Math.min(1, v));
    }
    return 0;
  }

  isBusy() {
    return this.pumping || this.queue.length > 0;
  }

  enqueue(item: VoiceItem) {
    this.queue.push(item);
    if (this.cfg.mode === "cloud" && !this.cloudBroken) this.prefetch.set(item, this.fetchBuffer(item.text));
    void this.pump();
  }

  stop() {
    const wasBusy = this.isBusy();
    this.run++;
    this.pumping = false;
    this.queue = [];
    this.prefetch.clear();
    const cancel = this.cancelCurrent;
    this.cancelCurrent = null;
    cancel?.();
    if (typeof window !== "undefined" && "speechSynthesis" in window) window.speechSynthesis.cancel();
    this.levelMode = "none";
    if (wasBusy) this.onIdle?.();
  }

  private async pump() {
    if (this.pumping) return;
    this.pumping = true;
    const run = ++this.run;
    while (this.queue.length && run === this.run) {
      const item = this.queue.shift()!;
      this.onStart?.(item);
      try {
        if (this.cfg.mode === "silent") await this.saySilent(item);
        else if (this.cfg.mode === "cloud" && !this.cloudBroken) await this.sayCloud(item, run);
        else await this.sayBrowser(item);
      } catch {
        /* keep going with the next sentence */
      }
    }
    if (run === this.run) {
      this.pumping = false;
      this.levelMode = "none";
      this.onIdle?.();
    }
  }

  private saySilent(item: VoiceItem): Promise<void> {
    return new Promise((resolve) => {
      this.levelMode = "sim";
      const timer = setTimeout(done, Math.max(900, item.text.length * 62));
      function done() {
        clearTimeout(timer);
        resolve();
      }
      this.cancelCurrent = done;
    });
  }

  private sayBrowser(item: VoiceItem): Promise<void> {
    return new Promise((resolve) => {
      if (typeof window === "undefined" || !("speechSynthesis" in window)) {
        void this.saySilent(item).then(resolve);
        return;
      }
      const synth = window.speechSynthesis;
      const u = new SpeechSynthesisUtterance(item.text);
      const voice = this.pickVoice(item.text);
      if (voice) {
        u.voice = voice;
        u.lang = voice.lang;
      }
      u.rate = this.cfg.rate;
      u.pitch = this.cfg.pitch;
      u.volume = this.cfg.volume;
      let finished = false;
      const finish = () => {
        if (finished) return;
        finished = true;
        clearTimeout(safety);
        if (this.cancelCurrent === finish) this.cancelCurrent = null;
        resolve();
      };
      const safety = setTimeout(finish, Math.max(2500, (item.text.length * 95) / this.cfg.rate + 3000));
      u.onend = finish;
      u.onerror = finish;
      u.onboundary = () => {
        this.pulse = 1;
      };
      this.levelMode = "sim";
      this.cancelCurrent = finish;
      synth.speak(u);
    });
  }

  private async fetchBuffer(text: string): Promise<AudioBuffer | null> {
    try {
      const res = await fetch("/api/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, voice: this.cfg.cloudVoice }),
      });
      if (!res.ok) throw new Error(String(res.status));
      const data = await res.arrayBuffer();
      const buf = await this.ensureCtx().decodeAudioData(data);
      this.cloudFailures = 0;
      return buf;
    } catch {
      this.cloudFailures++;
      if (this.cloudFailures >= 3) this.cloudBroken = true;
      return null;
    }
  }

  private async sayCloud(item: VoiceItem, run: number): Promise<void> {
    this.levelMode = "none";
    const buf = await (this.prefetch.get(item) ?? this.fetchBuffer(item.text));
    this.prefetch.delete(item);
    if (run !== this.run) return;
    if (!buf) return this.sayBrowser(item);
    const ctx = this.ensureCtx();
    if (ctx.state === "suspended") await ctx.resume().catch(() => undefined);
    return new Promise<void>((resolve) => {
      const src = ctx.createBufferSource();
      src.buffer = buf;
      const gain = ctx.createGain();
      gain.gain.value = this.cfg.volume;
      src.connect(gain);
      gain.connect(this.analyser!);
      let finished = false;
      const finish = () => {
        if (finished) return;
        finished = true;
        try {
          src.stop();
        } catch {
          /* already stopped */
        }
        src.disconnect();
        gain.disconnect();
        if (this.cancelCurrent === finish) this.cancelCurrent = null;
        resolve();
      };
      src.onended = finish;
      this.cancelCurrent = finish;
      this.levelMode = "analyser";
      src.start();
    });
  }

  /** A short three-note chime for timers. */
  chime() {
    try {
      const ctx = this.ensureCtx();
      if (ctx.state === "suspended") void ctx.resume();
      const notes = [880, 1174.66, 1567.98];
      notes.forEach((f, i) => {
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.type = "sine";
        o.frequency.value = f;
        const t0 = ctx.currentTime + i * 0.16;
        g.gain.setValueAtTime(0, t0);
        g.gain.linearRampToValueAtTime(0.25 * this.cfg.volume, t0 + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.5);
        o.connect(g);
        g.connect(ctx.destination);
        o.start(t0);
        o.stop(t0 + 0.55);
      });
    } catch {
      /* ignore */
    }
  }
}
