export type Mood =
  | "neutral"
  | "happy"
  | "excited"
  | "smug"
  | "sad"
  | "surprised"
  | "angry"
  | "thinking"
  | "embarrassed"
  | "sleepy";

export const MOOD_LIST: Mood[] = [
  "neutral",
  "happy",
  "excited",
  "smug",
  "sad",
  "surprised",
  "angry",
  "thinking",
  "embarrassed",
  "sleepy",
];

export const MOOD_EMOJI: Record<Mood, string> = {
  neutral: "😐",
  happy: "😊",
  excited: "🤩",
  smug: "😏",
  sad: "🥺",
  surprised: "😲",
  angry: "😤",
  thinking: "🤔",
  embarrassed: "😳",
  sleepy: "😴",
};

export type Status = "idle" | "listening" | "thinking" | "speaking";

export type ChipLink = { url: string; label: string };

export type ChatMsg = {
  id: string;
  role: "user" | "assistant";
  content: string;
  mood?: Mood;
  links?: ChipLink[];
  pending?: boolean;
  warning?: string;
};

export type TaskItem = { id: number; text: string; done: boolean };
export type NoteItem = { id: number; text: string; createdAt: string };
export type MemoryItem = { id: number; fact: string };
export type TimerItem = { id: string; label: string; endsAt: number; total: number };

export type WeatherData = {
  city: string;
  country: string;
  tempC: number;
  feelsC: number;
  humidity: number;
  windKph: number;
  condition: string;
  icon: string;
  highC: number;
  lowC: number;
  rainChance: number;
};

export type ServerStatus = {
  brain: string;
  model: string;
  free: boolean;
  tts: "elevenlabs" | "openai" | "edge";
  edgeVoices: { id: string; label: string }[];
};

export type FreeProviderInfo = {
  id: string;
  name: string;
  badge: string;
  desc: string;
  getKeyUrl: string;
  defaultModel: string;
  models: { id: string; label: string }[];
  keyPlaceholder: string;
};

export const FREE_PROVIDERS: FreeProviderInfo[] = [
  {
    id: "groq",
    name: "Groq Cloud",
    badge: "⚡ Free developer limits",
    desc: "Fast inference with a free developer tier. Free quotas and model availability are set by Groq and can change.",
    getKeyUrl: "https://console.groq.com/keys",
    defaultModel: "openai/gpt-oss-20b",
    models: [
      { id: "openai/gpt-oss-20b", label: "GPT-OSS 20B (fast, recommended)" },
      { id: "openai/gpt-oss-120b", label: "GPT-OSS 120B (stronger)" },
    ],
    keyPlaceholder: "gsk_...",
  },
  {
    id: "gemini",
    name: "Google AI Studio",
    badge: "🧠 Free tier available",
    desc: "Gemini API has a free tier for eligible models. Quotas depend on model, region and project.",
    getKeyUrl: "https://aistudio.google.com/apikey",
    defaultModel: "gemini-2.5-flash",
    models: [
      { id: "gemini-2.5-flash", label: "Gemini 2.5 Flash (recommended)" },
      { id: "gemini-2.5-flash-lite", label: "Gemini 2.5 Flash-Lite (fast, economical)" },
    ],
    keyPlaceholder: "AIzaSy...",
  },
  {
    id: "openrouter",
    name: "OpenRouter Free",
    badge: "🌐 Auto-picks a free model",
    desc: "The official free router selects from currently available free models. Free models have shared rate limits and availability can vary.",
    getKeyUrl: "https://openrouter.ai/keys",
    defaultModel: "openrouter/free",
    models: [{ id: "openrouter/free", label: "OpenRouter Free Router (recommended)" }],
    keyPlaceholder: "sk-or-v1-...",
  },
  {
    id: "huggingface",
    name: "Hugging Face Inference",
    badge: "🤗 Free credits may apply",
    desc: "Uses Hugging Face's current Inference Providers router. Free credits/availability depend on your account and selected provider.",
    getKeyUrl: "https://huggingface.co/settings/tokens",
    defaultModel: "openai/gpt-oss-120b:fastest",
    models: [
      { id: "openai/gpt-oss-120b:fastest", label: "GPT-OSS 120B · fastest available provider" },
      { id: "deepseek-ai/DeepSeek-R1:fastest", label: "DeepSeek R1 · fastest available provider" },
    ],
    keyPlaceholder: "hf_...",
  },
  {
    id: "ollama",
    name: "Ollama (Local / Offline)",
    badge: "💻 100% Offline & Free",
    desc: "Run open source models locally on your computer with zero internet required.",
    getKeyUrl: "https://ollama.com",
    defaultModel: "llama3.2",
    models: [
      { id: "llama3.2", label: "Llama 3.2 (Local)" },
      { id: "qwen2.5", label: "Qwen 2.5 (Local)" },
      { id: "mistral", label: "Mistral (Local)" },
      { id: "deepseek-r1:1.5b", label: "DeepSeek R1 1.5B (Local)" },
    ],
    keyPlaceholder: "(No key needed for Ollama)",
  },
  {
    id: "openai",
    name: "OpenAI API (Paid)",
    badge: "💳 Usage billed",
    desc: "OpenAI bills API usage. This provider is not a free tier.",
    getKeyUrl: "https://platform.openai.com/api-keys",
    defaultModel: "gpt-4o-mini",
    models: [
      { id: "gpt-4o-mini", label: "GPT-4o Mini" },
      { id: "gpt-4o", label: "GPT-4o" },
    ],
    keyPlaceholder: "sk-...",
  },
  {
    id: "deepseek",
    name: "DeepSeek API (Paid)",
    badge: "💳 Usage billed",
    desc: "DeepSeek API usage may be billed. This is not a free tier.",
    getKeyUrl: "https://platform.deepseek.com",
    defaultModel: "deepseek-chat",
    models: [
      { id: "deepseek-chat", label: "DeepSeek-V3" },
      { id: "deepseek-reasoner", label: "DeepSeek-R1" },
    ],
    keyPlaceholder: "sk-...",
  },
  {
    id: "custom",
    name: "Custom OpenAI-Compatible",
    badge: "⚙️ Custom Endpoint",
    desc: "Connect to any OpenAI-compatible server or proxy.",
    getKeyUrl: "",
    defaultModel: "gpt-4o-mini",
    models: [],
    keyPlaceholder: "API key or token",
  },
];

export type Settings = {
  autoSpeak: boolean;
  engine: "auto" | "cloud" | "browser";
  cloudVoice: string;
  browserVoiceURI: string;
  rate: number;
  pitch: number;
  volume: number;
  sttLang: string;
  wakeWord: boolean;
  subtitles: boolean;
  city: string;
  customApiKey?: string;
  customApiKeys?: Record<string, string>;
  customProvider?: string;
  customModel?: string;
  customBaseUrl?: string;
  randomRoasts: boolean;
  chaosMode: boolean;
  notificationMode: "off" | "review" | "automatic";
};

export const DEFAULT_SETTINGS: Settings = {
  autoSpeak: true,
  engine: "auto",
  cloudVoice: "en-US-AriaNeural",
  browserVoiceURI: "",
  rate: 1.05,
  pitch: 1.15,
  volume: 1,
  sttLang: "en-US",
  wakeWord: false,
  subtitles: true,
  city: "Kuala Lumpur",
  customApiKey: "",
  customProvider: "groq",
  customModel: "openai/gpt-oss-20b",
  customBaseUrl: "",
  customApiKeys: {},
  randomRoasts: true,
  chaosMode: true,
  notificationMode: "off",
};

/** Migrate saved settings when providers retire models or change endpoints. */
export function normalizeSettings(saved: Partial<Settings>): Settings {
  const settings: Settings = { ...DEFAULT_SETTINGS, ...saved };
  const keys = { ...(saved.customApiKeys ?? {}) };
  const oldProvider = saved.customProvider || DEFAULT_SETTINGS.customProvider || "groq";

  if (saved.customApiKey && !keys[oldProvider]) keys[oldProvider] = saved.customApiKey;

  if (oldProvider === "github") {
    // GitHub Models shut down; do not send its old token to another provider.
    settings.customProvider = "groq";
    settings.customModel = "openai/gpt-oss-20b";
    settings.customApiKey = "";
  } else {
    settings.customProvider = oldProvider;
    let model = settings.customModel || "";
    if (oldProvider === "groq" && /^(?:llama-|gemma|mixtral|qwen-|deepseek-r1)/i.test(model)) {
      model = "openai/gpt-oss-20b";
    } else if (oldProvider === "gemini" && /^(?:gemini-2\.0|gemini-1\.5)/i.test(model)) {
      model = "gemini-2.5-flash";
    } else if (oldProvider === "openrouter" && model !== "openrouter/free") {
      model = "openrouter/free";
    } else if (oldProvider === "huggingface" && /^(?:Qwen\/Qwen2\.5|meta-llama\/Llama-3\.2|mistralai\/Mistral-7B)/i.test(model)) {
      model = "openai/gpt-oss-120b:fastest";
    }
    settings.customModel = model;
    settings.customApiKey = keys[oldProvider] ?? settings.customApiKey ?? "";
  }

  settings.customApiKeys = keys;
  settings.chaosMode = saved.chaosMode ?? saved.randomRoasts ?? true;
  settings.randomRoasts = saved.randomRoasts ?? settings.chaosMode;
  const mode = saved.notificationMode;
  settings.notificationMode = mode === "review" || mode === "automatic" || mode === "off" ? mode : "off";
  return settings;
}

export const uidGen = () =>
  typeof crypto !== "undefined" && "randomUUID" in crypto
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(16).slice(2)}`;

/** Splits streamed text into speakable sentences. Terminators need trailing whitespace. */
export function splitSentences(buf: string, flush: boolean): { out: string[]; rest: string } {
  const out: string[] = [];
  let start = 0;
  const re = /[.!?…]+["'”)\]]*\s+|\n+/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(buf))) {
    const end = m.index + m[0].length;
    const piece = buf.slice(start, end).trim();
    if (piece.length >= 12) {
      out.push(piece);
      start = end;
    }
  }
  let rest = buf.slice(start);
  if (flush && rest.trim()) {
    out.push(rest.trim());
    rest = "";
  }
  return { out, rest };
}

/** Cleans text so it is pleasant to read aloud. */
export function speakable(s: string): string {
  return s
    .replace(/https?:\/\/\S+/g, "link")
    .replace(/\p{Extended_Pictographic}/gu, "")
    .replace(/[*_`#>~]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}
