// Incremental parser for the LLM token stream. The model is asked to embed tiny control
// tags like [mood:happy] and [remember: user likes teh tarik]. Tags can be split across
// chunks, so we hold back anything that might be an unfinished tag.

export type ParsedEvent =
  | { t: "text"; v: string }
  | { t: "mood"; v: string }
  | { t: "remember"; v: string };

export const MOODS = [
  "neutral",
  "happy",
  "excited",
  "smug",
  "sad",
  "surprised",
  "angry",
  "thinking",
  "embarrassed",
  "sleepy",
] as const;

export type Mood = (typeof MOODS)[number];

const TAG = /^\[\s*(mood|remember)\s*:\s*([^\]]*)\]$/i;

/** Strips markdown noise and emoji so text reads (and speaks) naturally. */
export function cleanText(s: string): string {
  return s
    .replace(/\p{Extended_Pictographic}/gu, "")
    .replace(/[\u200d\ufe0f]/g, "")
    .replace(/\*+/g, "")
    .replace(/`+/g, "")
    .replace(/^#{1,6}\s+/gm, "");
}

export class TagParser {
  private buf = "";
  private started = false;

  private emitText(text: string, out: ParsedEvent[]) {
    let v = cleanText(text);
    if (!this.started) {
      v = v.replace(/^\s+/, "");
      if (!v) return;
      this.started = true;
    }
    if (v) out.push({ t: "text", v });
  }

  push(chunk: string): ParsedEvent[] {
    const out: ParsedEvent[] = [];
    this.buf += chunk;
    for (;;) {
      const open = this.buf.indexOf("[");
      if (open === -1) {
        this.emitText(this.buf, out);
        this.buf = "";
        break;
      }
      if (open > 0) {
        this.emitText(this.buf.slice(0, open), out);
        this.buf = this.buf.slice(open);
      }
      const close = this.buf.indexOf("]");
      if (close === -1) {
        if (this.buf.length > 240) {
          this.emitText(this.buf.slice(0, 1), out);
          this.buf = this.buf.slice(1);
          continue;
        }
        break; // wait for more data
      }
      const tag = this.buf.slice(0, close + 1);
      this.buf = this.buf.slice(close + 1);
      const m = tag.match(TAG);
      if (m) {
        const kind = m[1].toLowerCase();
        const value = m[2].trim();
        if (kind === "mood") {
          const mood = value.toLowerCase();
          if ((MOODS as readonly string[]).includes(mood)) out.push({ t: "mood", v: mood });
        } else if (value) {
          out.push({ t: "remember", v: value });
        }
      } else {
        this.emitText(tag, out);
      }
    }
    return out;
  }

  flush(): ParsedEvent[] {
    const out: ParsedEvent[] = [];
    if (this.buf) this.emitText(this.buf, out);
    this.buf = "";
    return out;
  }
}
