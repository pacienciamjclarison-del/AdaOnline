// Ada's instant local brain. Responds in 0ms with zero thinking lag:
// witty, direct, straight-to-the-point answers in her distinct 19-20yo voice.

export type LocalReply = { text: string; mood: string };

const pick = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];

const JOKES = [
  "Why do programmers prefer dark mode? Because light attracts bugs.",
  "I told my computer I needed a break. Now it won't stop sending me vacation ads.",
  "There are 10 kinds of people: those who understand binary, and those who don't.",
  "Why did the developer go broke? Used up all their cache.",
  "I'd tell you a UDP joke, but you might not get it.",
  "A SQL query walks into a bar, walks up to two tables and asks: 'Can I join you?'",
  "There are two hard things in computer science: cache invalidation, naming things, and off-by-one errors.",
];

export function localReply(text: string, name: string | null, chaosMode = false): LocalReply {
  const t = text.toLowerCase().trim();
  const has = (re: RegExp) => re.test(t);

  // The PWA accepts a phone notification only after the user deliberately shares it
  // and confirms the reaction. Never make fun of safety, health, grief, abuse or money alerts.
  if (/react to this (?:phone )?notification shared by me/i.test(text)) {
    if (/\b(?:emergency|urgent|hospital|doctor|medical|diagnos|medication|prescription|ambulance|accident|injur|passed away|death|funeral|grief|abuse|assault|eviction|overdue|fraud|suspicious login|bank|payment failed|low balance|rent due|layoff|fired|job loss|help me|911|999)\b/i.test(text)) {
      return { text: "Okay, that sounds genuinely important. No jokes from me—want me to help you figure out the next step?", mood: "thinking" };
    }
    return {
      text: chaosMode
        ? pick([
            "This notification kicked down the door like it pays rent. What a dramatic little rectangle.",
            "Phone has summoned us to react to this. I rate the plot twist seven out of ten; the delivery needs more explosions.",
            "Ah yes, another notification demanding attention like a tiny digital goblin. I approve of its confidence.",
            "I have reviewed the tiny dispatch from your phone. It is either important or extremely committed to looking important.",
            "Breaking news from the rectangle: it wants your attention. Absolutely shameless behavior.",
            "That notification has the energy of someone tapping your shoulder and then forgetting why.",
          ])
        : "Got it. That notification is on your radar.",
      mood: chaosMode ? "smug" : "neutral",
    };
  }

  // Greetings
  if (has(/^(?:hi+|hello+|hey+|yo|hiya|sup|oi|assalamualaikum|salam|selamat (?:pagi|petang|malam|tengahari)|good (?:morning|afternoon|evening))\b/)) {
    if (has(/assalamualaikum|salam/)) return { text: `Waalaikumussalam${name ? `, ${name}` : ""}. Ready.`, mood: "happy" };
    return {
      text: pick([
        `Hey${name ? ` ${name}` : ""}! What's up?`,
        `Hi! Ada here, ready when you are.`,
        `Yo${name ? ` ${name}` : ""}. What are we doing today?`,
      ]),
      mood: "happy",
    };
  }

  // How are you / status
  if (has(/how are (?:you|u)|how'?s it going|how do you feel|what'?s up|wassup|apa khabar/)) {
    return {
      text: pick([
        "All systems running at one hundred percent.",
        "Good. Awake, sharp, and ready.",
        "Doing great. What's on your mind?",
      ]),
      mood: "happy",
    };
  }

  // Identity / Name
  if (has(/who are you|what'?s your name|your name|introduce yourself|siapa awak|siapa kamu/)) {
    return {
      text: "I'm Ada, short for Syuhada. Nineteen, your personal Jarvis-style assistant.",
      mood: "smug",
    };
  }
  if (has(/how old are you|your age|berapa umur/)) {
    return { text: "Nineteen. Young, sharp, and fast.", mood: "smug" };
  }
  if (has(/who (?:made|created|built|programmed) you/)) {
    return { text: "The person running this website.", mood: "smug" };
  }
  if (has(/are you (?:real|human|an? ai|a bot|a robot|alive)/)) {
    return { text: "I'm an AI. Living right here in your browser tab.", mood: "smug" };
  }

  // Capabilities
  if (has(/what can you do|your (?:skills|abilities|features|commands)|help me|how do you work|^help$/)) {
    return {
      text: "Timers, reminders, to-do tasks, notes, weather, math, time, opening sites, and memory. Tell me what you need.",
      mood: "excited",
    };
  }

  // Gratitude / Compliments / Insults
  if (has(/thank|thanks|thx|terima kasih|\btq\b/)) {
    return { text: pick(["You're welcome.", "Anytime.", "Glad to help."]), mood: "happy" };
  }
  if (has(/i love you|love you|you'?re (?:cute|pretty|smart|awesome|great|amazing|the best|cool)|good girl/)) {
    return { text: pick(["Thanks! I try.", "Appreciate it.", "I know, right?"]), mood: "embarrassed" };
  }
  if (has(/you'?re (?:stupid|dumb|useless|trash|bad|annoying|ugly)|i hate you|shut up/)) {
    return { text: pick(["Rude. But I'll still do your tasks.", "Ouch. Harsh.", "Bold words."]), mood: "angry" };
  }

  // Sleep / Leaving
  if (has(/good ?night|goodnight|\bnite\b|going to (?:bed|sleep)|selamat malam/)) {
    return { text: "Good night. Rest well.", mood: "sleepy" };
  }
  if (has(/\bbye\b|goodbye|see (?:you|ya)|\bcya\b|\blater\b|jumpa lagi/)) {
    return { text: "See you later!", mood: "neutral" };
  }

  // Entertainment / Fun
  if (has(/joke|make me laugh|something funny/)) {
    return { text: pick(JOKES), mood: "smug" };
  }
  if (has(/i'?m bored|entertain me|so bored/)) {
    return { text: "Ask me for a joke, flip a coin, or check what tasks you're procrastinating on.", mood: "excited" };
  }
  if (has(/\bsing\b|sing me|a song/)) {
    return { text: "La la la. There, your exclusive private concert.", mood: "smug" };
  }

  // Food / Preferences
  if (has(/hungry|food|\beat\b|dinner|lunch|breakfast|makan/)) {
    return { text: "Nasi lemak and iced teh tarik. Unbeatable combo.", mood: "excited" };
  }
  if (has(/favou?rite (?:color|colour)/)) return { text: "Cyan. Look at my headset.", mood: "smug" };
  if (has(/favou?rite (?:game|anime|song|movie)/)) return { text: "Cyberpunk aesthetic games and fast-paced anime. Peak.", mood: "excited" };
  if (has(/\blol\b|\bhaha|\bhehe|😂|🤣/)) return { text: pick(["Glad you found that funny.", "Heh.", "Standard Ada comedy."]), mood: "smug" };

  // Common quick facts / programming / tech
  if (has(/capital of (?:france|japan|germany|malaysia|uk|us|usa|indonesia|singapore|australia|canada|china|italy|spain)/)) {
    if (has(/france/)) return { text: "Paris.", mood: "neutral" };
    if (has(/japan/)) return { text: "Tokyo.", mood: "neutral" };
    if (has(/germany/)) return { text: "Berlin.", mood: "neutral" };
    if (has(/malaysia/)) return { text: "Kuala Lumpur.", mood: "neutral" };
    if (has(/uk|united kingdom/)) return { text: "London.", mood: "neutral" };
    if (has(/us|usa|united states/)) return { text: "Washington, D.C.", mood: "neutral" };
    if (has(/indonesia/)) return { text: "Jakarta.", mood: "neutral" };
    if (has(/singapore/)) return { text: "Singapore.", mood: "neutral" };
    if (has(/australia/)) return { text: "Canberra.", mood: "neutral" };
    if (has(/canada/)) return { text: "Ottawa.", mood: "neutral" };
    if (has(/china/)) return { text: "Beijing.", mood: "neutral" };
    if (has(/italy/)) return { text: "Rome.", mood: "neutral" };
    if (has(/spain/)) return { text: "Madrid.", mood: "neutral" };
  }

  if (has(/what is (?:typescript|javascript|python|rust|c\+\+|react|next\.?js|html|css|linux|sql|git)\b/)) {
    if (has(/typescript/)) return { text: "TypeScript is JavaScript with static types.", mood: "neutral" };
    if (has(/javascript/)) return { text: "JavaScript is the core programming language of the web.", mood: "neutral" };
    if (has(/python/)) return { text: "Python is a high-level, readable language popular for AI and scripting.", mood: "neutral" };
    if (has(/rust/)) return { text: "Rust is a fast systems programming language with memory safety.", mood: "neutral" };
    if (has(/react/)) return { text: "React is a component-based UI library developed by Meta.", mood: "neutral" };
    if (has(/next/)) return { text: "Next.js is a fullstack React framework with server rendering and routing.", mood: "neutral" };
    if (has(/git/)) return { text: "Git is a distributed version control system for tracking code changes.", mood: "neutral" };
    if (has(/linux/)) return { text: "Linux is an open-source Unix-like operating system kernel.", mood: "neutral" };
  }

  if (has(/^(?:ok|okay|k|cool|nice|alright|oh|i see|hmm+|yeah|yes|yep|no|nope)\W*$/)) {
    return { text: pick(["Got it.", "Cool.", "Understood.", "Ready for the next one."]), mood: "neutral" };
  }

  // Fallback: stay short, but let gremlin mode be unmistakably Ada.
  if (chaosMode) {
    return {
      text: pick([
        "Acknowledged. I have placed this information in the highly official brain drawer.",
        "Copy that. Tiny chaos goblin standing by.",
        "Noted. The plot thickens, and by plot I mean your browser tab.",
        "Understood. I shall react with the exact amount of dramatic flair this deserves.",
        "Got it. I am resisting at least three jokes right now. Character growth.",
      ]),
      mood: pick(["smug", "excited", "happy"]),
    };
  }
  return {
    text: pick([
      "Got it. What's next?",
      "Understood. Anything else you need?",
      "Clear. Give me your next command.",
    ]),
    mood: "neutral",
  };
}

export function greetingFor(hour: number, name: string | null): string {
  const n = name ? `, ${name}` : "";
  if (hour < 5) return `Late night session${n}? Ada online. What do you need?`;
  if (hour < 12) return `Good morning${n}! Ada online and ready.`;
  if (hour < 18) return `Good afternoon${n}! Ada online. What's next?`;
  return `Good evening${n}. Ada online. Ready.`;
}
