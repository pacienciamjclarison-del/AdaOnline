export type NewsArticle = {
  title: string;
  source: string;
  pubDate: string;
  timeAgo: string;
  link: string;
};

export type NewsCategory =
  | "top"
  | "tech"
  | "ai"
  | "gaming"
  | "business"
  | "entertainment"
  | "malaysia"
  | "science"
  | "sports";

const CATEGORY_QUERIES: Record<NewsCategory, string | null> = {
  top: null, // General top stories
  tech: "technology",
  ai: "artificial intelligence OR OpenAI OR Anthropic OR AI",
  gaming: "video games OR gaming",
  business: "business OR economy OR stock market",
  entertainment: "entertainment OR anime OR movies",
  malaysia: null, // Handled with hl=en-MY
  science: "science OR space OR astronomy",
  sports: "sports",
};

const cache = new Map<string, { at: number; data: NewsArticle[] }>();
const TTL = 2 * 60 * 1000; // 2 minutes cache

function timeAgo(dateStr: string): string {
  try {
    const d = new Date(dateStr);
    const diff = Math.floor((Date.now() - d.getTime()) / 1000);
    if (diff < 60) return "just now";
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    return `${Math.floor(diff / 86400)}d ago`;
  } catch {
    return "";
  }
}

function cleanHtml(str: string): string {
  return str
    .replace(/<!\[CDATA\[(.*?)\]\]>/g, "$1")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .trim();
}

export async function fetchLiveNews(options?: {
  query?: string;
  category?: NewsCategory;
  limit?: number;
  country?: string;
}): Promise<NewsArticle[]> {
  const query = options?.query?.trim();
  const category = options?.category || "top";
  const limit = Math.max(1, Math.min(15, options?.limit || 5));
  const country = (options?.country || "US").toUpperCase();

  const cacheKey = `${query || ""}_${category}_${country}_${limit}`;
  const hit = cache.get(cacheKey);
  if (hit && Date.now() - hit.at < TTL) return hit.data;

  let url: string;

  if (query) {
    url = `https://news.google.com/rss/search?q=${encodeURIComponent(query)}&hl=en-US&gl=US&ceid=US:en`;
  } else if (category === "malaysia" || country === "MY") {
    url = "https://news.google.com/rss?hl=en-MY&gl=MY&ceid=MY:en";
  } else if (CATEGORY_QUERIES[category]) {
    const q = CATEGORY_QUERIES[category]!;
    url = `https://news.google.com/rss/search?q=${encodeURIComponent(q)}&hl=en-US&gl=US&ceid=US:en`;
  } else {
    url = "https://news.google.com/rss?hl=en-US&gl=US&ceid=US:en";
  }

  try {
    const res = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 AdaAssistant/1.0",
        Accept: "application/rss+xml, application/xml, text/xml",
      },
      signal: AbortSignal.timeout(5000),
      cache: "no-store",
    });

    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const xml = await res.text();

    const items: NewsArticle[] = [];
    const itemMatches = xml.match(/<item>([\s\S]*?)<\/item>/gi) || [];

    for (const itemXml of itemMatches.slice(0, limit)) {
      const titleMatch = itemXml.match(/<title>([\s\S]*?)<\/title>/i);
      const linkMatch = itemXml.match(/<link>([\s\S]*?)<\/link>/i);
      const pubDateMatch = itemXml.match(/<pubDate>([\s\S]*?)<\/pubDate>/i);
      const sourceMatch = itemXml.match(/<source[^>]*>([\s\S]*?)<\/source>/i);

      let rawTitle = titleMatch ? cleanHtml(titleMatch[1]) : "";
      let source = sourceMatch ? cleanHtml(sourceMatch[1]) : "";

      let cleanTitle = rawTitle;
      const lastDash = rawTitle.lastIndexOf(" - ");
      if (lastDash > 12) {
        if (!source) source = rawTitle.slice(lastDash + 3).trim();
        cleanTitle = rawTitle.slice(0, lastDash).trim();
      }

      const link = linkMatch ? cleanHtml(linkMatch[1]) : "";
      const pubDate = pubDateMatch ? cleanHtml(pubDateMatch[1]) : "";

      if (cleanTitle) {
        items.push({
          title: cleanTitle,
          source: source || "News",
          pubDate,
          timeAgo: pubDate ? timeAgo(pubDate) : "",
          link,
        });
      }
    }

    cache.set(cacheKey, { at: Date.now(), data: items });
    return items;
  } catch (err) {
    console.error("[news] fetch error:", err instanceof Error ? err.message : err);
    return hit?.data || [];
  }
}
