import { db } from "@/db";
import { memories, messages, notes, tasks } from "@/db/schema";
import { and, asc, desc, eq, sql } from "drizzle-orm";

/** Reads the anonymous device id the browser sends with every request. */
export function getUid(req: Request): string {
  const raw = req.headers.get("x-ada-uid") ?? "";
  return /^[a-zA-Z0-9-]{8,64}$/.test(raw) ? raw : "anon";
}

/* ----------------------------- messages ----------------------------- */

export async function addMessage(uid: string, role: "user" | "assistant", content: string, emotion?: string) {
  const [row] = await db
    .insert(messages)
    .values({ userId: uid, role, content, emotion: emotion ?? null })
    .returning();
  return row;
}

export async function recentMessages(uid: string, limit = 40) {
  const rows = await db
    .select()
    .from(messages)
    .where(eq(messages.userId, uid))
    .orderBy(desc(messages.id))
    .limit(limit);
  return rows.reverse();
}

export async function clearMessages(uid: string) {
  await db.delete(messages).where(eq(messages.userId, uid));
}

/* ------------------------------ tasks ------------------------------- */

export async function listTasks(uid: string) {
  return db
    .select()
    .from(tasks)
    .where(eq(tasks.userId, uid))
    .orderBy(asc(tasks.done), desc(tasks.id));
}

export async function addTask(uid: string, text: string) {
  const [row] = await db.insert(tasks).values({ userId: uid, text: text.slice(0, 300) }).returning();
  return row;
}

export async function setTaskDone(uid: string, id: number, done: boolean) {
  await db
    .update(tasks)
    .set({ done })
    .where(and(eq(tasks.userId, uid), eq(tasks.id, id)));
}

export async function deleteTask(uid: string, id: number) {
  await db.delete(tasks).where(and(eq(tasks.userId, uid), eq(tasks.id, id)));
}

export async function clearDoneTasks(uid: string) {
  await db.delete(tasks).where(and(eq(tasks.userId, uid), eq(tasks.done, true)));
}

/* ------------------------------ notes ------------------------------- */

export async function listNotes(uid: string) {
  return db.select().from(notes).where(eq(notes.userId, uid)).orderBy(desc(notes.id));
}

export async function addNote(uid: string, text: string) {
  const [row] = await db.insert(notes).values({ userId: uid, text: text.slice(0, 2000) }).returning();
  return row;
}

export async function deleteNote(uid: string, id: number) {
  await db.delete(notes).where(and(eq(notes.userId, uid), eq(notes.id, id)));
}

/* ----------------------------- memories ----------------------------- */

export async function listMemories(uid: string) {
  return db.select().from(memories).where(eq(memories.userId, uid)).orderBy(desc(memories.id));
}

export async function addMemory(uid: string, fact: string) {
  const clean = fact.trim().slice(0, 300);
  if (!clean) return null;
  const existing = await db
    .select()
    .from(memories)
    .where(and(eq(memories.userId, uid), sql`lower(${memories.fact}) = ${clean.toLowerCase()}`))
    .limit(1);
  if (existing[0]) return existing[0];
  const [row] = await db.insert(memories).values({ userId: uid, fact: clean }).returning();
  return row;
}

export async function deleteMemory(uid: string, id: number) {
  await db.delete(memories).where(and(eq(memories.userId, uid), eq(memories.id, id)));
}

export async function deleteMemoriesLike(uid: string, pattern: string) {
  await db.delete(memories).where(and(eq(memories.userId, uid), sql`${memories.fact} ilike ${pattern}`));
}

export async function clearMemories(uid: string) {
  await db.delete(memories).where(eq(memories.userId, uid));
}
