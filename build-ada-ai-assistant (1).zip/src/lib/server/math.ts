// A tiny, safe arithmetic evaluator (no eval). Supports + - * / ^ % ( ), a few functions and constants.

type Tok = { t: "num"; v: number } | { t: "op"; v: string } | { t: "id"; v: string };

const FUNCS: Record<string, (x: number) => number> = {
  sqrt: Math.sqrt,
  abs: Math.abs,
  sin: (x) => Math.sin((x * Math.PI) / 180),
  cos: (x) => Math.cos((x * Math.PI) / 180),
  tan: (x) => Math.tan((x * Math.PI) / 180),
  log: Math.log10,
  ln: Math.log,
  round: Math.round,
  floor: Math.floor,
  ceil: Math.ceil,
};
const CONSTS: Record<string, number> = { pi: Math.PI, e: Math.E };

function tokenize(src: string): Tok[] {
  const out: Tok[] = [];
  let i = 0;
  while (i < src.length) {
    const ch = src[i];
    if (/\s/.test(ch)) {
      i++;
    } else if (/[0-9.]/.test(ch)) {
      let j = i;
      while (j < src.length && /[0-9.]/.test(src[j])) j++;
      const n = Number(src.slice(i, j));
      if (Number.isNaN(n)) throw new Error("bad number");
      out.push({ t: "num", v: n });
      i = j;
    } else if (/[a-z]/i.test(ch)) {
      let j = i;
      while (j < src.length && /[a-z]/i.test(src[j])) j++;
      out.push({ t: "id", v: src.slice(i, j).toLowerCase() });
      i = j;
    } else if ("+-*/^%()".includes(ch)) {
      out.push({ t: "op", v: ch });
      i++;
    } else {
      throw new Error("bad char");
    }
  }
  return out;
}

export function evaluate(src: string): number {
  const toks = tokenize(src);
  let p = 0;
  const peek = () => toks[p];
  const isOp = (v: string) => peek()?.t === "op" && (peek() as { v: string }).v === v;

  function parseExpr(): number {
    let v = parseTerm();
    while (isOp("+") || isOp("-")) {
      const op = (toks[p++] as { v: string }).v;
      const r = parseTerm();
      v = op === "+" ? v + r : v - r;
    }
    return v;
  }
  function parseTerm(): number {
    let v = parsePow();
    while (isOp("*") || isOp("/") || isOp("%")) {
      const op = (toks[p++] as { v: string }).v;
      const r = parsePow();
      v = op === "*" ? v * r : op === "/" ? v / r : v % r;
    }
    return v;
  }
  function parsePow(): number {
    const base = parseUnary();
    if (isOp("^")) {
      p++;
      return Math.pow(base, parsePow());
    }
    return base;
  }
  function parseUnary(): number {
    if (isOp("-")) {
      p++;
      return -parseUnary();
    }
    if (isOp("+")) {
      p++;
      return parseUnary();
    }
    return parseAtom();
  }
  function parseAtom(): number {
    const tk = toks[p++];
    if (!tk) throw new Error("unexpected end");
    if (tk.t === "num") return tk.v;
    if (tk.t === "id") {
      if (tk.v in CONSTS) return CONSTS[tk.v];
      const fn = FUNCS[tk.v];
      if (!fn) throw new Error("unknown id");
      if (!isOp("(")) throw new Error("expected (");
      p++;
      const arg = parseExpr();
      if (!isOp(")")) throw new Error("expected )");
      p++;
      return fn(arg);
    }
    if (tk.v === "(") {
      const v = parseExpr();
      if (!isOp(")")) throw new Error("expected )");
      p++;
      return v;
    }
    throw new Error("unexpected token");
  }

  const result = parseExpr();
  if (p < toks.length) throw new Error("trailing tokens");
  if (!Number.isFinite(result)) throw new Error("not finite");
  return result;
}

export function formatNumber(n: number): string {
  if (Number.isInteger(n) && Math.abs(n) < 1e15) return n.toLocaleString("en-US");
  const rounded = Number(n.toPrecision(10));
  return rounded.toLocaleString("en-US", { maximumFractionDigits: 8 });
}

/** Turns natural language like "12 times 4 plus 3" into an expression and evaluates it. */
export function evaluateNatural(input: string): { expression: string; result: number } | null {
  let s = input.toLowerCase().trim();
  s = s.replace(/[?!]+$/g, "").replace(/\bequals?\b.*$/, "").replace(/=\s*$/, "").trim();
  s = s.replace(/^(?:please\s+)?(?:can you\s+)?(?:calculate|compute|solve|work out|what(?:'s| is)|how much is|how many is|whats)\s+/, "");

  const pct = s.match(/^(\d+(?:\.\d+)?)\s*(?:%|percent)\s*of\s*(\d+(?:\.\d+)?)$/);
  if (pct) {
    const r = (Number(pct[1]) / 100) * Number(pct[2]);
    return { expression: `${pct[1]}% of ${pct[2]}`, result: r };
  }

  s = s
    .replace(/square root of\s*(\d+(?:\.\d+)?)/g, "sqrt($1)")
    .replace(/(\d+(?:\.\d+)?)\s*squared/g, "($1^2)")
    .replace(/(\d+(?:\.\d+)?)\s*cubed/g, "($1^3)")
    .replace(/to the power of|to the power|raised to/g, "^")
    .replace(/multiplied by|times|\bx\b|×/g, "*")
    .replace(/divided by|\bover\b|÷/g, "/")
    .replace(/\bplus\b/g, "+")
    .replace(/\bminus\b|\btake away\b/g, "-")
    .replace(/\bmod(?:ulo)?\b/g, "%")
    .replace(/(\d),(?=\d{3}\b)/g, "$1")
    .replace(/\band\b/g, "+")
    .trim();

  if (!/\d/.test(s)) return null;
  // only allow digits, operators, parentheses, known function names and constants
  const words = s.match(/[a-z]+/g) ?? [];
  if (words.some((w) => !(w in FUNCS) && !(w in CONSTS))) return null;
  if (!/[+\-*/^%()]|[a-z]/.test(s)) return null; // a bare number isn't a calculation
  try {
    return { expression: s, result: evaluate(s) };
  } catch {
    return null;
  }
}
