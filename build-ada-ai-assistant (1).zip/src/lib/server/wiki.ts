export type WikiResult = { title: string; extract: string; url: string };

const HEADERS = { "User-Agent": "AdaAssistant/1.0 (personal AI companion)", Accept: "application/json" };

async function getJson(url: string, timeoutMs: number) {
  const res = await fetch(url, { headers: HEADERS, signal: AbortSignal.timeout(timeoutMs), cache: "no-store" });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

/** Looks up a short Wikipedia summary. Returns null when nothing relevant is found. */
export async function wikiLookup(subject: string, timeoutMs = 3000): Promise<WikiResult | null> {
  const q = subject.trim().slice(0, 120);
  if (!q) return null;
  try {
    const search = await getJson(
      `https://en.wikipedia.org/w/rest.php/v1/search/title?q=${encodeURIComponent(q)}&limit=1`,
      timeoutMs,
    );
    const page = search?.pages?.[0];
    if (!page?.key) return null;
    const summary = await getJson(
      `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(page.key)}`,
      timeoutMs,
    );
    if (!summary?.extract || summary.type === "disambiguation") return null;
    return {
      title: String(summary.title ?? page.title),
      extract: String(summary.extract).slice(0, 900),
      url: summary?.content_urls?.desktop?.page ?? `https://en.wikipedia.org/wiki/${page.key}`,
    };
  } catch {
    return null;
  }
}

/** True when the page title shares a meaningful word with what the user asked for. */
export function titleMatches(subject: string, title: string): boolean {
  const words = subject
    .toLowerCase()
    .split(/[^a-z0-9]+/)
    .filter((w) => w.length > 2 && !["the", "and", "for", "with", "about", "what", "who"].includes(w));
  const t = title.toLowerCase();
  return words.some((w) => t.includes(w));
}
