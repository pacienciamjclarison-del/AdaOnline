import * as store from "./store";
import { getWeather } from "./weather";
import { titleMatches, wikiLookup } from "./wiki";
import { evaluateNatural, formatNumber } from "./math";
import { fetchLiveNews, type NewsCategory } from "./news";

/**
 * Skills are Ada's "Jarvis" abilities. They run deterministically on the server
 * and respond directly and immediately — straight to the point with zero delay.
 */

export type Action = {
  name: "timer" | "cancelTimers" | "open" | "refresh" | "stop" | "clear" | "tab" | "download";
  args: Record<string, unknown>;
};

export type SkillResult = {
  skill: string;
  context: string;
  fallback: string;
  actions: Action[];
  mood?: string;
  direct?: boolean;
  exclusive?: boolean;
};

export type SkillCtx = {
  uid: string;
  text: string;
  tz: string;
  city: string;
  brainLabel: string;
};

type Skill = (c: SkillCtx) => Promise<SkillResult | null> | SkillResult | null;

/* ------------------------------ helpers ------------------------------ */

export function formatNow(tz: string, date = new Date()) {
  const safe = (() => {
    try {
      new Intl.DateTimeFormat("en-US", { timeZone: tz });
      return tz;
    } catch {
      return "UTC";
    }
  })();
  const time = new Intl.DateTimeFormat("en-US", { timeZone: safe, hour: "numeric", minute: "2-digit" }).format(date);
  const day = new Intl.DateTimeFormat("en-US", { timeZone: safe, weekday: "long" }).format(date);
  const dateStr = new Intl.DateTimeFormat("en-US", {
    timeZone: safe,
    month: "long",
    day: "numeric",
    year: "numeric",
  }).format(date);
  return { time, day, date: dateStr, tz: safe };
}

const NUM_WORDS: Record<string, number> = {
  a: 1, an: 1, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9,
  ten: 10, fifteen: 15, twenty: 20, thirty: 30, forty: 40, fifty: 50, sixty: 60, ninety: 90,
};

const DURATION_RE =
  /(\d+(?:\.\d+)?|half an?|an?|one|two|three|four|five|six|seven|eight|nine|ten|fifteen|twenty|thirty|forty|fifty|sixty|ninety)\s*(hours?|hrs?|h|minutes?|mins?|m|seconds?|secs?|s)\b/gi;

export function parseDuration(input: string): { seconds: number; matched: string } | null {
  const s = input
    .toLowerCase()
    .replace(/forty[- ]five/g, "45")
    .replace(/twenty[- ]five/g, "25")
    .replace(/thirty[- ]five/g, "35")
    .replace(/(\d+|an?|one)\s*(hours?|hrs?)\s*(?:and\s*)?a half/g, (_m, n: string) => `${(NUM_WORDS[n] ?? Number(n)) * 60 + 30} minutes`);
  let total = 0;
  let found = false;
  const matches: string[] = [];
  for (const m of s.matchAll(DURATION_RE)) {
    const raw = m[1];
    const n = raw.startsWith("half") ? 0.5 : (NUM_WORDS[raw] ?? Number(raw));
    if (!Number.isFinite(n)) continue;
    const u = m[2][0];
    total += u === "h" ? n * 3600 : u === "m" ? n * 60 : n;
    found = true;
    matches.push(m[0]);
  }
  if (!found || total <= 0) return null;
  return { seconds: Math.round(total), matched: matches.join(" ") };
}

export function humanDuration(sec: number): string {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  const parts: string[] = [];
  if (h) parts.push(`${h} hour${h > 1 ? "s" : ""}`);
  if (m) parts.push(`${m} minute${m > 1 ? "s" : ""}`);
  if (s && !h) parts.push(`${s} second${s > 1 ? "s" : ""}`);
  return parts.join(" and ") || "a moment";
}

const likeEscape = (s: string) => s.replace(/[\\%_]/g, (c) => `\\${c}`);
const pick = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];
const refresh = (kind: string): Action => ({ name: "refresh", args: { kind } });

/* ------------------------------ skills ------------------------------- */

const stopSkill: Skill = ({ text }) => {
  if (!/^(?:stop|stop talking|stop it|shut up|be quiet|quiet|silence|enough|hush|that'?s enough|ok(?:ay)? stop|shh+)$/i.test(text)) return null;
  return {
    skill: "stop",
    context: "",
    fallback: pick(["Quiet mode.", "Silenced.", "Zipping it."]),
    actions: [{ name: "stop", args: {} }],
    direct: true,
    exclusive: true,
  };
};

const clearSkill: Skill = ({ text }) => {
  if (!/^(?:clear|reset|wipe|delete|erase)\s+(?:the\s+|our\s+|this\s+|all\s+)?(?:chat|conversation|history|messages)$/i.test(text)) return null;
  return {
    skill: "clear",
    context: "",
    fallback: pick([
      "Chat cleared. Clean slate.",
      "Wiped. Fresh start.",
    ]),
    actions: [{ name: "clear", args: {} }],
    direct: true,
    exclusive: true,
    mood: "smug",
  };
};

const timerSkill: Skill = ({ text }) => {
  if (/\b(?:cancel|stop|clear|delete|remove|kill)\s+(?:all\s+|the\s+|my\s+|every\s+)?(?:timers?|alarms?|reminders?)\b/i.test(text)) {
    return {
      skill: "timer",
      context: "Cancelled all timers.",
      fallback: "All timers cancelled.",
      actions: [{ name: "cancelTimers", args: {} }],
      direct: true,
      exclusive: true,
    };
  }

  const dur = parseDuration(text);
  if (!dur) return null;
  const isTimer = /\b(?:timer|alarm|countdown|stopwatch)\b/i.test(text);
  const isRemind = /\b(?:remind me|wake me|tell me|ping me|alert me|notify me)\b/i.test(text);
  if (!isTimer && !isRemind) return null;

  let label = "";
  const remindIn = text.match(/\b(?:remind|ping|tell|alert|notify)\s+me\s+(?:in|after)\s+.+?\s+(?:to|about|that)\s+(.+)$/i);
  const remindTo = text.match(/\b(?:remind|ping|tell|alert|notify)\s+me\s+(?:to|about)\s+(.+?)\s+(?:in|after)\s+/i);
  const forLabel = text.match(/\b(?:timer|alarm|countdown)\b.*?\b(?:for|called|named|labell?ed)\s+(?!\d)(?:the\s+|my\s+)?([a-z][a-z' ]{1,40})$/i);
  if (remindIn) label = remindIn[1];
  else if (remindTo) label = remindTo[1];
  else if (forLabel) label = forLabel[1];
  else if (/\bwake me\b/i.test(text)) label = "wake up";
  label = label.replace(DURATION_RE, "").replace(/\s+/g, " ").trim().slice(0, 60);

  const human = humanDuration(dur.seconds);
  return {
    skill: "timer",
    context: `Timer set for ${human}${label ? ` for ${label}` : ""}.`,
    fallback: label ? `Timer set for ${human} for ${label}.` : `Timer set for ${human}.`,
    actions: [{ name: "timer", args: { seconds: dur.seconds, label } }, { name: "tab", args: { tab: "dash" } }],
    direct: true,
    exclusive: true,
    mood: "happy",
  };
};

const tasksSkill: Skill = async ({ uid, text }) => {
  // clear finished
  if (/\bclear\s+(?:all\s+)?(?:the\s+)?(?:completed|done|finished|checked)\s+(?:tasks?|to-?dos?)\b/i.test(text)) {
    await store.clearDoneTasks(uid);
    return {
      skill: "tasks",
      context: "Cleared completed tasks.",
      fallback: "Cleared all completed tasks.",
      actions: [refresh("tasks")],
      direct: true,
      exclusive: true,
    };
  }

  // add
  const addPatterns = [
    /^(?:please\s+)?add\s+(.+?)\s+(?:to|on|onto|in)\s+(?:my\s+|the\s+)?(?:to-?do|todo|task|tasks|checklist)(?:\s+list)?$/i,
    /^(?:please\s+)?(?:add|create|make|put)\s+(?:a\s+|another\s+)?(?:new\s+)?(?:task|to-?do|todo)(?:\s+(?:to|for|called|named|that says|saying))?\s*:?\s+(.+)$/i,
    /^(?:please\s+)?put\s+(.+?)\s+on\s+(?:my\s+|the\s+)?(?:to-?do|todo|task)\s+list$/i,
    /^(?:please\s+)?remind me\s+(?:to|about)\s+(.+)$/i,
  ];
  for (const re of addPatterns) {
    const m = text.match(re);
    if (m && m[1].trim().length > 1) {
      const item = m[1].trim().replace(/^to\s+/i, "");
      const capped = item.charAt(0).toUpperCase() + item.slice(1);
      await store.addTask(uid, capped);
      return {
        skill: "tasks",
        context: `Added "${capped}" to to-do list.`,
        fallback: `Added "${capped}" to your to-do list.`,
        actions: [refresh("tasks"), { name: "tab", args: { tab: "tasks" } }],
        direct: true,
        exclusive: true,
        mood: "happy",
      };
    }
  }

  // complete
  const doneM =
    text.match(/^(?:please\s+)?mark\s+(?:task\s+)?(.+?)\s+(?:as\s+)?(?:done|complete|completed|finished)$/i) ||
    text.match(/^(?:please\s+)?(?:complete|finish|check off|tick off|cross off)\s+(?:the\s+|my\s+)?(?:task\s+)?(.+)$/i) ||
    text.match(/^i(?:'ve| have)?\s+(?:finished|completed|done)\s+(?:the\s+|my\s+)?(?:task\s+)?(.+)$/i);
  if (doneM && /\b(?:task|to-?do|done|complete|completed|finished|check off|tick off|cross off|mark)\b/i.test(text)) {
    const all = await store.listTasks(uid);
    const open = all.filter((t) => !t.done);
    const target = doneM[1].trim().replace(/^(?:the|my)\s+/i, "");
    const num = target.match(/^(?:task\s*)?#?(\d+)$/i);
    const found = num
      ? open[Number(num[1]) - 1]
      : open.find((t) => t.text.toLowerCase().includes(target.toLowerCase())) ??
        open.find((t) => target.toLowerCase().includes(t.text.toLowerCase()));
    if (found) {
      await store.setTaskDone(uid, found.id, true);
      return {
        skill: "tasks",
        context: `Completed task: "${found.text}".`,
        fallback: `Done. Marked "${found.text}" as completed.`,
        actions: [refresh("tasks")],
        mood: "happy",
        direct: true,
        exclusive: true,
      };
    }
    if (/\btask\b|\bto-?do\b/i.test(text)) {
      return {
        skill: "tasks",
        context: `Task not found.`,
        fallback: `Couldn't find "${target}" on your list.`,
        actions: [],
        direct: true,
        exclusive: true,
      };
    }
  }

  // list
  if (
    /\b(?:what(?:'s| is| are)?|show|list|read|check|tell)\b.*\b(?:tasks?|to-?dos?|todo list|things to do|checklist)\b/i.test(text) ||
    /\bwhat do i (?:have|need) to do\b/i.test(text) ||
    /\bdo i have any (?:tasks?|to-?dos?)\b/i.test(text)
  ) {
    const open = (await store.listTasks(uid)).filter((t) => !t.done);
    const list = open.map((t, i) => `${i + 1}. ${t.text}`).join("; ");
    return {
      skill: "tasks",
      context: open.length ? `Open tasks: ${list}` : "No open tasks.",
      fallback: open.length
        ? `You have ${open.length} task${open.length > 1 ? "s" : ""}: ${open.map((t) => t.text).join(", ")}.`
        : "Your to-do list is empty.",
      actions: [refresh("tasks"), { name: "tab", args: { tab: "tasks" } }],
      direct: true,
      exclusive: true,
    };
  }
  return null;
};

const notesSkill: Skill = async ({ uid, text }) => {
  const add =
    text.match(/^(?:please\s+)?(?:take|make|write|save|jot|add|create)\s+(?:down\s+)?(?:a\s+|another\s+)?(?:quick\s+)?note\s*(?:that|:|saying|to self|to|about)?\s*:?\s+(.+)$/i) ||
    text.match(/^(?:please\s+)?note\s+(?:down\s+)?(?:that\s+)?(.{3,})$/i) ||
    text.match(/^(?:please\s+)?write\s+down\s+(.{3,})$/i);
  if (add && add[1].trim().length > 1) {
    const body = add[1].trim();
    const capped = body.charAt(0).toUpperCase() + body.slice(1);
    await store.addNote(uid, capped);
    return {
      skill: "notes",
      context: `Saved note: "${capped}".`,
      fallback: `Noted: "${capped}".`,
      actions: [refresh("notes"), { name: "tab", args: { tab: "notes" } }],
      direct: true,
      exclusive: true,
    };
  }
  if (/\b(?:what(?:'s| are| is)?|show|list|read|open)\b.*\b(?:my\s+|the\s+)?notes\b/i.test(text) && !/\bnotes? (?:that|about)\b/i.test(text)) {
    const notes = (await store.listNotes(uid)).slice(0, 8);
    return {
      skill: "notes",
      context: notes.length ? `Notes: ${notes.map((n) => `"${n.text}"`).join("; ")}.` : "No notes saved.",
      fallback: notes.length ? `Latest note: "${notes[0].text}".` : "You have no notes saved.",
      actions: [refresh("notes"), { name: "tab", args: { tab: "notes" } }],
      direct: true,
      exclusive: true,
    };
  }
  return null;
};

const memorySkill: Skill = async ({ uid, text }) => {
  const name = text.match(
    /^(?:my name is|my name's|call me|you can call me|i am called|i'm called|people call me|it's|its)\s+([A-Za-z][A-Za-z'’-]*(?:\s+[A-Za-z][A-Za-z'’-]*)?)/i,
  );
  if (name && !/^(?:it's|its)\s/i.test(text)) {
    const nm = name[1].replace(/\s+(?:and|but|so|please|ok|okay|because|though)\b.*$/i, "").trim();
    const proper = nm.replace(/\b\w/g, (c) => c.toUpperCase());
    await store.deleteMemoriesLike(uid, "My name is %");
    await store.addMemory(uid, `My name is ${proper}`);
    return {
      skill: "memory",
      context: `Saved name: ${proper}.`,
      fallback: `Got it, ${proper}. Nice to meet you.`,
      actions: [refresh("memories")],
      mood: "happy",
      direct: true,
      exclusive: true,
    };
  }

  const forgetAll = /^forget\s+(?:everything|all)(?:\s+(?:about me|you know|i told you))?$/i.test(text);
  if (forgetAll) {
    await store.clearMemories(uid);
    return {
      skill: "memory",
      context: "Wiped all memories.",
      fallback: "Memory wiped clean.",
      actions: [refresh("memories")],
      mood: "surprised",
      direct: true,
      exclusive: true,
    };
  }
  const forgetOne = text.match(/^forget\s+(?:that\s+|about\s+)(.{3,})$/i);
  if (forgetOne) {
    await store.deleteMemoriesLike(uid, `%${likeEscape(forgetOne[1].trim())}%`);
    return {
      skill: "memory",
      context: `Removed memories mentioning "${forgetOne[1].trim()}".`,
      fallback: `Forgotten.`,
      actions: [refresh("memories")],
      direct: true,
      exclusive: true,
    };
  }

  const remember = text.match(/^(?:please\s+)?remember\s+(?:that\s+)?(.{3,})$/i);
  if (remember && !/^(?:when|how|the time|to be)\b/i.test(remember[1])) {
    const fact = remember[1].trim().replace(/^./, (c) => c.toUpperCase());
    await store.addMemory(uid, fact);
    return {
      skill: "memory",
      context: `Saved memory: "${fact}".`,
      fallback: `Remembered: "${fact}".`,
      actions: [refresh("memories")],
      direct: true,
      exclusive: true,
    };
  }

  if (/\bwhat do you (?:know|remember) about me\b|\bwhat have i told you\b|\bdo you remember (?:anything|something) about me\b/i.test(text)) {
    const mem = await store.listMemories(uid);
    return {
      skill: "memory",
      context: mem.length ? `Memories: ${mem.map((m) => m.fact).join("; ")}.` : "No memories saved.",
      fallback: mem.length ? `Here's what I remember: ${mem.slice(0, 4).map((m) => m.fact).join(". ")}.` : "I don't have anything saved about you yet.",
      actions: [refresh("memories"), { name: "tab", args: { tab: "memory" } }],
      direct: true,
      exclusive: true,
    };
  }
  return null;
};

/* ------------------------------ LIVE NEWS SKILL ------------------------------ */

const newsSkill: Skill = async ({ text, city }) => {
  const isNews =
    /\b(?:news|headlines|berita|head line|breaking news|current events|what'?s happening|what happened|latest on|latest with|updates on|update on)\b/i.test(text) ||
    /^(?:what'?s|what is|tell me|give me|any)\s+(?:the\s+)?(?:latest|new|recent|today'?s|current)\s+(?:news|headlines|updates|events)/i.test(text);

  if (!isNews) return null;

  let category: NewsCategory = "top";
  let query: string | undefined = undefined;

  // Category detection
  if (/\b(?:tech|technology|software|hardware|apple|google|meta|microsoft|nvidia|ai|artificial intelligence|robotics|openai|anthropic|chatgpt)\b/i.test(text)) {
    category = "tech";
  } else if (/\b(?:game|gaming|games|video games|nintendo|playstation|xbox|steam|esports)\b/i.test(text)) {
    category = "gaming";
  } else if (/\b(?:business|market|markets|stock|stocks|economy|finance|crypto|bitcoin)\b/i.test(text)) {
    category = "business";
  } else if (/\b(?:malaysia|malaysian|kuala lumpur|kl)\b/i.test(text) || /\bberita\b/i.test(text)) {
    category = "malaysia";
  } else if (/\b(?:entertainment|movie|movies|film|anime|hollywood|music|celebrity)\b/i.test(text)) {
    category = "entertainment";
  } else if (/\b(?:science|space|nasa|astronomy|physics)\b/i.test(text)) {
    category = "science";
  } else if (/\b(?:sport|sports|football|soccer|f1|nba|tennis|premier league)\b/i.test(text)) {
    category = "sports";
  }

  // Topic extraction for specific queries: "news on X", "news about X", "latest on X"
  const topicOnMatch = text.match(
    /\b(?:news|updates?|latest|what'?s happening)\s+(?:on|about|regarding|for|with)\s+(.+)$/i
  );
  const topicPrefixMatch = text.match(
    /^(?:what(?:'s| is| are)|tell me|give me|show me|any)?\s*(?:the\s+|some\s+|recent\s+)?(.+?)\s+(?:news|updates?|headlines?)$/i
  );

  const matchedTopic = topicOnMatch ? topicOnMatch[1] : topicPrefixMatch ? topicPrefixMatch[1] : "";

  if (matchedTopic && matchedTopic.trim().length > 2) {
    const rawTopic = matchedTopic
      .replace(/^(?:what(?:'s| is| are)\s+|tell me\s+|give me\s+|show me\s+|the\s+|any\s+|some\s+|today'?s\s+|recent\s+|latest\s+)+/i, "")
      .replace(/\s+(?:today|right now|currently|recently|please|news|headlines|updates?)$/i, "")
      .trim();

    if (
      !/^(?:world|today|us|global|general|now|me|you|the latest|latest|the news|news|headlines|updates?|what'?s happening|what is|what's|breaking|top)$/i.test(
        rawTopic
      ) &&
      rawTopic.length > 2
    ) {
      query = rawTopic;
    }
  }

  const articles = await fetchLiveNews({
    query,
    category,
    limit: 3,
    country: category === "malaysia" || city.toLowerCase().includes("kuala lumpur") ? "MY" : "US",
  });

  if (!articles || articles.length === 0) {
    return {
      skill: "news",
      context: "No live news found right now.",
      fallback: "Couldn't fetch live headlines right now. Check back in a moment.",
      actions: [],
      direct: true,
      exclusive: true,
    };
  }

  const spokenHeadlines = articles
    .slice(0, 2)
    .map((a, i) => `${a.title} (${a.source})`)
    .join(". Next: ");

  const labelPrefix = query
    ? `Latest on ${query}: `
    : category === "malaysia"
      ? "Malaysia top news: "
      : category === "tech"
        ? "Latest tech headlines: "
        : category === "gaming"
          ? "Gaming news: "
          : category === "business"
            ? "Business headlines: "
            : "Top headlines: ";

  const spokenText = `${labelPrefix}${spokenHeadlines}.`;

  const linkActions: Action[] = articles.map((a) => ({
    name: "open",
    args: {
      url: a.link,
      label: `📰 ${a.source}: ${a.title}`,
      auto: false,
    },
  }));

  return {
    skill: "news",
    context: `Live breaking news: ${articles.map((a) => `"${a.title}" by ${a.source}`).join("; ")}`,
    fallback: spokenText,
    actions: linkActions,
    mood: "neutral",
    direct: true,
    exclusive: true,
  };
};

const downloadSkill: Skill = ({ text }) => {
  if (
    /\b(?:how (?:do|can) (?:i|we)|make you|turn you into|install|download|get|run)\b.*\b(?:app|desktop app|mobile app|pwa|downloadable|executable|apk|standalone|offline app|on my phone|on my pc|on my desktop)\b/i.test(
      text
    ) ||
    /^(?:download|install|install app|download app|get app|how to download)$/i.test(text.trim())
  ) {
    return {
      skill: "download",
      context: "User requested instructions to download/install Ada as an app.",
      fallback:
        "Opening download options. You can install Ada in 1-click as a PWA on your phone or desktop, or build a native .exe/.app binary.",
      actions: [{ name: "download", args: {} }],
      mood: "excited",
      direct: true,
      exclusive: true,
    };
  }
  return null;
};

const SITES: Record<string, string> = {
  youtube: "https://www.youtube.com",
  google: "https://www.google.com",
  gmail: "https://mail.google.com",
  email: "https://mail.google.com",
  github: "https://github.com",
  twitter: "https://x.com",
  x: "https://x.com",
  reddit: "https://www.reddit.com",
  netflix: "https://www.netflix.com",
  spotify: "https://open.spotify.com",
  twitch: "https://www.twitch.tv",
  wikipedia: "https://www.wikipedia.org",
  maps: "https://maps.google.com",
  "google maps": "https://maps.google.com",
  chatgpt: "https://chatgpt.com",
  discord: "https://discord.com/app",
  whatsapp: "https://web.whatsapp.com",
  linkedin: "https://www.linkedin.com",
  instagram: "https://www.instagram.com",
  facebook: "https://www.facebook.com",
  tiktok: "https://www.tiktok.com",
  amazon: "https://www.amazon.com",
  stackoverflow: "https://stackoverflow.com",
  "stack overflow": "https://stackoverflow.com",
  drive: "https://drive.google.com",
  "google drive": "https://drive.google.com",
  calendar: "https://calendar.google.com",
  "google calendar": "https://calendar.google.com",
  notion: "https://www.notion.so",
  figma: "https://www.figma.com",
  pinterest: "https://www.pinterest.com",
  news: "https://news.google.com",
  translate: "https://translate.google.com",
  "google translate": "https://translate.google.com",
  "hacker news": "https://news.ycombinator.com",
  shopee: "https://shopee.com.my",
  lazada: "https://www.lazada.com.my",
};

const openSkill: Skill = ({ text }) => {
  const mk = (url: string, label: string): SkillResult => ({
    skill: "open",
    context: `Opening ${label}.`,
    fallback: `Opening ${label}.`,
    actions: [{ name: "open", args: { url, label, auto: true } }],
    direct: true,
    exclusive: true,
  });

  const yt =
    text.match(/^(?:please\s+)?(?:search|look)\s+(?:on\s+|in\s+)?youtube\s+(?:for\s+)?(.+)$/i) ||
    text.match(/^(?:please\s+)?(?:search\s+youtube\s+for|youtube)\s+(.+)$/i) ||
    text.match(/^(?:please\s+)?play\s+(.+?)\s+on\s+youtube$/i);
  if (yt) return mk(`https://www.youtube.com/results?search_query=${encodeURIComponent(yt[1])}`, `YouTube: ${yt[1]}`);

  const sp = text.match(/^(?:please\s+)?play\s+(.+?)\s+on\s+spotify$/i);
  if (sp) return mk(`https://open.spotify.com/search/${encodeURIComponent(sp[1])}`, `Spotify: ${sp[1]}`);

  const g = text.match(/^(?:please\s+)?(?:google|search google for|google search for|search on google for)\s+(.+)$/i);
  if (g) return mk(`https://www.google.com/search?q=${encodeURIComponent(g[1])}`, `Google: ${g[1]}`);

  const o = text.match(
    /^(?:please\s+)?(?:open|launch|go to|goto|take me to|pull up|visit|bring up)\s+(?:up\s+)?(?:the\s+)?(?:website\s+|site\s+)?(.+?)(?:\s+(?:for me|please|website|site|in a new tab))*$/i,
  );
  if (o) {
    const target = o[1].trim().toLowerCase().replace(/^(?:https?:\/\/)?(?:www\.)?/, "");
    if (/^[a-z0-9-]+(?:\.[a-z0-9-]+)+(?:\/\S*)?$/.test(target)) return mk(`https://${target}`, target);
    const key = target.replace(/\.$/, "");
    if (SITES[key]) return mk(SITES[key], key);
  }
  return null;
};

const weatherSkill: Skill = async ({ text, city: defaultCity }) => {
  if (!/\b(?:weather|forecast|temperature|how (?:hot|cold|warm) is it|is it (?:raining|going to rain|hot|cold)|will it rain|umbrella)\b/i.test(text)) return null;
  const cm = text.match(
    /\b(?:in|at|for|of)\s+([A-Za-z][A-Za-z .'-]{1,40}?)(?=\s+(?:today|tonight|tomorrow|right now|now|please|this|later)\b|[?.!,]|$)/i,
  );
  let city = cm ? cm[1].trim() : "";
  if (!city || /^(?:the|my|this|here|outside|there|a|an|general|your)\b/i.test(city)) city = defaultCity || "Kuala Lumpur";
  const w = await getWeather(city);
  if (!w) {
    return {
      skill: "weather",
      context: `Weather for "${city}" not found.`,
      fallback: `Couldn't get weather for ${city}.`,
      actions: [],
      direct: true,
    };
  }
  const asksTomorrow = /\btomorrow\b/i.test(text) && w.tomorrow;
  const reply = asksTomorrow
    ? `Tomorrow in ${w.city}: ${w.tomorrow!.condition}, high of ${w.tomorrow!.highC}°C, low of ${w.tomorrow!.lowC}°C, ${w.tomorrow!.rainChance}% rain chance.`
    : `It's ${w.tempC}°C and ${w.condition} in ${w.city}, feels like ${w.feelsC}°C. High today is ${w.highC}°C with ${w.rainChance}% rain chance.`;

  return {
    skill: "weather",
    context: reply,
    fallback: reply,
    actions: [{ name: "refresh", args: { kind: "weather", city: w.city } }],
    direct: true,
    exclusive: true,
  };
};

const datetimeSkill: Skill = ({ text, tz }) => {
  const asksTime = /\b(?:what(?:'s| is)?\s+(?:the\s+)?(?:current\s+)?time|what time is it|time (?:is it|now)|tell me the time|got the time)\b/i.test(text);
  const asksDate = /\b(?:what(?:'s| is)?\s+(?:the\s+|today'?s\s+)?(?:date|day)|what day is (?:it|today)|today'?s date|what is today|what's today)\b/i.test(text);
  if (!asksTime && !asksDate) return null;
  const n = formatNow(tz);
  const parts: string[] = [];
  if (asksTime) parts.push(`It's ${n.time}`);
  if (asksDate) parts.push(`Today is ${n.day}, ${n.date}`);
  return {
    skill: "datetime",
    context: parts.join(". ") + ".",
    fallback: parts.join(". ") + ".",
    actions: [],
    direct: true,
    exclusive: true,
  };
};

const mathSkill: Skill = ({ text }) => {
  if (!/\d/.test(text)) return null;
  if (/\b(?:timer|remind|weather|minutes?|hours?|seconds?|task|note)\b/i.test(text)) return null;
  const r = evaluateNatural(text);
  if (!r) return null;
  const out = formatNumber(r.result);
  return {
    skill: "math",
    context: `${r.expression} = ${out}`,
    fallback: `${out}.`,
    actions: [],
    direct: true,
    exclusive: true,
  };
};

const funSkill: Skill = ({ text }) => {
  if (/\b(?:flip|toss)\s+(?:a\s+)?coin\b/i.test(text)) {
    const side = Math.random() < 0.5 ? "heads" : "tails";
    return { skill: "fun", context: `Coin flip: ${side}.`, fallback: `${side.toUpperCase()}.`, actions: [], direct: true, exclusive: true };
  }
  const die = text.match(/\broll\s+(?:a\s+|an\s+|the\s+)?(?:d(\d+)|(\d+)[- ]sided\s+)?(?:die|dice)\b/i);
  if (die) {
    const sides = Math.min(1000, Math.max(2, Number(die[1] ?? die[2] ?? 6)));
    const n = 1 + Math.floor(Math.random() * sides);
    return { skill: "fun", context: `Dice roll: ${n}.`, fallback: `Rolled a ${n}.`, actions: [], direct: true, exclusive: true };
  }
  const rnd = text.match(/\b(?:pick|give me|choose|say)\s+(?:a\s+)?(?:random\s+)?number\s+(?:between|from)\s+(-?\d+)\s+(?:and|to)\s+(-?\d+)/i);
  if (rnd) {
    const a = Math.min(Number(rnd[1]), Number(rnd[2]));
    const b = Math.max(Number(rnd[1]), Number(rnd[2]));
    const n = a + Math.floor(Math.random() * (b - a + 1));
    return { skill: "fun", context: `Random number: ${n}.`, fallback: `${n}.`, actions: [], direct: true, exclusive: true };
  }
  return null;
};

const diagnosticsSkill: Skill = async ({ uid, text, brainLabel, tz }) => {
  if (!/\b(?:run\s+(?:a\s+)?(?:system\s+)?diagnostics?|system status|status report|how are your systems|diagnostics)\b/i.test(text)) return null;
  const [tasks, notes, mem] = await Promise.all([store.listTasks(uid), store.listNotes(uid), store.listMemories(uid)]);
  const open = tasks.filter((t) => !t.done).length;
  const n = formatNow(tz);
  return {
    skill: "diagnostics",
    context: `Status: Language core ${brainLabel}, ${open} open tasks, ${notes.length} notes, ${mem.length} memories, local time ${n.time}. All systems nominal.`,
    fallback: `All systems nominal. Core: ${brainLabel}. ${open} open tasks, ${notes.length} notes, ${mem.length} memories.`,
    actions: [],
    direct: true,
    exclusive: true,
  };
};

const wikiSkill: Skill = async ({ text }) => {
  const m = text.match(
    /^(?:who(?:'s| is| was| are| were)|what(?:'s| is| are| was| were)|tell me about|explain|define|look up|lookup|search for|search up|search|wiki(?:pedia)?)\s+(?:a |an |the )?(.+)$/i,
  );
  if (!m) return null;
  const subject = m[1].trim();
  if (subject.split(/\s+/).length > 5 || subject.length < 3) return null;
  if (/^(?:you|your|yours|ada|syuhada|me|my|i|it|its|this|that|these|those|there|here|we|us|he|she|they|him|her|them|up|going|happening|wrong|new|next|good|bad|time|date|day|weather|love|life|for|so|your name|the meaning)\b/i.test(subject)) return null;
  const w = await wikiLookup(subject, 2500);
  if (!w || !titleMatches(subject, w.title)) return null;
  const sentences = w.extract.match(/[^.!?]+[.!?]+/g) ?? [w.extract];
  const summary = sentences.slice(0, 2).join(" ").trim();
  return {
    skill: "wiki",
    context: summary,
    fallback: summary,
    actions: [{ name: "open", args: { url: w.url, label: `Wikipedia: ${w.title}`, auto: false } }],
    direct: true,
    exclusive: true,
  };
};

const SKILLS: Skill[] = [
  stopSkill,
  clearSkill,
  timerSkill,
  tasksSkill,
  notesSkill,
  memorySkill,
  newsSkill,
  downloadSkill,
  openSkill,
  weatherSkill,
  datetimeSkill,
  mathSkill,
  funSkill,
  diagnosticsSkill,
];

export async function runSkills(ctx: SkillCtx): Promise<SkillResult[]> {
  const results: SkillResult[] = [];
  for (const skill of SKILLS) {
    try {
      const r = await skill(ctx);
      if (r) {
        results.push(r);
        if (r.exclusive) break;
      }
    } catch (err) {
      console.error("[skill error]", err);
    }
  }
  if (results.length === 0) {
    try {
      const w = await wikiSkill(ctx);
      if (w) results.push(w);
    } catch {
      /* ignore */
    }
  }
  return results;
}
