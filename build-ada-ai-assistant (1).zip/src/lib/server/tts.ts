import { MsEdgeTTS, OUTPUT_FORMAT } from "msedge-tts";

export type TtsProvider = "elevenlabs" | "openai" | "edge";

export function ttsProvider(): TtsProvider {
  const e = process.env;
  if (e.ELEVENLABS_API_KEY) return "elevenlabs";
  if (e.TTS_API_KEY || e.OPENAI_API_KEY) return "openai";
  return "edge";
}

/** Neural voices offered when the free engine is used. */
export const EDGE_VOICES = [
  { id: "en-US-AriaNeural", label: "Aria · bright, expressive (US)" },
  { id: "en-US-AvaNeural", label: "Ava · warm, natural (US)" },
  { id: "en-US-JennyNeural", label: "Jenny · friendly (US)" },
  { id: "en-US-EmmaNeural", label: "Emma · calm, clear (US)" },
  { id: "en-US-MichelleNeural", label: "Michelle · soft (US)" },
  { id: "en-US-AnaNeural", label: "Ana · young, cute (US)" },
  { id: "en-GB-SoniaNeural", label: "Sonia · British" },
  { id: "en-GB-LibbyNeural", label: "Libby · British, youthful" },
  { id: "en-AU-NatashaNeural", label: "Natasha · Australian" },
  { id: "ms-MY-YasminNeural", label: "Yasmin · Bahasa Melayu" },
] as const;

const MALAY_HINTS =
  /\b(?:saya|aku|awak|kamu|engkau|tak|tidak|yang|dan|ini|itu|apa|boleh|nak|dengan|untuk|kita|dia|lah|kan|je|jom|macam|sangat|terima kasih|selamat|boleh|tolong|bila|mana|siapa|kenapa|bagaimana|dah|sudah|belum|ada)\b/gi;

export function looksMalay(text: string): boolean {
  const hits = text.match(MALAY_HINTS);
  return !!hits && hits.length >= 2;
}

export async function edgeSynth(text: string, voice: string): Promise<Buffer> {
  const tts = new MsEdgeTTS({ connectionTimeoutMs: 8000, synthesisTimeoutMs: 15000 });
  try {
    await tts.setMetadata(voice, OUTPUT_FORMAT.AUDIO_24KHZ_48KBITRATE_MONO_MP3);
    const { audioStream } = tts.toStream(text, { pitch: "+8%", rate: "+6%" });
    const chunks: Buffer[] = [];
    await new Promise<void>((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("edge tts timeout")), 20000);
      audioStream.on("data", (d: Buffer) => chunks.push(d));
      audioStream.on("end", () => {
        clearTimeout(timer);
        resolve();
      });
      audioStream.on("close", () => {
        clearTimeout(timer);
        resolve();
      });
      audioStream.on("error", (err: Error) => {
        clearTimeout(timer);
        reject(err);
      });
    });
    const buf = Buffer.concat(chunks);
    if (buf.length < 200) throw new Error("empty audio");
    return buf;
  } finally {
    try {
      tts.close();
    } catch {
      /* ignore */
    }
  }
}

export async function elevenSynth(text: string): Promise<Buffer> {
  const voice = process.env.ELEVENLABS_VOICE_ID || "EXAVITQu4vr4xnSDxMaL";
  const res = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voice}?output_format=mp3_44100_64`, {
    method: "POST",
    headers: { "xi-api-key": process.env.ELEVENLABS_API_KEY ?? "", "Content-Type": "application/json" },
    body: JSON.stringify({
      text,
      model_id: process.env.ELEVENLABS_MODEL || "eleven_flash_v2_5",
      voice_settings: { stability: 0.4, similarity_boost: 0.8, style: 0.4 },
    }),
    signal: AbortSignal.timeout(20000),
  });
  if (!res.ok) throw new Error(`elevenlabs ${res.status}`);
  return Buffer.from(await res.arrayBuffer());
}

export async function openaiSynth(text: string): Promise<Buffer> {
  const base = (process.env.TTS_BASE_URL || "https://api.openai.com/v1").replace(/\/+$/, "");
  const model = process.env.TTS_MODEL || "gpt-4o-mini-tts";
  const res = await fetch(`${base}/audio/speech`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${process.env.TTS_API_KEY || process.env.OPENAI_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model,
      voice: process.env.TTS_VOICE || "nova",
      input: text,
      response_format: "mp3",
      ...(model.includes("gpt-4o")
        ? { instructions: "Speak like a bright, playful, quick-witted 19-year-old girl. Natural, casual, a little teasing." }
        : {}),
    }),
    signal: AbortSignal.timeout(20000),
  });
  if (!res.ok) throw new Error(`openai tts ${res.status}`);
  return Buffer.from(await res.arrayBuffer());
}
