export type Weather = {
  city: string;
  country: string;
  tempC: number;
  feelsC: number;
  humidity: number;
  windKph: number;
  isDay: boolean;
  condition: string;
  icon: string;
  highC: number;
  lowC: number;
  rainChance: number;
  tomorrow: { condition: string; highC: number; lowC: number; rainChance: number } | null;
};

const WMO: Record<number, [string, string, string?]> = {
  0: ["clear sky", "☀️", "🌙"],
  1: ["mostly clear", "🌤️", "🌙"],
  2: ["partly cloudy", "⛅", "☁️"],
  3: ["overcast", "☁️"],
  45: ["foggy", "🌫️"],
  48: ["foggy", "🌫️"],
  51: ["light drizzle", "🌦️"],
  53: ["drizzle", "🌦️"],
  55: ["heavy drizzle", "🌧️"],
  56: ["freezing drizzle", "🌧️"],
  57: ["freezing drizzle", "🌧️"],
  61: ["light rain", "🌦️"],
  63: ["rain", "🌧️"],
  65: ["heavy rain", "🌧️"],
  66: ["freezing rain", "🌧️"],
  67: ["freezing rain", "🌧️"],
  71: ["light snow", "🌨️"],
  73: ["snow", "❄️"],
  75: ["heavy snow", "❄️"],
  77: ["snow grains", "❄️"],
  80: ["rain showers", "🌦️"],
  81: ["rain showers", "🌧️"],
  82: ["violent rain showers", "⛈️"],
  85: ["snow showers", "🌨️"],
  86: ["snow showers", "🌨️"],
  95: ["thunderstorm", "⛈️"],
  96: ["thunderstorm with hail", "⛈️"],
  99: ["thunderstorm with hail", "⛈️"],
};

function describe(code: number, isDay: boolean): { condition: string; icon: string } {
  const entry = WMO[code] ?? ["unsettled weather", "🌡️"];
  return { condition: entry[0], icon: !isDay && entry[2] ? entry[2] : entry[1] };
}

const cache = new Map<string, { at: number; data: Weather | null }>();
const TTL = 10 * 60 * 1000;

async function getJson(url: string, timeoutMs = 6000) {
  const res = await fetch(url, { signal: AbortSignal.timeout(timeoutMs), cache: "no-store" });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

export async function getWeather(cityInput: string): Promise<Weather | null> {
  const city = cityInput.trim().slice(0, 80);
  if (!city) return null;
  const key = city.toLowerCase();
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < TTL) return hit.data;

  try {
    const geo = await getJson(
      `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1&language=en&format=json`,
    );
    const place = geo?.results?.[0];
    if (!place) {
      cache.set(key, { at: Date.now(), data: null });
      return null;
    }
    const f = await getJson(
      `https://api.open-meteo.com/v1/forecast?latitude=${place.latitude}&longitude=${place.longitude}` +
        `&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m,is_day` +
        `&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max` +
        `&timezone=auto&forecast_days=2`,
    );
    const c = f.current;
    const d = f.daily;
    const isDay = c.is_day === 1;
    const now = describe(c.weather_code, isDay);
    const tomorrow = d?.time?.[1]
      ? {
          condition: describe(d.weather_code[1], true).condition,
          highC: Math.round(d.temperature_2m_max[1]),
          lowC: Math.round(d.temperature_2m_min[1]),
          rainChance: Math.round(d.precipitation_probability_max?.[1] ?? 0),
        }
      : null;
    const data: Weather = {
      city: place.name,
      country: place.country ?? "",
      tempC: Math.round(c.temperature_2m),
      feelsC: Math.round(c.apparent_temperature),
      humidity: Math.round(c.relative_humidity_2m),
      windKph: Math.round(c.wind_speed_10m),
      isDay,
      condition: now.condition,
      icon: now.icon,
      highC: Math.round(d.temperature_2m_max[0]),
      lowC: Math.round(d.temperature_2m_min[0]),
      rainChance: Math.round(d.precipitation_probability_max?.[0] ?? 0),
      tomorrow,
    };
    cache.set(key, { at: Date.now(), data });
    return data;
  } catch {
    return hit?.data ?? null;
  }
}
