// OpenAI-compatible chat API client. Provider-specific defaults live here so stale
// model IDs and mismatched request parameters don't make pasted keys fail silently.

export type ClientLlmConfig = {
  provider?: string;
  apiKey?: string;
  model?: string;
  baseUrl?: string;
};

export type MaxTokenParameter = "max_tokens" | "max_completion_tokens";

export type LlmConfig = {
  id: string;
  label: string;
  baseUrl: string;
  apiKey?: string;
  model: string;
  headers?: Record<string, string>;
  maxTokenParameter?: MaxTokenParameter;
  reasoningEffort?: string;
};

export type ChatMessage = { role: "system" | "user" | "assistant"; content: string };

export class ProviderError extends Error {
  provider: string;
  status?: number;
  code?: string;

  constructor(provider: string, message: string, status?: number, code?: string) {
    super(message);
    this.name = "ProviderError";
    this.provider = provider;
    this.status = status;
    this.code = code;
  }
}

const trim = (u: string) => u.trim().replace(/\/+$/, "");

function normalizeBaseUrl(value: string): string {
  const base = trim(value);
  return base.replace(/\/chat\/completions$/i, "");
}

function createClientConfig(clientCfg: ClientLlmConfig): LlmConfig {
  const provider = (clientCfg.provider || "groq").trim().toLowerCase();
  const apiKey = (clientCfg.apiKey || "").trim();
  const model = (clientCfg.model || "").trim();

  const cfg = (values: Omit<LlmConfig, "apiKey">): LlmConfig => ({ ...values, apiKey: apiKey || undefined });

  switch (provider) {
    case "groq":
      return cfg({
        id: "groq-user",
        label: model || "openai/gpt-oss-20b",
        baseUrl: "https://api.groq.com/openai/v1",
        model: model || "openai/gpt-oss-20b",
        maxTokenParameter: "max_completion_tokens",
        reasoningEffort: "low",
      });

    case "gemini":
      return cfg({
        id: "gemini-user",
        label: model || "gemini-2.5-flash",
        baseUrl: "https://generativelanguage.googleapis.com/v1beta/openai",
        model: model || "gemini-2.5-flash",
        maxTokenParameter: "max_tokens",
        reasoningEffort: "none",
      });

    case "openrouter":
      return cfg({
        id: "openrouter-user",
        label: model || "openrouter/free",
        baseUrl: "https://openrouter.ai/api/v1",
        model: model || "openrouter/free",
        maxTokenParameter: "max_tokens",
        headers: {
          "HTTP-Referer": process.env.NEXT_PUBLIC_APP_URL || "https://ada-assistant.app",
          "X-OpenRouter-Title": "Ada Personal Assistant",
        },
      });

    case "huggingface":
      return cfg({
        id: "huggingface-user",
        label: model || "openai/gpt-oss-120b:fastest",
        baseUrl: "https://router.huggingface.co/v1",
        model: model || "openai/gpt-oss-120b:fastest",
        maxTokenParameter: "max_tokens",
      });

    case "ollama":
      return cfg({
        id: "ollama-user",
        label: model || "llama3.2",
        baseUrl: normalizeBaseUrl(clientCfg.baseUrl || "http://localhost:11434/v1"),
        model: model || "llama3.2",
        maxTokenParameter: "max_tokens",
      });

    case "openai":
      return cfg({
        id: "openai-user",
        label: model || "gpt-4o-mini",
        baseUrl: "https://api.openai.com/v1",
        model: model || "gpt-4o-mini",
        maxTokenParameter: "max_completion_tokens",
      });

    case "deepseek":
      return cfg({
        id: "deepseek-user",
        label: model || "deepseek-chat",
        baseUrl: "https://api.deepseek.com/v1",
        model: model || "deepseek-chat",
        maxTokenParameter: "max_tokens",
      });

    case "custom":
      if (!clientCfg.baseUrl?.trim()) {
        throw new ProviderError("Custom endpoint", "Enter the OpenAI-compatible API base URL (for example, https://api.example.com/v1).", 400);
      }
      return cfg({
        id: "custom-user",
        label: model || "custom model",
        baseUrl: normalizeBaseUrl(clientCfg.baseUrl),
        model: model || "gpt-4o-mini",
        maxTokenParameter: "max_tokens",
      });

    case "github":
      throw new ProviderError(
        "GitHub Models",
        "GitHub Models was retired. Select Groq, Gemini, OpenRouter, or Hugging Face in Settings.",
        410,
      );

    default:
      throw new ProviderError(
        provider || "AI provider",
        `Unknown provider “${provider}”. Choose a provider again in Settings.`,
        400,
      );
  }
}

/** A user-selected key is tried on its selected provider only; never send it to another API. */
export function llmChain(clientCfg?: ClientLlmConfig): LlmConfig[] {
  if (clientCfg) {
    const provider = (clientCfg.provider || "groq").toLowerCase();
    const keyRequired = provider !== "ollama";
    if (keyRequired && !clientCfg.apiKey?.trim()) {
      throw new ProviderError(provider, "Paste an API key for the selected provider.", 400);
    }
    return [createClientConfig(clientCfg)];
  }

  const e = process.env;
  const chain: LlmConfig[] = [];
  if (e.LLM_DISABLED === "1") return chain;

  if (e.GROQ_API_KEY) {
    const model = e.GROQ_MODEL || "openai/gpt-oss-20b";
    chain.push({
      id: "groq",
      label: model,
      baseUrl: "https://api.groq.com/openai/v1",
      apiKey: e.GROQ_API_KEY,
      model,
      maxTokenParameter: "max_completion_tokens",
      reasoningEffort: "low",
    });
  }
  if (e.GEMINI_API_KEY) {
    const model = e.GEMINI_MODEL || "gemini-2.5-flash";
    chain.push({
      id: "gemini",
      label: model,
      baseUrl: "https://generativelanguage.googleapis.com/v1beta/openai",
      apiKey: e.GEMINI_API_KEY,
      model,
      maxTokenParameter: "max_tokens",
    });
  }
  if (e.OPENROUTER_API_KEY) {
    const model = e.OPENROUTER_MODEL || "openrouter/free";
    chain.push({
      id: "openrouter",
      label: model,
      baseUrl: "https://openrouter.ai/api/v1",
      apiKey: e.OPENROUTER_API_KEY,
      model,
      maxTokenParameter: "max_tokens",
      headers: {
        "HTTP-Referer": process.env.NEXT_PUBLIC_APP_URL || "https://ada-assistant.app",
        "X-OpenRouter-Title": "Ada Personal Assistant",
      },
    });
  }
  if (e.HF_TOKEN || e.HUGGINGFACE_API_KEY) {
    const model = e.HF_MODEL || "openai/gpt-oss-120b:fastest";
    chain.push({
      id: "huggingface",
      label: model,
      baseUrl: "https://router.huggingface.co/v1",
      apiKey: e.HF_TOKEN || e.HUGGINGFACE_API_KEY,
      model,
      maxTokenParameter: "max_tokens",
    });
  }
  if (e.OPENAI_API_KEY) {
    const model = e.OPENAI_MODEL || "gpt-4o-mini";
    chain.push({
      id: "openai",
      label: model,
      baseUrl: "https://api.openai.com/v1",
      apiKey: e.OPENAI_API_KEY,
      model,
      maxTokenParameter: "max_completion_tokens",
    });
  }
  if (e.DEEPSEEK_API_KEY) {
    const model = e.DEEPSEEK_MODEL || "deepseek-chat",
      baseUrl = trim(e.DEEPSEEK_BASE_URL || "https://api.deepseek.com/v1");
    chain.push({ id: "deepseek", label: model, baseUrl, apiKey: e.DEEPSEEK_API_KEY, model, maxTokenParameter: "max_tokens" });
  }
  if (e.LLM_API_KEY) {
    const model = e.LLM_MODEL || "gpt-4o-mini";
    chain.push({
      id: e.LLM_PROVIDER || "custom",
      label: model,
      baseUrl: normalizeBaseUrl(e.LLM_BASE_URL || "https://api.openai.com/v1"),
      apiKey: e.LLM_API_KEY,
      model,
      maxTokenParameter: "max_tokens",
    });
  }

  // Optional no-key fallback. It may be rate-limited; local brain remains available.
  if (e.LLM_FREE_FALLBACK !== "0") {
    chain.push({
      id: "free",
      label: "anonymous cloud fallback",
      baseUrl: "https://text.pollinations.ai/openai",
      model: "openai-fast",
      maxTokenParameter: "max_tokens",
    });
  }
  return chain;
}

function providerLabel(id: string): string {
  if (id.startsWith("groq")) return "Groq";
  if (id.startsWith("gemini")) return "Google Gemini";
  if (id.startsWith("openrouter")) return "OpenRouter";
  if (id.startsWith("huggingface")) return "Hugging Face";
  if (id.startsWith("ollama")) return "Ollama";
  if (id.startsWith("openai")) return "OpenAI";
  if (id.startsWith("deepseek")) return "DeepSeek";
  if (id === "free") return "Free cloud fallback";
  return "Custom API";
}

function readUpstreamMessage(body: string): { message: string; code?: string } {
  try {
    const json = JSON.parse(body) as { error?: unknown; message?: unknown; code?: unknown };
    const err = json.error;
    if (typeof err === "string") return { message: err };
    if (err && typeof err === "object") {
      const detail = err as { message?: unknown; code?: unknown; type?: unknown };
      return {
        message: typeof detail.message === "string" ? detail.message : JSON.stringify(err),
        code: typeof detail.code === "string" ? detail.code : typeof detail.type === "string" ? detail.type : undefined,
      };
    }
    return {
      message: typeof json.message === "string" ? json.message : body,
      code: typeof json.code === "string" ? json.code : undefined,
    };
  } catch {
    return { message: body };
  }
}

function friendlyHttpError(cfg: LlmConfig, status: number, body: string): ProviderError {
  const provider = providerLabel(cfg.id);
  const upstream = readUpstreamMessage(body);
  const detail = upstream.message.replace(cfg.apiKey || "\0", "[redacted]").replace(/\s+/g, " ").slice(0, 260);
  const code = upstream.code;
  const authError = /api key|invalid key|valid key|credential|unauthori[sz]ed|authentication|invalid token/i.test(`${detail} ${code || ""}`);

  if (status === 401 || (authError && status >= 400 && status < 500)) return new ProviderError(provider, `${provider} rejected the API key. Check that it is complete, active, and belongs to this provider.`, status, code);
  if (status === 403) return new ProviderError(provider, `${provider} denied access. Check the key's permissions, project access, free-tier eligibility, or billing status. ${detail}`, status, code);
  if (status === 404) return new ProviderError(provider, `${provider} could not find the selected model or API endpoint (“${cfg.model}”). Pick a currently available model in Settings.`, status, code);
  if (status === 402) return new ProviderError(provider, `${provider} requires available credits or the selected model is not free. Check the provider account or choose its free model. ${detail}`, status, code);
  if (status === 429) return new ProviderError(provider, `${provider} rate limit reached. Wait a bit, or use another provider/model. ${detail}`, status, code);
  if (status === 400 || status === 422) return new ProviderError(provider, `${provider} rejected this model or request: ${detail}`, status, code);
  if (status >= 500) return new ProviderError(provider, `${provider} is temporarily unavailable (HTTP ${status}). Try again shortly.`, status, code);
  return new ProviderError(provider, `${provider} returned HTTP ${status}: ${detail}`, status, code);
}

export function explainProviderError(error: unknown, cfg?: LlmConfig): string {
  if (error instanceof ProviderError) return error.message;
  if (error instanceof DOMException && error.name === "AbortError") {
    return `${cfg ? providerLabel(cfg.id) : "AI provider"} timed out before replying. Check your connection or try another model.`;
  }
  if (error instanceof Error && (error.name === "TypeError" || /fetch failed|network/i.test(error.message))) {
    return `${cfg ? providerLabel(cfg.id) : "AI provider"} could not be reached. Check the endpoint and your internet connection.`;
  }
  return `${cfg ? providerLabel(cfg.id) : "AI provider"} failed. Check the key, model and provider settings.`;
}

export async function* streamChat(
  cfg: LlmConfig,
  messages: ChatMessage[],
  signal?: AbortSignal,
): AsyncGenerator<string> {
  const ctrl = new AbortController();
  const onAbort = () => ctrl.abort();
  signal?.addEventListener("abort", onAbort);
  const initialBudget = cfg.id === "free" ? 8000 : 30000;
  let timer = setTimeout(() => ctrl.abort(), initialBudget);
  const endpoint = cfg.id === "free" ? cfg.baseUrl : `${normalizeBaseUrl(cfg.baseUrl)}/chat/completions`;
  let gotToken = false;

  try {
    const body: Record<string, unknown> = {
      model: cfg.model,
      messages,
      stream: true,
      temperature: 0.45,
      [cfg.maxTokenParameter || "max_tokens"]: 320,
    };
    if (cfg.reasoningEffort) body.reasoning_effort = cfg.reasoningEffort;

    const res = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(cfg.apiKey ? { Authorization: `Bearer ${cfg.apiKey}` } : {}),
        ...(cfg.headers || {}),
      },
      body: JSON.stringify(body),
      signal: ctrl.signal,
    });

    if (!res.ok || !res.body) {
      const detail = await res.text().catch(() => "");
      throw friendlyHttpError(cfg, res.status, detail);
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";

    const parseLine = (line: string): string | null => {
      const trimmed = line.trim();
      if (!trimmed.startsWith("data:")) return null;
      const data = trimmed.slice(5).trim();
      if (!data || data === "[DONE]") return null;
      let json: { choices?: Array<{ delta?: { content?: unknown }; message?: { content?: unknown } }>; error?: unknown };
      try {
        json = JSON.parse(data);
      } catch {
        return null;
      }
      if (json.error) {
        const msg = typeof json.error === "string" ? json.error : JSON.stringify(json.error);
        throw new ProviderError(providerLabel(cfg.id), `${providerLabel(cfg.id)} stream error: ${msg.slice(0, 240)}`);
      }
      const value = json.choices?.[0]?.delta?.content ?? json.choices?.[0]?.message?.content;
      return typeof value === "string" && value ? value : null;
    };

    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      let newline: number;
      while ((newline = buffer.indexOf("\n")) !== -1) {
        const line = buffer.slice(0, newline);
        buffer = buffer.slice(newline + 1);
        const text = parseLine(line);
        if (text) {
          if (!gotToken) {
            gotToken = true;
            clearTimeout(timer);
            timer = setTimeout(() => ctrl.abort(), 30000);
          }
          yield text;
        }
      }
    }

    if (buffer.trim()) {
      const text = parseLine(buffer);
      if (text) {
        gotToken = true;
        yield text;
      }
    }
    if (!gotToken) {
      throw new ProviderError(providerLabel(cfg.id), `${providerLabel(cfg.id)} returned no text. Check that the model supports chat completions and streaming.`);
    }
  } catch (error) {
    if (signal?.aborted) throw error;
    if (ctrl.signal.aborted) {
      throw new ProviderError(providerLabel(cfg.id), `${providerLabel(cfg.id)} timed out before completing the request.`);
    }
    if (error instanceof ProviderError) throw error;
    if (error instanceof Error && error.name === "AbortError") {
      throw new ProviderError(providerLabel(cfg.id), `${providerLabel(cfg.id)} timed out before replying.`);
    }
    if (error instanceof TypeError) {
      throw new ProviderError(providerLabel(cfg.id), `${providerLabel(cfg.id)} could not be reached. Check the endpoint and internet connection.`);
    }
    throw error;
  } finally {
    clearTimeout(timer);
    signal?.removeEventListener("abort", onAbort);
    ctrl.abort();
  }
}
