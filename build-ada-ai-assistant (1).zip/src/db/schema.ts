import { boolean, index, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

// Every row is scoped to an anonymous device id (generated in the browser),
// so one deployment can serve several people without mixing their data.

export const messages = pgTable(
  "messages",
  {
    id: serial("id").primaryKey(),
    userId: text("user_id").notNull(),
    role: text("role").notNull(), // "user" | "assistant"
    content: text("content").notNull(),
    emotion: text("emotion"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (t) => [index("messages_user_idx").on(t.userId, t.id)],
);

export const tasks = pgTable(
  "tasks",
  {
    id: serial("id").primaryKey(),
    userId: text("user_id").notNull(),
    text: text("text").notNull(),
    done: boolean("done").default(false).notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (t) => [index("tasks_user_idx").on(t.userId)],
);

export const notes = pgTable(
  "notes",
  {
    id: serial("id").primaryKey(),
    userId: text("user_id").notNull(),
    text: text("text").notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (t) => [index("notes_user_idx").on(t.userId)],
);

export const memories = pgTable(
  "memories",
  {
    id: serial("id").primaryKey(),
    userId: text("user_id").notNull(),
    fact: text("fact").notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (t) => [index("memories_user_idx").on(t.userId)],
);

export type Message = typeof messages.$inferSelect;
export type Task = typeof tasks.$inferSelect;
export type Note = typeof notes.$inferSelect;
export type Memory = typeof memories.$inferSelect;
