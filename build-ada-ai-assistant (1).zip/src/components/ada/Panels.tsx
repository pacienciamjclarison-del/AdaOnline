"use client";

import { useState } from "react";
import { Brain, Check, Plus, StickyNote, Trash2 } from "lucide-react";
import type { MemoryItem, NoteItem, TaskItem } from "@/lib/client/types";

function AddForm({ placeholder, onAdd, multiline }: { placeholder: string; onAdd: (t: string) => void; multiline?: boolean }) {
  const [v, setV] = useState("");
  const submit = () => {
    if (!v.trim()) return;
    onAdd(v.trim());
    setV("");
  };
  return (
    <form
      className="flex gap-2"
      onSubmit={(e) => {
        e.preventDefault();
        submit();
      }}
    >
      {multiline ? (
        <textarea
          value={v}
          onChange={(e) => setV(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              submit();
            }
          }}
          rows={2}
          placeholder={placeholder}
          className="min-w-0 flex-1 resize-none rounded-xl border border-white/10 bg-black/30 px-3 py-2 text-sm text-white outline-none placeholder:text-slate-500 focus:border-cyan-400/50"
        />
      ) : (
        <input
          value={v}
          onChange={(e) => setV(e.target.value)}
          placeholder={placeholder}
          className="min-w-0 flex-1 rounded-xl border border-white/10 bg-black/30 px-3 py-2 text-sm text-white outline-none placeholder:text-slate-500 focus:border-cyan-400/50"
        />
      )}
      <button className="grid w-10 shrink-0 place-items-center rounded-xl bg-cyan-400/15 text-cyan-200 hover:bg-cyan-400/25" aria-label="Add">
        <Plus size={18} />
      </button>
    </form>
  );
}

function Empty({ icon, title, hint }: { icon: React.ReactNode; title: string; hint: string }) {
  return (
    <div className="mt-8 flex flex-col items-center gap-2 px-6 text-center text-slate-500">
      <div className="grid h-12 w-12 place-items-center rounded-2xl bg-white/5 text-cyan-300/70">{icon}</div>
      <p className="text-sm font-medium text-slate-300">{title}</p>
      <p className="text-xs leading-relaxed">{hint}</p>
    </div>
  );
}

export function TasksPanel({
  tasks,
  onAdd,
  onToggle,
  onDelete,
  onClearDone,
}: {
  tasks: TaskItem[];
  onAdd: (t: string) => void;
  onToggle: (id: number, done: boolean) => void;
  onDelete: (id: number) => void;
  onClearDone: () => void;
}) {
  const doneCount = tasks.filter((t) => t.done).length;
  return (
    <div className="flex h-full min-h-0 flex-col gap-3 p-3">
      <AddForm placeholder="Add a task…  or just tell Ada" onAdd={onAdd} />
      <div className="min-h-0 flex-1 overflow-y-auto pr-1">
        {tasks.length === 0 ? (
          <Empty icon={<Check size={22} />} title="Nothing to do. Suspicious." hint="Say “add buy milk to my to-do list” and I'll keep track." />
        ) : (
          <ul className="space-y-2">
            {tasks.map((t, i) => (
              <li key={t.id} className="group flex items-center gap-3 rounded-xl bg-white/5 px-3 py-2.5">
                <button
                  onClick={() => onToggle(t.id, !t.done)}
                  className={`grid h-5 w-5 shrink-0 place-items-center rounded-md border transition ${t.done ? "border-cyan-300 bg-cyan-300 text-slate-900" : "border-slate-500 hover:border-cyan-300"}`}
                  aria-label={t.done ? "Mark as not done" : "Mark as done"}
                >
                  {t.done && <Check size={13} strokeWidth={3} />}
                </button>
                <span className={`flex-1 text-sm ${t.done ? "text-slate-500 line-through" : "text-slate-100"}`}>
                  {!t.done && <span className="mr-2 font-mono text-xs text-cyan-300/60">{tasks.filter((x) => !x.done).indexOf(t) + 1}</span>}
                  {t.text}
                </span>
                <button onClick={() => onDelete(t.id)} className="text-slate-600 opacity-0 transition hover:text-rose-300 group-hover:opacity-100 max-lg:opacity-100" aria-label="Delete task">
                  <Trash2 size={15} />
                </button>
                <span className="hidden">{i}</span>
              </li>
            ))}
          </ul>
        )}
      </div>
      {doneCount > 0 && (
        <button onClick={onClearDone} className="self-start text-xs text-slate-400 hover:text-cyan-300">
          Clear {doneCount} completed
        </button>
      )}
    </div>
  );
}

export function NotesPanel({ notes, onAdd, onDelete }: { notes: NoteItem[]; onAdd: (t: string) => void; onDelete: (id: number) => void }) {
  return (
    <div className="flex h-full min-h-0 flex-col gap-3 p-3">
      <AddForm multiline placeholder="Write a note…  Enter to save" onAdd={onAdd} />
      <div className="min-h-0 flex-1 overflow-y-auto pr-1">
        {notes.length === 0 ? (
          <Empty icon={<StickyNote size={22} />} title="No notes yet" hint="Say “take a note that the wifi password is on the fridge”." />
        ) : (
          <ul className="space-y-2">
            {notes.map((n) => (
              <li key={n.id} className="group rounded-xl border border-amber-200/10 bg-amber-200/[0.06] p-3">
                <p className="whitespace-pre-wrap text-sm text-slate-100">{n.text}</p>
                <div className="mt-2 flex items-center justify-between text-[11px] text-slate-500">
                  <span>{new Date(n.createdAt).toLocaleString([], { dateStyle: "medium", timeStyle: "short" })}</span>
                  <button onClick={() => onDelete(n.id)} className="hover:text-rose-300" aria-label="Delete note">
                    <Trash2 size={14} />
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

export function MemoryPanel({
  memories,
  onAdd,
  onDelete,
  onClear,
}: {
  memories: MemoryItem[];
  onAdd: (t: string) => void;
  onDelete: (id: number) => void;
  onClear: () => void;
}) {
  return (
    <div className="flex h-full min-h-0 flex-col gap-3 p-3">
      <AddForm placeholder="Tell Ada something to remember…" onAdd={onAdd} />
      <div className="min-h-0 flex-1 overflow-y-auto pr-1">
        {memories.length === 0 ? (
          <Empty icon={<Brain size={22} />} title="I don't know you yet" hint="Say “my name is …” or “remember that I love teh tarik”. I also pick up important things on my own." />
        ) : (
          <ul className="space-y-2">
            {memories.map((m) => (
              <li key={m.id} className="group flex items-start gap-3 rounded-xl bg-pink-400/[0.07] px-3 py-2.5">
                <Brain size={15} className="mt-0.5 shrink-0 text-pink-300/80" />
                <span className="flex-1 text-sm text-slate-100">{m.fact}</span>
                <button onClick={() => onDelete(m.id)} className="text-slate-600 opacity-0 transition hover:text-rose-300 group-hover:opacity-100 max-lg:opacity-100" aria-label="Forget this">
                  <Trash2 size={15} />
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
      {memories.length > 0 && (
        <button onClick={onClear} className="self-start text-xs text-slate-400 hover:text-rose-300">
          Forget everything
        </button>
      )}
    </div>
  );
}
