"use client";

import { useEffect, useState } from "react";
import { Check, Copy, Download, ExternalLink, Laptop, Monitor, Smartphone, Terminal, X, Zap } from "lucide-react";

type Props = {
  open: boolean;
  onClose: () => void;
};

export default function DownloadModal({ open, onClose }: Props) {
  const [tab, setTab] = useState<"pwa" | "android" | "desktop">("pwa");
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstallable, setIsInstallable] = useState(false);
  const [installed, setInstalled] = useState(false);
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);

  useEffect(() => {
    const handleBeforeInstall = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setIsInstallable(true);
    };

    window.addEventListener("beforeinstallprompt", handleBeforeInstall);
    window.addEventListener("appinstalled", () => {
      setInstalled(true);
      setIsInstallable(false);
    });

    // Check if already in standalone mode
    if (window.matchMedia("(display-mode: standalone)").matches) {
      setInstalled(true);
    }

    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstall);
    };
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === "accepted") {
      setInstalled(true);
    }
    setDeferredPrompt(null);
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCmd(id);
    setTimeout(() => setCopiedCmd(null), 2000);
  };

  if (!open) return null;

  const currentUrl = typeof window !== "undefined" ? window.location.origin : "https://your-ada-site.com";

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/80 p-4 backdrop-blur-md" onClick={onClose}>
      <div
        className="max-h-[92dvh] w-full max-w-xl overflow-y-auto rounded-3xl border border-cyan-300/30 bg-[#091024] p-6 shadow-[0_0_80px_rgba(34,211,238,0.2)]"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-label="Download Ada App"
      >
        <div className="mb-4 flex items-center justify-between border-b border-white/10 pb-3">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-cyan-400 to-fuchsia-400 text-lg font-black text-slate-900 shadow-[0_0_20px_rgba(34,211,238,0.4)]">
              <Download size={20} />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Download & Install Ada</h2>
              <p className="text-xs text-slate-400">Run Ada as a standalone Desktop or Mobile App</p>
            </div>
          </div>
          <button onClick={onClose} className="rounded-full p-2 text-slate-400 hover:bg-white/10 hover:text-white" aria-label="Close modal">
            <X size={18} />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="mb-5 flex rounded-xl border border-white/10 bg-black/40 p-1">
          <button
            onClick={() => setTab("pwa")}
            className={`flex flex-1 items-center justify-center gap-2 rounded-lg py-2 text-xs font-semibold transition ${
              tab === "pwa" ? "bg-cyan-400 text-slate-950 shadow-[0_0_15px_rgba(34,211,238,0.3)]" : "text-slate-400 hover:text-slate-200"
            }`}
          >
            <Smartphone size={14} /> 1-Click Install (PWA)
          </button>
          <button
            onClick={() => setTab("android")}
            className={`flex flex-1 items-center justify-center gap-2 rounded-lg py-2 text-xs font-semibold transition ${
              tab === "android" ? "bg-emerald-400 text-slate-950 shadow-[0_0_15px_rgba(52,211,153,0.3)]" : "text-slate-400 hover:text-slate-200"
            }`}
          >
            <Smartphone size={14} /> Android APK
          </button>
          <button
            onClick={() => setTab("desktop")}
            className={`flex flex-1 items-center justify-center gap-2 rounded-lg py-2 text-xs font-semibold transition ${
              tab === "desktop" ? "bg-cyan-400 text-slate-950 shadow-[0_0_15px_rgba(34,211,238,0.3)]" : "text-slate-400 hover:text-slate-200"
            }`}
          >
            <Laptop size={14} /> Desktop
          </button>
        </div>

        {/* 1. 1-CLICK PWA INSTALL */}
        {tab === "pwa" && (
          <div className="space-y-4">
            <div className="rounded-2xl border border-cyan-400/30 bg-gradient-to-b from-cyan-950/40 via-cyan-900/10 to-transparent p-5">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white">Install to Desktop & Mobile</h3>
                  <p className="mt-0.5 text-xs text-slate-300">
                    Runs in its own window with a homescreen icon. The PWA accepts explicit shares; live Android notification access requires the native APK and your separate system permission.
                  </p>
                </div>
                <span className="rounded-full bg-emerald-500/20 px-2.5 py-1 text-[11px] font-bold text-emerald-300 ring-1 ring-emerald-400/40">
                  Instant
                </span>
              </div>

              <div className="mt-4 flex flex-col gap-2">
                {isInstallable ? (
                  <button
                    onClick={handleInstallClick}
                    className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-cyan-400 to-fuchsia-400 py-3 text-sm font-bold text-slate-950 shadow-[0_0_30px_rgba(34,211,238,0.4)] transition hover:scale-[1.02]"
                  >
                    <Download size={16} /> Install Ada to Your Device Now
                  </button>
                ) : installed ? (
                  <div className="flex items-center justify-center gap-2 rounded-xl bg-emerald-500/20 py-2.5 text-xs font-bold text-emerald-200 ring-1 ring-emerald-400/30">
                    <Check size={16} /> Ada is already installed on this device!
                  </div>
                ) : null}
              </div>
            </div>

            {/* Platform specific guides */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-cyan-300/80">How to install manually on any browser:</h4>

              <div className="grid gap-2 text-xs sm:grid-cols-2">
                {/* Chrome / Edge on Windows & Mac */}
                <div className="rounded-xl border border-white/10 bg-black/40 p-3.5">
                  <p className="font-semibold text-white flex items-center gap-1.5">
                    <Monitor size={14} className="text-cyan-300" /> Chrome / Edge (PC & Mac)
                  </p>
                  <ol className="mt-2 list-decimal space-y-1 pl-4 text-slate-300">
                    <li>Look at your browser's address bar (top right).</li>
                    <li>Click the <strong>Install / App icon (⊕)</strong>.</li>
                    <li>Click <strong>Install</strong> to add Ada to your desktop / taskbar.</li>
                  </ol>
                </div>

                {/* iPhone / iPad Safari */}
                <div className="rounded-xl border border-white/10 bg-black/40 p-3.5">
                  <p className="font-semibold text-white flex items-center gap-1.5">
                    <Smartphone size={14} className="text-fuchsia-300" /> iPhone / iPad (Safari)
                  </p>
                  <ol className="mt-2 list-decimal space-y-1 pl-4 text-slate-300">
                    <li>Open this page in <strong>Safari</strong>.</li>
                    <li>Tap the <strong>Share button</strong> (box with arrow).</li>
                    <li>Scroll down and tap <strong>Add to Home Screen</strong>.</li>
                  </ol>
                </div>

                {/* Android Chrome */}
                <div className="rounded-xl border border-white/10 bg-black/40 p-3.5">
                  <p className="font-semibold text-white flex items-center gap-1.5">
                    <Smartphone size={14} className="text-emerald-300" /> Android (Chrome)
                  </p>
                  <ol className="mt-2 list-decimal space-y-1 pl-4 text-slate-300">
                    <li>Tap the <strong>three dots (⋮)</strong> at top right.</li>
                    <li>Tap <strong>Install app</strong> or <strong>Add to Home Screen</strong>.</li>
                    <li>Ada appears as an installable web app.</li>
                    <li>To share text, use an app's <strong>Share</strong> action and choose <strong>Ada</strong>; review the preview and tap React.</li>
                    <li>Notifications without a Share action can be copied and pasted into Ada's chat. Ada cannot read the tray automatically.</li>
                  </ol>
                </div>

                {/* macOS Safari */}
                <div className="rounded-xl border border-white/10 bg-black/40 p-3.5">
                  <p className="font-semibold text-white flex items-center gap-1.5">
                    <Laptop size={14} className="text-blue-300" /> Mac (Safari on Sonoma+)
                  </p>
                  <ol className="mt-2 list-decimal space-y-1 pl-4 text-slate-300">
                    <li>In Safari menu bar, click <strong>File</strong>.</li>
                    <li>Select <strong>Add to Dock...</strong></li>
                    <li>Launch Ada straight from your Mac Dock.</li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
        )}

        {tab === "android" && (
          <div className="space-y-4">
            <section className="rounded-2xl border border-emerald-400/25 bg-emerald-950/20 p-4">
              <h3 className="text-sm font-bold text-white">Native Android companion · APK</h3>
              <p className="mt-2 text-xs leading-relaxed text-slate-300">
                This Android companion wraps Ada and adds an optional NotificationListenerService. Build the debug-signed APK for your own HTTPS deployment; a Play Store release needs your own release-signing key.
              </p>
              <a href="/downloads/ada-android-source.zip" download className="mt-3 inline-flex items-center gap-2 rounded-xl bg-emerald-400 px-4 py-2 text-xs font-bold text-slate-950 hover:bg-emerald-300">
                <Download size={14} /> Download Android project source
              </a>
            </section>

            <section className="rounded-2xl border border-white/10 bg-black/40 p-4">
              <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-300">Build an APK in GitHub Actions (no Android SDK on your PC)</h4>
              <ol className="mt-2 list-decimal space-y-1.5 pl-4 text-xs leading-relaxed text-slate-300">
                <li>Put the project in your own private GitHub repository.</li>
                <li>Open <strong>Actions → Build Ada Android APK → Run workflow</strong>.</li>
                <li>Enter your HTTPS Ada site URL: <code className="text-emerald-200">{currentUrl}</code>.</li>
                <li>Download <strong>ada-android-debug-apk</strong> from the completed workflow run.</li>
              </ol>
              <p className="mt-3 text-[11px] leading-relaxed text-amber-200/80">The APK is a debug build for personal sideloading, not a Play Store-signed release. Android may ask you to allow installation from your browser/files app.</p>
            </section>

            <section className="rounded-xl border border-white/10 bg-black/40 p-4">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-cyan-300">Build locally</h4>
                  <p className="text-xs text-slate-400">Requires Android SDK, JDK 17 and Gradle 8.11.1+.</p>
                </div>
                <button onClick={() => copyToClipboard(`cd native/ada-android && gradle :app:assembleDebug -PADA_WEB_URL="${currentUrl}"`, "android-build")} className="flex shrink-0 items-center gap-1 rounded-lg bg-cyan-400/15 px-2.5 py-1 text-xs font-semibold text-cyan-200 hover:bg-cyan-400/25">
                  {copiedCmd === "android-build" ? <Check size={12} /> : <Copy size={12} />}
                  {copiedCmd === "android-build" ? "Copied" : "Copy"}
                </button>
              </div>
              <pre className="mt-3 overflow-x-auto rounded-lg bg-slate-950 p-3 font-mono text-[11px] text-cyan-200">cd native/ada-android &amp;&amp; gradle :app:assembleDebug -PADA_WEB_URL=&quot;{currentUrl}&quot;</pre>
              <p className="mt-2 text-[11px] text-slate-400">APK output: <code>app/build/outputs/apk/debug/app-debug.apk</code>.</p>
            </section>

            <section className="rounded-xl border border-amber-300/20 bg-amber-950/15 p-4">
              <h4 className="text-xs font-bold uppercase tracking-wider text-amber-200">Notification privacy</h4>
              <p className="mt-2 text-xs leading-relaxed text-slate-300">Install the APK, choose Review or Automatic in Ada Settings, then grant Notification Access in Android Settings. This is broad device permission. The app keeps a short on-device queue; automatic mode sends eligible text to the AI provider you selected. OTPs are ignored; financial/health notices always require review. Turn monitoring off in Ada or revoke Android access whenever you want.</p>
            </section>
          </div>
        )}

        {/* 2. NATIVE DESKTOP BUILDER */}
        {tab === "desktop" && (
          <div className="space-y-4">
            <div className="rounded-2xl border border-fuchsia-400/30 bg-gradient-to-b from-fuchsia-950/40 via-fuchsia-900/10 to-transparent p-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Terminal size={16} className="text-fuchsia-300" /> Package into a Standalone .exe / .dmg / .deb
              </h3>
              <p className="mt-1 text-xs text-slate-300 leading-relaxed">
                You can turn this web app into a single native binary using <strong>Pake (Rust/Tauri)</strong> or <strong>Nativefier (Electron)</strong> in one terminal command.
              </p>
            </div>

            {/* Option A: Pake (Tauri - tiny & fast ~5MB) */}
            <div className="rounded-xl border border-white/10 bg-black/40 p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-bold uppercase tracking-wider text-cyan-300">Option A: Pake / Tauri (Recommended - 5MB size)</p>
                  <p className="text-xs text-slate-400">Builds a super lightweight native app package in seconds.</p>
                </div>
                <button
                  onClick={() => copyToClipboard(`npx pake-cli ${currentUrl} --name "Ada" --transparent`, "pake")}
                  className="flex items-center gap-1 rounded-lg bg-cyan-400/15 px-2.5 py-1 text-xs font-semibold text-cyan-200 transition hover:bg-cyan-400/25"
                >
                  {copiedCmd === "pake" ? <Check size={12} /> : <Copy size={12} />}
                  {copiedCmd === "pake" ? "Copied" : "Copy Command"}
                </button>
              </div>

              <pre className="mt-2.5 overflow-x-auto rounded-lg bg-slate-950 p-3 font-mono text-[11px] text-cyan-300">
                npx pake-cli {currentUrl} --name &quot;Ada&quot; --transparent
              </pre>
            </div>

            {/* Option B: Nativefier (Electron) */}
            <div className="rounded-xl border border-white/10 bg-black/40 p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-bold uppercase tracking-wider text-fuchsia-300">Option B: Nativefier (Chromium / Electron)</p>
                  <p className="text-xs text-slate-400">Generates Windows .exe, Mac .app, or Linux binary.</p>
                </div>
                <button
                  onClick={() => copyToClipboard(`npx nativefier "${currentUrl}" --name "Ada" --single-instance --tray`, "nativefier")}
                  className="flex items-center gap-1 rounded-lg bg-fuchsia-400/15 px-2.5 py-1 text-xs font-semibold text-fuchsia-200 transition hover:bg-fuchsia-400/25"
                >
                  {copiedCmd === "nativefier" ? <Check size={12} /> : <Copy size={12} />}
                  {copiedCmd === "nativefier" ? "Copied" : "Copy Command"}
                </button>
              </div>

              <pre className="mt-2.5 overflow-x-auto rounded-lg bg-slate-950 p-3 font-mono text-[11px] text-fuchsia-300">
                npx nativefier &quot;{currentUrl}&quot; --name &quot;Ada&quot; --single-instance --tray
              </pre>
            </div>

            {/* Option C: Run Local / Docker */}
            <div className="rounded-xl border border-white/10 bg-black/40 p-4">
              <p className="text-xs font-bold uppercase tracking-wider text-emerald-300">Option C: Run Local Server</p>
              <p className="text-xs text-slate-400">Run completely on your own machine with Node.js and PostgreSQL.</p>
              <pre className="mt-2.5 overflow-x-auto rounded-lg bg-slate-950 p-3 font-mono text-[11px] text-emerald-300">
                npm install &amp;&amp; npm run dev
              </pre>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
