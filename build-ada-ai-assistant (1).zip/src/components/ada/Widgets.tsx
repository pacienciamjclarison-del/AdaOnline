"use client";

import { useEffect, useState } from "react";
import { Check, Cpu, ExternalLink, Globe, MapPin, Mic, Newspaper, Pencil, RefreshCw, Sparkles, Timer as TimerIcon, Volume2, X, Zap } from "lucide-react";
import type { ServerStatus, TimerItem, WeatherData } from "@/lib/client/types";

export type LiveNewsItem = {
  title: string;
  source: string;
  pubDate: string;
  timeAgo: string;
  link: string;
};

function useNow(intervalMs: number) {
  const [now, setNow] = useState<number | null>(null);
  useEffect(() => {
    const tick = () => setNow(Date.now());
    tick();
    const id = setInterval(tick, intervalMs);
    return () => clearInterval(id);
  }, [intervalMs]);
  return now;
}

function Card({ title, icon, children, right }: { title: string; icon: React.ReactNode; children: React.ReactNode; right?: React.ReactNode }) {
  return (
    <section className="hud p-4">
      <header className="mb-3 flex items-center justify-between text-[11px] font-semibold uppercase tracking-[0.2em] text-cyan-300/80">
        <span className="flex items-center gap-2">
          {icon}
          {title}
        </span>
        {right}
      </header>
      {children}
    </section>
  );
}

export function ClockCard() {
  const now = useNow(1000);
  const d = now ? new Date(now) : null;
  const hour = d?.getHours() ?? 12;
  const greet = hour < 5 ? "Burning the midnight oil" : hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";
  return (
    <section className="hud p-4">
      <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-cyan-300/80">{greet}</p>
      <p className="mt-1 font-mono text-4xl font-semibold tabular-nums tracking-tight text-white">
        {d ? d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : "--:--"}
        <span className="ml-1 text-lg text-cyan-300/70">{d ? d.toLocaleTimeString([], { second: "2-digit" }).slice(-2) : ""}</span>
      </p>
      <p className="mt-1 text-sm text-slate-400">
        {d ? d.toLocaleDateString([], { weekday: "long", day: "numeric", month: "long" }) : "\u00a0"}
      </p>
    </section>
  );
}

export function LiveNewsCard({ country }: { country?: string }) {
  const [category, setCategory] = useState<"top" | "tech" | "gaming" | "malaysia" | "business">("top");
  const [articles, setArticles] = useState<LiveNewsItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchNews = async (cat: string) => {
    try {
      const res = await fetch(`/api/news?category=${cat}&limit=4&country=${country || "US"}`);
      if (!res.ok) throw new Error();
      const json = await res.json();
      setArticles(json.articles || []);
    } catch {
      /* ignore */
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    setLoading(true);
    void fetchNews(category);
    const id = setInterval(() => void fetchNews(category), 5 * 60 * 1000);
    return () => clearInterval(id);
  }, [category, country]);

  const handleRefresh = () => {
    setRefreshing(true);
    void fetchNews(category);
  };

  const cats: { id: "top" | "tech" | "gaming" | "malaysia" | "business"; label: string }[] = [
    { id: "top", label: "Top" },
    { id: "tech", label: "Tech / AI" },
    { id: "gaming", label: "Gaming" },
    { id: "malaysia", label: "Malaysia" },
    { id: "business", label: "Markets" },
  ];

  return (
    <Card
      title="Live Breaking News"
      icon={<Newspaper size={13} />}
      right={
        <button
          onClick={handleRefresh}
          className="rounded p-1 text-slate-400 hover:text-cyan-300"
          title="Refresh news"
          aria-label="Refresh news"
        >
          <RefreshCw size={12} className={refreshing ? "animate-spin text-cyan-300" : ""} />
        </button>
      }
    >
      {/* Category Pills */}
      <div className="mb-3 flex gap-1 overflow-x-auto pb-1 [scrollbar-width:none]">
        {cats.map((c) => (
          <button
            key={c.id}
            onClick={() => setCategory(c.id)}
            className={`shrink-0 rounded-lg px-2.5 py-1 text-[11px] font-semibold transition ${
              category === c.id
                ? "bg-cyan-400/20 text-cyan-200 ring-1 ring-cyan-300/40"
                : "bg-white/5 text-slate-400 hover:bg-white/10 hover:text-slate-200"
            }`}
          >
            {c.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="space-y-2">
          <div className="h-10 animate-pulse rounded-lg bg-white/5" />
          <div className="h-10 animate-pulse rounded-lg bg-white/5" />
          <div className="h-10 animate-pulse rounded-lg bg-white/5" />
        </div>
      ) : articles.length === 0 ? (
        <p className="text-xs text-slate-500">No headlines available right now.</p>
      ) : (
        <ul className="space-y-2">
          {articles.map((art, i) => (
            <li key={i} className="group rounded-xl bg-white/[0.04] p-2.5 transition hover:bg-white/[0.08]">
              <a
                href={art.link}
                target="_blank"
                rel="noopener noreferrer"
                className="block text-xs font-medium leading-snug text-slate-200 group-hover:text-cyan-200"
              >
                {art.title}
              </a>
              <div className="mt-1.5 flex items-center justify-between text-[10px] text-slate-400">
                <span className="font-semibold text-cyan-400/80">{art.source}</span>
                <span className="flex items-center gap-1">
                  {art.timeAgo && <span>{art.timeAgo}</span>}
                  <ExternalLink size={10} className="opacity-0 group-hover:opacity-100" />
                </span>
              </div>
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}

export function WeatherCard({ city, onCity }: { city: string; onCity: (c: string) => void }) {
  const [data, setData] = useState<WeatherData | null>(null);
  const [state, setState] = useState<"loading" | "ok" | "error">("loading");
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(city);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      try {
        const res = await fetch(`/api/weather?city=${encodeURIComponent(city)}`);
        if (!res.ok) throw new Error();
        const json = (await res.json()) as WeatherData;
        if (!cancelled) {
          setData(json);
          setState("ok");
        }
      } catch {
        if (!cancelled) setState("error");
      }
    };
    setState("loading");
    void load();
    const id = setInterval(load, 15 * 60 * 1000);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, [city]);

  return (
    <Card
      title="Weather"
      icon={<MapPin size={13} />}
      right={
        <button onClick={() => { setDraft(city); setEditing((v) => !v); }} className="rounded p-1 text-slate-400 hover:text-cyan-300" aria-label="Change city">
          <Pencil size={12} />
        </button>
      }
    >
      {editing && (
        <form
          className="mb-3 flex gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            if (draft.trim()) onCity(draft.trim());
            setEditing(false);
          }}
        >
          <input
            autoFocus
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder="City name"
            className="min-w-0 flex-1 rounded-lg border border-cyan-400/20 bg-black/30 px-3 py-1.5 text-sm text-white outline-none focus:border-cyan-400/60"
          />
          <button className="rounded-lg bg-cyan-400/15 px-3 text-cyan-200 hover:bg-cyan-400/25" aria-label="Save city">
            <Check size={16} />
          </button>
        </form>
      )}
      {state === "loading" && !data && <div className="h-16 animate-pulse rounded-lg bg-white/5" />}
      {state === "error" && !data && <p className="text-sm text-slate-400">Couldn&apos;t reach weather for “{city}”.</p>}
      {data && (
        <div>
          <div className="flex items-center gap-3">
            <span className="text-4xl leading-none">{data.icon}</span>
            <div>
              <p className="text-3xl font-semibold text-white">
                {data.tempC}°<span className="text-base font-normal text-slate-400">C</span>
              </p>
              <p className="text-sm capitalize text-slate-300">{data.condition}</p>
            </div>
          </div>
          <p className="mt-2 text-xs text-slate-400">
            {data.city}, {data.country} · feels {data.feelsC}°
          </p>
          <div className="mt-3 grid grid-cols-3 gap-2 text-center text-[11px] text-slate-400">
            <div className="rounded-lg bg-white/5 py-1.5">
              <p className="text-sm font-medium text-slate-100">
                {data.highC}° / {data.lowC}°
              </p>
              hi / lo
            </div>
            <div className="rounded-lg bg-white/5 py-1.5">
              <p className="text-sm font-medium text-slate-100">{data.rainChance}%</p>
              rain
            </div>
            <div className="rounded-lg bg-white/5 py-1.5">
              <p className="text-sm font-medium text-slate-100">{data.windKph}</p>
              km/h wind
            </div>
          </div>
        </div>
      )}
    </Card>
  );
}

function fmt(ms: number) {
  const s = Math.max(0, Math.ceil(ms / 1000));
  const h = Math.floor(s / 3600);
  const m = Math.floor((sec(ms) % 3600) / 60);
  const secVal = sec(ms) % 60;
  return h ? `${h}:${String(m).padStart(2, "0")}:${String(secVal).padStart(2, "0")}` : `${m}:${String(secVal).padStart(2, "0")}`;
}
function sec(ms: number) {
  return Math.max(0, Math.ceil(ms / 1000));
}

export function TimersCard({ timers, onCancel }: { timers: TimerItem[]; onCancel: (id: string) => void }) {
  const now = useNow(250);
  return (
    <Card title="Timers" icon={<TimerIcon size={13} />}>
      {timers.length === 0 ? (
        <p className="text-sm text-slate-500">No active timers. Try “set a timer for 10 minutes”.</p>
      ) : (
        <ul className="space-y-2">
          {timers.map((t) => {
            const left = (t.endsAt - (now ?? t.endsAt));
            const pct = Math.max(0, Math.min(100, (left / (t.total * 1000)) * 100));
            return (
              <li key={t.id} className="rounded-xl bg-white/5 p-3">
                <div className="flex items-center justify-between">
                  <span className="truncate text-sm text-slate-200">{t.label || "Timer"}</span>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-lg tabular-nums text-cyan-200">{fmt(left)}</span>
                    <button onClick={() => onCancel(t.id)} className="text-slate-500 hover:text-rose-300" aria-label="Cancel timer">
                      <X size={14} />
                    </button>
                  </div>
                </div>
                <div className="mt-2 h-1 overflow-hidden rounded-full bg-white/10">
                  <div className="h-full rounded-full bg-cyan-300 transition-[width] duration-300" style={{ width: `${pct}%` }} />
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </Card>
  );
}

export function SystemCard({
  aiLabel,
  voiceLabel,
  micLabel,
  counts,
  onOpenSettings,
}: {
  aiLabel: string;
  voiceLabel: string;
  micLabel: string;
  counts: { tasks: number; notes: number; memories: number };
  onOpenSettings?: () => void;
}) {
  const rows: [string, string, boolean][] = [
    ["AI Engine", aiLabel, true],
    ["Voice", voiceLabel, true],
    ["Microphone", micLabel, micLabel.startsWith("listening")],
  ];
  return (
    <Card
      title="System Status"
      icon={<Cpu size={13} />}
      right={
        onOpenSettings ? (
          <button
            onClick={onOpenSettings}
            className="flex items-center gap-1 rounded bg-cyan-400/10 px-2 py-0.5 text-[10px] font-bold text-cyan-200 hover:bg-cyan-400/20"
          >
            <Sparkles size={10} /> Free APIs
          </button>
        ) : undefined
      }
    >
      <ul className="space-y-2 text-sm">
        {rows.map(([k, v, ok]) => (
          <li key={k} className="flex items-center justify-between gap-3">
            <span className="flex items-center gap-2 text-slate-400">
              {k === "Voice" ? <Volume2 size={13} /> : k === "Microphone" ? <Mic size={13} /> : <Zap size={13} />}
              {k}
            </span>
            <span className="flex min-w-0 items-center gap-2 text-slate-200">
              <span className={`h-1.5 w-1.5 shrink-0 rounded-full ${ok ? "bg-emerald-400" : "bg-amber-400"}`} />
              <span className="truncate">{v}</span>
            </span>
          </li>
        ))}
      </ul>
      <div className="mt-3 grid grid-cols-3 gap-2 text-center text-[11px] text-slate-400">
        <div className="rounded-lg bg-white/5 py-1.5">
          <p className="text-sm font-medium text-slate-100">{counts.tasks}</p>tasks
        </div>
        <div className="rounded-lg bg-white/5 py-1.5">
          <p className="text-sm font-medium text-slate-100">{counts.notes}</p>notes
        </div>
        <div className="rounded-lg bg-white/5 py-1.5">
          <p className="text-sm font-medium text-slate-100">{counts.memories}</p>memories
        </div>
      </div>
      {onOpenSettings && (
        <button
          onClick={onOpenSettings}
          className="mt-3 flex w-full items-center justify-center gap-1.5 rounded-xl border border-cyan-400/20 bg-cyan-400/10 py-2 text-xs font-semibold text-cyan-200 transition hover:bg-cyan-400/20"
        >
          <Zap size={13} /> Connect 100% Free AI API (Groq / Gemini)
        </button>
      )}
    </Card>
  );
}

export default function Widgets(props: {
  city: string;
  onCity: (c: string) => void;
  timers: TimerItem[];
  onCancelTimer: (id: string) => void;
  status: ServerStatus | null;
  aiLabel: string;
  voiceLabel: string;
  micLabel: string;
  counts: { tasks: number; notes: number; memories: number };
  onOpenSettings?: () => void;
}) {
  return (
    <div className="flex flex-col gap-3">
      <ClockCard />
      <LiveNewsCard country={props.city.toLowerCase().includes("kuala lumpur") ? "MY" : "US"} />
      <WeatherCard city={props.city} onCity={props.onCity} />
      <TimersCard timers={props.timers} onCancel={props.onCancelTimer} />
      <SystemCard
        aiLabel={props.aiLabel}
        voiceLabel={props.voiceLabel}
        micLabel={props.micLabel}
        counts={props.counts}
        onOpenSettings={props.onOpenSettings}
      />
    </div>
  );
}
