"use client";

import { useEffect, useRef, useState } from "react";
import AvatarSvg, { NEUTRAL_POSE, type Pose } from "./AvatarSvg";
import type { Mood, Status } from "@/lib/client/types";

type Expr = {
  eyeOpen: number;
  smileEye: number;
  pupil: number;
  browY: number;
  browAngry: number;
  browSkew: number;
  mouthCurve: number;
  mouthWidth: number;
  mouthSkew: number;
  mouthBase: number;
  blush: number;
  tilt: number;
  biasX: number;
  biasY: number;
};

const BASE: Expr = {
  eyeOpen: 1,
  smileEye: 0,
  pupil: 1,
  browY: 0,
  browAngry: 0,
  browSkew: 0,
  mouthCurve: 0.3,
  mouthWidth: 1,
  mouthSkew: 0,
  mouthBase: 0,
  blush: 0.2,
  tilt: 0,
  biasX: 0,
  biasY: 0,
};
const KEYS = Object.keys(BASE) as (keyof Expr)[];

const MOODS: Record<Mood, Partial<Expr>> = {
  neutral: {},
  happy: { eyeOpen: 0.92, mouthCurve: 0.85, mouthWidth: 1.15, browY: -3, blush: 0.4 },
  excited: { smileEye: 0.95, mouthCurve: 1, mouthWidth: 1.3, browY: -6, blush: 0.6 },
  smug: { eyeOpen: 0.72, browY: -3, browSkew: 3, mouthCurve: 0.6, mouthSkew: 1, mouthWidth: 0.95, tilt: -3 },
  sad: { eyeOpen: 0.82, browAngry: -12, browY: 3, mouthCurve: -0.7, mouthWidth: 0.85, blush: 0, biasY: 0.5, tilt: 3 },
  surprised: { eyeOpen: 1.15, browY: -10, pupil: 0.8, mouthBase: 0.4, mouthWidth: 0.7, mouthCurve: 0, blush: 0.1 },
  angry: { eyeOpen: 0.88, browAngry: 14, browY: 2, mouthCurve: -0.45, blush: 0.05, mouthWidth: 0.95 },
  thinking: { browSkew: 3, browY: -2, mouthCurve: 0, mouthWidth: 0.7, mouthSkew: -0.8, biasX: -0.7, biasY: -0.7, tilt: 4 },
  embarrassed: { smileEye: 0.3, eyeOpen: 0.9, blush: 1, browAngry: -8, browY: -1, mouthCurve: 0.2, mouthWidth: 0.8, biasX: 0.6, biasY: 0.6, tilt: -3 },
  sleepy: { eyeOpen: 0.3, browY: 3, mouthCurve: 0, mouthWidth: 0.7, tilt: 5, blush: 0.25 },
};

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

type Props = {
  mood: Mood;
  status: Status;
  getLevel: () => number;
  onPoke?: () => void;
  className?: string;
};

export default function AdaAvatar({ mood, status, getLevel, onPoke, className }: Props) {
  const [pose, setPose] = useState<Pose>(NEUTRAL_POSE);
  const wrapRef = useRef<HTMLDivElement>(null);
  const propsRef = useRef({ mood, status, getLevel });
  useEffect(() => {
    propsRef.current = { mood, status, getLevel };
  });

  useEffect(() => {
    const s = {
      cur: { ...BASE } as Expr,
      gx: 0,
      gy: 0,
      tx: 0,
      ty: 0,
      nextSaccade: 1,
      nextBlink: 2.5,
      blinkT: -1,
      mouth: 0,
      t: 0,
      mx: 0,
      my: 0,
      mouseAt: -99,
    };

    const onMove = (e: PointerEvent) => {
      const el = wrapRef.current;
      if (!el) return;
      const r = el.getBoundingClientRect();
      const cx = r.left + r.width / 2;
      const cy = r.top + r.height * 0.45;
      s.mx = clamp((e.clientX - cx) / (window.innerWidth * 0.5), -1, 1);
      s.my = clamp((e.clientY - cy) / (window.innerHeight * 0.5), -1, 1);
      s.mouseAt = s.t;
    };
    window.addEventListener("pointermove", onMove);

    let raf = 0;
    let last = performance.now();
    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      s.t += dt;
      const t = s.t;
      const { mood: m, status: st, getLevel: level } = propsRef.current;

      // expression easing
      const effective: Mood = st === "thinking" && m === "neutral" ? "thinking" : m;
      const target = { ...BASE, ...MOODS[effective] };
      if (st === "listening" && effective === "neutral") {
        target.eyeOpen = 1.06;
        target.browY = -3;
        target.mouthCurve = 0.4;
        target.tilt = 3;
      }
      const k = 1 - Math.exp(-dt * 8);
      for (const key of KEYS) s.cur[key] += (target[key] - s.cur[key]) * k;

      // blinking
      if (s.blinkT < 0 && t > s.nextBlink) s.blinkT = 0;
      let blink = 0;
      if (s.blinkT >= 0) {
        s.blinkT += dt;
        const p = s.blinkT / 0.16;
        if (p >= 1) {
          s.blinkT = -1;
          s.nextBlink = t + (Math.random() < 0.15 ? 0.22 : 2 + Math.random() * 3.8);
        } else {
          blink = Math.sin(Math.PI * p);
        }
      }

      // gaze: follow the pointer if it moved recently, otherwise wander
      const talking = st === "speaking" || st === "listening";
      if (t - s.mouseAt < 5) {
        s.tx = s.mx * 0.9;
        s.ty = s.my * 0.7;
      } else if (t > s.nextSaccade) {
        s.tx = (Math.random() - 0.5) * 0.9;
        s.ty = (Math.random() - 0.5) * 0.55;
        s.nextSaccade = t + 1.2 + Math.random() * 3;
      }
      const damp = talking ? 0.45 : 1;
      const gx = clamp(s.tx * damp + s.cur.biasX, -1, 1);
      const gy = clamp(s.ty * damp + s.cur.biasY, -1, 1);
      const gk = 1 - Math.exp(-dt * 10);
      s.gx += (gx - s.gx) * gk;
      s.gy += (gy - s.gy) * gk;

      // mouth (lip sync)
      const lv = st === "speaking" ? level() : 0;
      s.mouth += (lv - s.mouth) * (1 - Math.exp(-dt * 26));

      const sleepy = effective === "sleepy";
      const headRot =
        Math.sin(t * 0.6) * 1.1 + Math.sin(t * 1.7) * 0.4 + s.cur.tilt + s.gx * 1.6 + (st === "speaking" ? Math.sin(t * 3.1) * 1.3 : 0);
      const glow =
        st === "thinking"
          ? 0.55 + 0.4 * Math.sin(t * 6)
          : st === "listening"
            ? 0.95
            : st === "speaking"
              ? 0.65 + s.mouth * 0.35
              : 0.55 + 0.1 * Math.sin(t * 1.4);

      setPose({
        headRot,
        headX: Math.sin(t * 0.5) * 2 + s.gx * 3,
        headY: Math.sin(t * 0.9) * 1.2 + s.mouth * 1.6 + s.gy * 1.5,
        breath: (Math.sin(t * (sleepy ? 1 : 1.7) + 0.5) + 1) / 2,
        eyeOpen: s.cur.eyeOpen * (1 - blink * 0.94),
        smileEye: s.cur.smileEye,
        gazeX: s.gx,
        gazeY: s.gy,
        pupil: s.cur.pupil,
        browY: s.cur.browY,
        browAngry: s.cur.browAngry,
        browSkew: s.cur.browSkew,
        mouthOpen: Math.max(s.cur.mouthBase, s.mouth * 0.95),
        mouthCurve: s.cur.mouthCurve,
        mouthWidth: s.cur.mouthWidth * (1 - s.mouth * 0.14),
        mouthSkew: s.cur.mouthSkew,
        blush: s.cur.blush,
        hairSway: Math.sin(t * 0.9 + 1) * 1.2 - headRot * 0.5,
        ahoge: Math.sin(t * 2.2) * 6 + s.mouth * 6,
        glow,
      });
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("pointermove", onMove);
    };
  }, []);

  return (
    <div ref={wrapRef} className={className} onClick={onPoke} style={{ cursor: onPoke ? "pointer" : undefined }}>
      <AvatarSvg pose={pose} className="h-full w-auto max-w-full select-none drop-shadow-[0_0_30px_rgba(34,211,238,0.25)]" />
    </div>
  );
}
