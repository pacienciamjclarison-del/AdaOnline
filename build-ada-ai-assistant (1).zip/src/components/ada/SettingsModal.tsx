"use client";

import { useState } from "react";
import { Check, ExternalLink, Loader2, Sparkles, X, Zap } from "lucide-react";
import { FREE_PROVIDERS, type FreeProviderInfo, type ServerStatus, type Settings } from "@/lib/client/types";

type Props = {
  open: boolean;
  onClose: () => void;
  settings: Settings;
  onChange: (p: Partial<Settings>) => void;
  status: ServerStatus | null;
  browserVoices: SpeechSynthesisVoice[];
  micSupported: boolean;
  isAndroidApp: boolean;
  notificationAccessGranted: boolean;
  onRequestNotificationAccess: () => void;
  onTest: () => void;
  onClearChat: () => void;
};

function Row({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-4 py-3">
      <div className="min-w-0">
        <p className="text-sm font-medium text-slate-100">{label}</p>
        {hint && <p className="mt-0.5 text-xs text-slate-400">{hint}</p>}
      </div>
      <div className="shrink-0">{children}</div>
    </div>
  );
}

function Toggle({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button
      role="switch"
      aria-checked={on}
      aria-label={label}
      onClick={() => onChange(!on)}
      className={`relative h-6 w-11 rounded-full transition ${on ? "bg-cyan-400" : "bg-white/15"}`}
    >
      <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all ${on ? "left-[22px]" : "left-0.5"}`} />
    </button>
  );
}

const selectCls = "max-w-[210px] rounded-lg border border-white/10 bg-slate-900 px-2 py-1.5 text-sm text-slate-100 outline-none focus:border-cyan-400/50";
const inputCls = "w-full rounded-lg border border-white/10 bg-black/40 px-3 py-2 text-sm text-white outline-none placeholder:text-slate-500 focus:border-cyan-400/50";

export default function SettingsModal({ open, onClose, settings, onChange, status, browserVoices, micSupported, isAndroidApp, notificationAccessGranted, onRequestNotificationAccess, onTest, onClearChat }: Props) {
  const [testingKey, setTestingKey] = useState(false);
  const [testResult, setTestResult] = useState<{ ok: boolean; message: string } | null>(null);

  if (!open) return null;
  const cloudLabel = status?.tts === "elevenlabs" ? "ElevenLabs" : status?.tts === "openai" ? "OpenAI voice" : "Neural voice";

  const currentProviderId = settings.customProvider || "groq";
  const selectedProvider: FreeProviderInfo =
    FREE_PROVIDERS.find((p) => p.id === currentProviderId) || FREE_PROVIDERS[0];

  const handleProviderSelect = (pid: string) => {
    const prov = FREE_PROVIDERS.find((p) => p.id === pid);
    if (!prov) return;
    setTestResult(null);
    const keys = { ...(settings.customApiKeys || {}) };
    if (settings.customApiKey && currentProviderId) keys[currentProviderId] = settings.customApiKey;
    const nextKey = keys[pid] || "";
    onChange({
      customProvider: prov.id,
      customModel: prov.defaultModel,
      customApiKeys: keys,
      customApiKey: nextKey,
    });
  };

  const handleTestKey = async () => {
    setTestingKey(true);
    setTestResult(null);
    try {
      const res = await fetch("/api/test-key", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          clientLlm: {
            apiKey: settings.customApiKey,
            provider: settings.customProvider || "groq",
            model: settings.customModel || selectedProvider.defaultModel,
            baseUrl: settings.customBaseUrl,
          },
        }),
      });
      const json = await res.json();
      if (json.ok) {
        setTestResult({
          ok: true,
          message: `✓ Connected! Model: ${json.model} · Response time: ${json.latency}ms`,
        });
      } else {
        setTestResult({
          ok: false,
          message: `✗ Error: ${json.error || "Connection failed"}`,
        });
      }
    } catch (e) {
      setTestResult({
        ok: false,
        message: `✗ Network error: ${e instanceof Error ? e.message : String(e)}`,
      });
    } finally {
      setTestingKey(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/75 p-4 backdrop-blur-md" onClick={onClose}>
      <div
        className="max-h-[90dvh] w-full max-w-xl overflow-y-auto rounded-3xl border border-cyan-300/25 bg-[#091024] p-6 shadow-[0_0_80px_rgba(34,211,238,0.15)]"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-label="Settings"
      >
        <div className="mb-4 flex items-center justify-between border-b border-white/10 pb-3">
          <div className="flex items-center gap-2">
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-cyan-400/20 text-cyan-300">
              <Zap size={18} />
            </span>
            <div>
              <h2 className="text-lg font-bold text-white">Ada Control Center</h2>
              <p className="text-xs text-slate-400">Configure free AI APIs, voice, and Jarvis preferences</p>
            </div>
          </div>
          <button onClick={onClose} className="rounded-full p-2 text-slate-400 hover:bg-white/10 hover:text-white" aria-label="Close settings">
            <X size={18} />
          </button>
        </div>

        <section className="mb-5 rounded-2xl border border-fuchsia-400/20 bg-fuchsia-950/15 px-4">
          <Row label="Maximum chaos · gremlin mode" hint="Ada chats and teases spontaneously while the app is open and idle. Turn it off anytime.">
            <Toggle
              on={settings.chaosMode}
              onChange={(v) => onChange({ chaosMode: v, randomRoasts: v })}
              label="Maximum chaos mode"
            />
          </Row>
        </section>

        <section className="mb-6 rounded-2xl border border-emerald-400/20 bg-emerald-950/15 p-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-200">Android live notifications</h3>
          <p className="mt-2 text-xs leading-relaxed text-slate-300">
            Only the native Android Ada app can read notifications, and only after you grant Android's special Notification Access permission. The permission can expose notifications from multiple apps; Ada buffers them on-device. iPhone and the regular website cannot read the notification tray.
          </p>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <span className={`rounded-full px-2.5 py-1 text-[11px] font-semibold ${isAndroidApp && notificationAccessGranted ? "bg-emerald-500/15 text-emerald-200" : "bg-white/5 text-slate-300"}`}>
              {isAndroidApp ? notificationAccessGranted ? "Android access granted" : "Android access not granted" : "Native Android app required"}
            </span>
            {isAndroidApp && (
              <button onClick={onRequestNotificationAccess} className="rounded-lg border border-emerald-300/25 bg-emerald-400/10 px-3 py-1.5 text-xs font-semibold text-emerald-100 hover:bg-emerald-400/20">
                {notificationAccessGranted ? "Manage Android permission" : "Open Android permission settings"}
              </button>
            )}
          </div>
          <div className="mt-3">
            <label className="mb-1 block text-xs font-medium text-slate-200">What should Ada do?</label>
            <select
              value={settings.notificationMode}
              onChange={(e) => onChange({ notificationMode: e.target.value as Settings["notificationMode"] })}
              className="w-full rounded-lg border border-white/10 bg-slate-900 px-3 py-2 text-sm text-white outline-none focus:border-emerald-300/50"
            >
              <option value="off">Off — do not monitor</option>
              <option value="review">Review — show each notice and wait for me</option>
              <option value="automatic">Automatic — react when Ada is idle</option>
            </select>
            <p className="mt-2 text-[11px] leading-relaxed text-slate-400">
              Automatic mode sends eligible notification text to your selected AI provider. Security codes, banking/payment and health notices always wait for your review. Nothing is saved to chat history. Turn this off here or revoke Notification Access in Android Settings at any time.
            </p>
          </div>
          {!isAndroidApp && (
            <p className="mt-2 text-[11px] text-cyan-200/80">To use this feature, build and install the companion from Install App → Android APK.</p>
          )}
        </section>

        {/* ================= 100% FREE AI PROVIDER SECTION ================= */}
        <section className="mb-6 rounded-2xl border border-cyan-400/30 bg-gradient-to-b from-cyan-950/40 via-cyan-900/10 to-transparent p-4">
          <div className="mb-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles size={16} className="text-cyan-300" />
              <h3 className="text-sm font-bold uppercase tracking-wider text-cyan-200">
                AI API Connection
              </h3>
            </div>
            <span className="rounded-full bg-cyan-400/15 px-2.5 py-0.5 text-[11px] font-semibold text-cyan-300 ring-1 ring-cyan-300/30">
              {selectedProvider.badge}
            </span>
          </div>

          <p className="mb-4 text-xs leading-relaxed text-slate-300">
            Connect a provider-specific key. Free quotas and model availability vary; OpenRouter Free routes to a currently available free model. OpenAI and DeepSeek are paid. Your key is saved in this browser and only sent to the selected provider through Ada's server.
          </p>

          {/* Provider Selector Chips */}
          <div className="mb-4 flex flex-wrap gap-1.5">
            {FREE_PROVIDERS.map((prov) => {
              const active = (settings.customProvider || "groq") === prov.id;
              return (
                <button
                  key={prov.id}
                  onClick={() => handleProviderSelect(prov.id)}
                  className={`flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-semibold transition ${
                    active
                      ? "bg-cyan-400 text-slate-950 shadow-[0_0_15px_rgba(34,211,238,0.4)]"
                      : "border border-white/10 bg-white/5 text-slate-300 hover:border-cyan-400/40 hover:text-white"
                  }`}
                >
                  {active && <Check size={12} strokeWidth={3} />}
                  {prov.name}
                </button>
              );
            })}
          </div>

          {/* Provider Details & Input */}
          <div className="space-y-3 rounded-xl border border-white/10 bg-black/40 p-4">
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="text-sm font-semibold text-white">{selectedProvider.name}</p>
                <p className="text-xs text-slate-400">{selectedProvider.desc}</p>
              </div>
              {selectedProvider.getKeyUrl && (
                <a
                  href={selectedProvider.getKeyUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex shrink-0 items-center gap-1 rounded-lg bg-cyan-400/15 px-2.5 py-1 text-xs font-semibold text-cyan-200 transition hover:bg-cyan-400/25"
                >
                  Get Free Key <ExternalLink size={12} />
                </a>
              )}
            </div>

            {selectedProvider.id !== "ollama" && (
              <div>
                <label className="mb-1 block text-xs font-medium text-slate-300">
                  {selectedProvider.name} API Key
                </label>
                <input
                  type="password"
                  value={settings.customApiKey || ""}
                  onChange={(e) => {
                    setTestResult(null);
                    const value = e.target.value;
                    onChange({
                      customApiKey: value,
                      customApiKeys: { ...(settings.customApiKeys || {}), [currentProviderId]: value },
                    });
                  }}
                  placeholder={selectedProvider.keyPlaceholder}
                  className={inputCls}
                />
              </div>
            )}

            {/* Model Selector if options exist */}
            {selectedProvider.models.length > 0 && (
              <div>
                <label className="mb-1 block text-xs font-medium text-slate-300">
                  Model
                </label>
                <select
                  value={settings.customModel || selectedProvider.defaultModel}
                  onChange={(e) => {
                    setTestResult(null);
                    onChange({ customModel: e.target.value });
                  }}
                  className="w-full rounded-lg border border-white/10 bg-slate-900 px-3 py-2 text-sm text-white outline-none focus:border-cyan-400/50"
                >
                  {selectedProvider.models.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.label}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {selectedProvider.id === "custom" && (
              <div>
                <label className="mb-1 block text-xs font-medium text-slate-300">
                  Custom Base URL
                </label>
                <input
                  type="text"
                  value={settings.customBaseUrl || ""}
                  onChange={(e) => onChange({ customBaseUrl: e.target.value })}
                  placeholder="https://api.together.xyz/v1"
                  className={inputCls}
                />
              </div>
            )}

            {/* Test Key Button & Feedback */}
            <div className="flex flex-col gap-2 pt-1">
              <div className="flex items-center gap-2">
                <button
                  onClick={handleTestKey}
                  disabled={testingKey || (!settings.customApiKey?.trim() && selectedProvider.id !== "ollama")}
                  className="flex items-center gap-1.5 rounded-lg bg-emerald-500/20 px-4 py-2 text-xs font-bold text-emerald-200 ring-1 ring-emerald-400/40 transition hover:bg-emerald-500/30 disabled:opacity-40"
                >
                  {testingKey ? <Loader2 size={13} className="animate-spin" /> : <Zap size={13} />}
                  {testingKey ? "Testing connection…" : "Test & Verify Key"}
                </button>
                {settings.customApiKey && (
                  <button
                    onClick={() => {
                      setTestResult(null);
                      onChange({
                        customApiKey: "",
                        customApiKeys: { ...(settings.customApiKeys || {}), [currentProviderId]: "" },
                      });
                    }}
                    className="text-xs text-slate-400 hover:text-rose-300"
                  >
                    Clear Key
                  </button>
                )}
              </div>

              {testResult && (
                <div
                  className={`rounded-lg p-2.5 text-xs font-medium ${
                    testResult.ok
                      ? "border border-emerald-400/30 bg-emerald-950/50 text-emerald-200"
                      : "border border-rose-400/30 bg-rose-950/50 text-rose-200"
                  }`}
                >
                  {testResult.message}
                </div>
              )}
            </div>
          </div>
        </section>

        {/* ================= VOICE SETTINGS ================= */}
        <h3 className="text-[11px] font-semibold uppercase tracking-[0.2em] text-cyan-300/80">Voice & Speech</h3>
        <div className="divide-y divide-white/5">
          <Row label="Ada speaks out loud" hint="Off = subtitles only">
            <Toggle on={settings.autoSpeak} onChange={(v) => onChange({ autoSpeak: v })} label="Speak replies" />
          </Row>
          <Row label="Voice engine" hint={`${cloudLabel} is 100% free neural audio. Browser works offline.`}>
            <select className={selectCls} value={settings.engine} onChange={(e) => onChange({ engine: e.target.value as Settings["engine"] })}>
              <option value="auto">Auto (Best available)</option>
              <option value="cloud">{cloudLabel}</option>
              <option value="browser">Browser Speech Synthesis</option>
            </select>
          </Row>
          {status?.tts === "edge" && settings.engine !== "browser" && (
            <Row label="Neural voice">
              <select className={selectCls} value={settings.cloudVoice} onChange={(e) => onChange({ cloudVoice: e.target.value })}>
                {status.edgeVoices.map((v) => (
                  <option key={v.id} value={v.id}>
                    {v.label}
                  </option>
                ))}
              </select>
            </Row>
          )}
          {settings.engine !== "cloud" && (
            <Row label="Browser voice" hint="Used as local fallback">
              <select className={selectCls} value={settings.browserVoiceURI} onChange={(e) => onChange({ browserVoiceURI: e.target.value })}>
                <option value="">Auto-pick (female)</option>
                {browserVoices.map((v) => (
                  <option key={v.voiceURI} value={v.voiceURI}>
                    {v.name} ({v.lang})
                  </option>
                ))}
              </select>
            </Row>
          )}
          <Row label="Volume">
            <input type="range" min={0} max={1} step={0.05} value={settings.volume} onChange={(e) => onChange({ volume: Number(e.target.value) })} className="w-36 accent-cyan-400" />
          </Row>
          <Row label="Subtitles on stage">
            <Toggle on={settings.subtitles} onChange={(v) => onChange({ subtitles: v })} label="Subtitles" />
          </Row>
        </div>
        <button onClick={onTest} className="mt-2 rounded-full bg-cyan-400/15 px-4 py-2 text-xs font-semibold text-cyan-100 ring-1 ring-cyan-300/30 hover:bg-cyan-400/25">
          Test Ada's Voice
        </button>

        {/* ================= MICROPHONE & LISTENING ================= */}
        <h3 className="mt-6 text-[11px] font-semibold uppercase tracking-[0.2em] text-cyan-300/80">Microphone & Listening</h3>
        <div className="divide-y divide-white/5">
          <Row label="Speech language" hint={micSupported ? "Speech recognition language" : "Microphone not supported in this browser"}>
            <select className={selectCls} value={settings.sttLang} onChange={(e) => onChange({ sttLang: e.target.value })}>
              <option value="en-US">English (US)</option>
              <option value="en-GB">English (UK)</option>
              <option value="en-AU">English (AU)</option>
              <option value="ms-MY">Bahasa Melayu</option>
              <option value="id-ID">Bahasa Indonesia</option>
              <option value="ja-JP">日本語</option>
              <option value="zh-CN">中文</option>
            </select>
          </Row>
          <Row label="Wake word" hint={'Only responds when you say "Ada" or "Jarvis". Stays awake 25s.'}>
            <Toggle on={settings.wakeWord} onChange={(v) => onChange({ wakeWord: v })} label="Wake word" />
          </Row>
        </div>

        {/* ================= GENERAL ================= */}
        <h3 className="mt-6 text-[11px] font-semibold uppercase tracking-[0.2em] text-cyan-300/80">Location & Chat</h3>
        <div className="divide-y divide-white/5">
          <Row label="Default city" hint="For “what's the weather?”">
            <input value={settings.city} onChange={(e) => onChange({ city: e.target.value })} className="w-40 rounded-lg border border-white/10 bg-black/30 px-3 py-1.5 text-sm text-white outline-none focus:border-cyan-400/50" />
          </Row>
          <Row label="Clear conversation" hint="Resets chat history">
            <button onClick={onClearChat} className="rounded-lg bg-rose-400/15 px-3 py-1.5 text-xs font-semibold text-rose-200 hover:bg-rose-400/25">
              Clear chat
            </button>
          </Row>
        </div>
      </div>
    </div>
  );
}
