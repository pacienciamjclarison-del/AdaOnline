"use client";

import { useEffect, useRef, useState } from "react";
import { ArrowUpRight, Mic, MicOff, SendHorizontal, Square } from "lucide-react";
import { MOOD_EMOJI, type ChatMsg } from "@/lib/client/types";

const SUGGESTIONS = [
  "What's the latest news?",
  "What's happening in tech?",
  "What's the weather like?",
  "Set a timer for 5 minutes",
  "Add task: buy groceries",
  "Tell me a joke",
  "Open YouTube",
];

type Props = {
  messages: ChatMsg[];
  onSend: (text: string) => void;
  onStop: () => void;
  busy: boolean;
  micSupported: boolean;
  listening: boolean;
  onToggleMic: () => void;
  micError: string | null;
  wakeWord: boolean;
};

export default function ChatPanel({ messages, onSend, onStop, busy, micSupported, listening, onToggleMic, micError, wakeWord }: Props) {
  const [text, setText] = useState("");
  const endRef = useRef<HTMLDivElement>(null);
  const lastContent = messages[messages.length - 1]?.content;

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages.length, lastContent]);

  const submit = () => {
    const t = text.trim();
    if (!t) return;
    onSend(t);
    setText("");
  };

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="min-h-0 flex-1 space-y-3 overflow-y-auto px-3 pb-2 pt-3">
        {messages.length === 0 && (
          <div className="mt-6 text-center text-sm text-slate-500">
            <p className="text-slate-300">Say something. Type it, or hit the mic and just talk.</p>
          </div>
        )}
        {messages.map((m) => (
          <div key={m.id} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"} fade-up`}>
            <div className={`max-w-[88%] ${m.role === "user" ? "items-end" : "items-start"} flex flex-col gap-1`}>
              {m.role === "assistant" && (
                <span className="flex items-center gap-1.5 pl-1 text-[10px] font-semibold uppercase tracking-[0.2em] text-pink-300/80">
                  Ada {m.mood && m.mood !== "neutral" ? <span className="text-xs tracking-normal">{MOOD_EMOJI[m.mood]}</span> : null}
                </span>
              )}
              <div
                className={`whitespace-pre-wrap break-words rounded-2xl px-3.5 py-2 text-[14.5px] leading-relaxed ${
                  m.role === "user"
                    ? "rounded-br-md bg-cyan-400/15 text-cyan-50 ring-1 ring-cyan-300/25"
                    : "rounded-bl-md bg-white/[0.06] text-slate-100 ring-1 ring-white/10"
                }`}
              >
                {m.content ||
                  (m.pending ? (
                    <span className="typing flex items-center gap-1 py-1">
                      <i />
                      <i />
                      <i />
                    </span>
                  ) : (
                    "…"
                  ))}
              </div>
              {m.warning && (
                <div className="max-w-full rounded-lg border border-amber-400/25 bg-amber-500/10 px-3 py-2 text-[11px] leading-relaxed text-amber-100/90">
                  <span className="font-semibold text-amber-200">API issue: </span>{m.warning}
                </div>
              )}
              {m.links?.map((l) => (
                <a
                  key={l.url}
                  href={l.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex max-w-full items-center gap-1.5 rounded-full border border-cyan-300/30 bg-cyan-400/10 px-3 py-1 text-xs font-medium text-cyan-200 transition hover:bg-cyan-400/25"
                >
                  <ArrowUpRight size={13} className="shrink-0" />
                  <span className="truncate">{l.label}</span>
                </a>
              ))}
            </div>
          </div>
        ))}
        <div ref={endRef} />
      </div>

      {messages.length <= 2 && (
        <div className="flex gap-2 overflow-x-auto px-3 pb-2 [scrollbar-width:none]">
          {SUGGESTIONS.map((s) => (
            <button
              key={s}
              onClick={() => onSend(s)}
              className="shrink-0 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-slate-300 transition hover:border-cyan-300/40 hover:text-cyan-100"
            >
              {s}
            </button>
          ))}
        </div>
      )}

      {micError && <p className="mx-3 mb-2 rounded-lg bg-rose-500/10 px-3 py-2 text-xs text-rose-200">{micError}</p>}

      <form
        className="flex items-center gap-2 border-t border-white/10 p-3"
        onSubmit={(e) => {
          e.preventDefault();
          submit();
        }}
      >
        {micSupported && (
          <button
            type="button"
            onClick={onToggleMic}
            className={`relative grid h-11 w-11 shrink-0 place-items-center rounded-full transition ${
              listening ? "bg-emerald-400 text-slate-900 shadow-[0_0_24px_rgba(52,211,153,0.6)]" : "bg-white/8 text-slate-300 ring-1 ring-white/10 hover:text-cyan-200"
            }`}
            aria-label={listening ? "Stop listening" : "Start listening"}
            title={listening ? (wakeWord ? 'Listening for "Ada…"' : "Listening") : "Talk to Ada"}
          >
            {listening && <span className="absolute inset-0 animate-ping rounded-full bg-emerald-300/40" />}
            {listening ? <Mic size={19} className="relative" /> : <MicOff size={19} className="relative" />}
          </button>
        )}
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder={listening ? (wakeWord ? 'Say "Hey Ada…" or type' : "Listening… or type here") : "Talk to Ada…"}
          className="h-11 min-w-0 flex-1 rounded-full border border-white/10 bg-black/30 px-4 text-sm text-white outline-none placeholder:text-slate-500 focus:border-cyan-400/50"
          autoComplete="off"
        />
        {busy ? (
          <button type="button" onClick={onStop} className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-rose-400/20 text-rose-200 ring-1 ring-rose-300/30 hover:bg-rose-400/30" aria-label="Stop">
            <Square size={16} fill="currentColor" />
          </button>
        ) : (
          <button
            disabled={!text.trim()}
            className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-cyan-400 text-slate-900 transition enabled:hover:bg-cyan-300 disabled:opacity-30"
            aria-label="Send"
          >
            <SendHorizontal size={18} />
          </button>
        )}
      </form>
    </div>
  );
}
