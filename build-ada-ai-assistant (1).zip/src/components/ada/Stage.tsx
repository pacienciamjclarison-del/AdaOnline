"use client";

import { useEffect, useRef } from "react";
import AdaAvatar from "./AdaAvatar";
import { MOOD_EMOJI, type Mood, type Status } from "@/lib/client/types";

const STATUS_META: Record<Status, { label: string; color: string }> = {
  idle: { label: "ONLINE", color: "#22d3ee" },
  listening: { label: "LISTENING", color: "#34d399" },
  thinking: { label: "THINKING", color: "#a78bfa" },
  speaking: { label: "SPEAKING", color: "#f472b6" },
};

function LevelBars({ getLevel, active }: { getLevel: () => number; active: boolean }) {
  const bars = useRef<(HTMLSpanElement | null)[]>([]);
  const activeRef = useRef(active);
  useEffect(() => {
    activeRef.current = active;
  });
  useEffect(() => {
    let raf = 0;
    const smooth = new Array(7).fill(0);
    const loop = () => {
      const lv = activeRef.current ? getLevel() : 0;
      const t = performance.now() / 1000;
      bars.current.forEach((el, i) => {
        if (!el) return;
        const wobble = 0.55 + 0.45 * Math.sin(t * (7 + i * 1.7) + i);
        const target = activeRef.current ? Math.max(0.12, lv * wobble * 1.4) : 0.12;
        smooth[i] += (target - smooth[i]) * 0.35;
        el.style.height = `${Math.min(100, 12 + smooth[i] * 88)}%`;
      });
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [getLevel]);
  return (
    <div className="flex h-4 items-center gap-[3px]">
      {Array.from({ length: 7 }).map((_, i) => (
        <span
          key={i}
          ref={(el) => {
            bars.current[i] = el;
          }}
          className="w-[3px] rounded-full bg-current"
          style={{ height: "12%" }}
        />
      ))}
    </div>
  );
}

type Props = {
  mood: Mood;
  status: Status;
  subtitle: string;
  showSubtitles: boolean;
  interim: string;
  getLevel: () => number;
  onPoke: () => void;
};

export default function Stage({ mood, status, subtitle, showSubtitles, interim, getLevel, onPoke }: Props) {
  const meta = STATUS_META[status];
  return (
    <div className="relative h-full w-full overflow-hidden rounded-[inherit]" style={{ ["--accent" as string]: meta.color }}>
      {/* aura */}
      <div
        className="absolute inset-0 transition-[background] duration-700"
        style={{
          background: `radial-gradient(60% 55% at 50% 48%, color-mix(in srgb, ${meta.color} 22%, transparent), transparent 70%)`,
        }}
      />
      {/* HUD rings */}
      <div className="pointer-events-none absolute left-1/2 top-[46%] aspect-square h-[96%] max-w-[120%] -translate-x-1/2 -translate-y-1/2" style={{ color: meta.color }}>
        <svg viewBox="0 0 600 600" className="absolute inset-0 h-full w-full transition-colors duration-700">
          <g className="ring-cw" style={{ transformOrigin: "300px 300px" }}>
            <circle cx="300" cy="300" r="286" fill="none" stroke="currentColor" strokeOpacity="0.35" strokeWidth="1.5" strokeDasharray="2 14" strokeLinecap="round" />
            <path d="M300 14A286 286 0 0 1 586 300" fill="none" stroke="currentColor" strokeOpacity="0.8" strokeWidth="3" strokeLinecap="round" />
            <path d="M300 586A286 286 0 0 1 14 300" fill="none" stroke="currentColor" strokeOpacity="0.8" strokeWidth="3" strokeLinecap="round" />
          </g>
          <g className="ring-ccw" style={{ transformOrigin: "300px 300px" }}>
            <circle cx="300" cy="300" r="254" fill="none" stroke="currentColor" strokeOpacity="0.22" strokeWidth="1" strokeDasharray="40 12 6 12" />
            <path d="M120 120A254 254 0 0 1 200 60" fill="none" stroke="currentColor" strokeOpacity="0.7" strokeWidth="2" strokeLinecap="round" />
            <path d="M480 480A254 254 0 0 1 400 540" fill="none" stroke="currentColor" strokeOpacity="0.7" strokeWidth="2" strokeLinecap="round" />
          </g>
          <circle cx="300" cy="300" r="222" fill="none" stroke="currentColor" strokeOpacity="0.1" strokeWidth="1" />
          {Array.from({ length: 36 }).map((_, i) => {
            const a = (i / 36) * Math.PI * 2;
            const r1 = 296;
            const r2 = i % 3 === 0 ? 306 : 301;
            return (
              <line
                key={i}
                x1={300 + Math.cos(a) * r1}
                y1={300 + Math.sin(a) * r1}
                x2={300 + Math.cos(a) * r2}
                y2={300 + Math.sin(a) * r2}
                stroke="currentColor"
                strokeOpacity="0.45"
                strokeWidth="1.5"
              />
            );
          })}
        </svg>
      </div>

      {/* floating particles */}
      <div className="pointer-events-none absolute inset-0">
        {Array.from({ length: 14 }).map((_, i) => (
          <span
            key={i}
            className="particle"
            style={{
              left: `${(i * 37 + 11) % 100}%`,
              animationDelay: `${(i * 1.3) % 9}s`,
              animationDuration: `${9 + (i % 5) * 2.5}s`,
              width: `${2 + (i % 3)}px`,
              height: `${2 + (i % 3)}px`,
              color: meta.color,
            }}
          />
        ))}
      </div>

      {/* avatar */}
      <div className="absolute inset-x-0 bottom-0 top-[5%] flex items-end justify-center">
        <AdaAvatar mood={mood} status={status} getLevel={getLevel} onPoke={onPoke} className="h-full" />
      </div>

      {/* status chip */}
      <div
        className="absolute left-3 top-3 flex items-center gap-2 rounded-full border px-3 py-1.5 text-[11px] font-semibold tracking-[0.18em] backdrop-blur-md transition-colors duration-500"
        style={{ color: meta.color, borderColor: `color-mix(in srgb, ${meta.color} 40%, transparent)`, background: "rgba(5,10,22,0.55)" }}
      >
        <span className="relative flex h-2 w-2">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full opacity-70" style={{ background: meta.color }} />
          <span className="relative inline-flex h-2 w-2 rounded-full" style={{ background: meta.color }} />
        </span>
        {meta.label}
        <LevelBars getLevel={getLevel} active={status === "speaking"} />
      </div>
      <div className="absolute right-3 top-3 rounded-full border border-white/10 bg-[rgba(5,10,22,0.55)] px-3 py-1.5 text-[11px] tracking-wide text-slate-300 backdrop-blur-md">
        <span className="mr-1">{MOOD_EMOJI[mood]}</span>
        {mood}
      </div>

      {/* subtitles / live transcript */}
      <div className="pointer-events-none absolute inset-x-0 bottom-3 flex flex-col items-center gap-2 px-4">
        {interim && (
          <div className="max-w-[90%] rounded-full border border-emerald-400/30 bg-emerald-950/60 px-4 py-1.5 text-center text-sm italic text-emerald-200 backdrop-blur-md">
            {interim}
          </div>
        )}
        {showSubtitles && subtitle && (
          <p key={subtitle} className="subtitle max-w-[92%] text-center text-[clamp(15px,1.7vw,22px)] font-bold leading-snug text-white">
            {subtitle}
          </p>
        )}
      </div>
    </div>
  );
}
