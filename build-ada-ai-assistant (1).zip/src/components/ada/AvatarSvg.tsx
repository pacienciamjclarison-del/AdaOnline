// Ada's body. A pure SVG driven by a numeric "pose" so the animation loop can
// drive it every frame (and so it can be rendered statically for testing).

export type Pose = {
  headRot: number;
  headX: number;
  headY: number;
  breath: number;
  eyeOpen: number; // 0 closed .. 1 open (1.15 = wide)
  smileEye: number; // 0..1, blends into happy ^ ^ eyes
  gazeX: number; // -1..1
  gazeY: number; // -1..1
  pupil: number; // pupil scale
  browY: number; // negative = raised
  browAngry: number; // positive = inner ends down, negative = inner ends up
  browSkew: number; // raises the viewer-right brow
  mouthOpen: number; // 0..1
  mouthCurve: number; // -1 frown .. 1 big smile
  mouthWidth: number;
  mouthSkew: number; // smirk
  blush: number; // 0..1
  hairSway: number;
  ahoge: number;
  glow: number; // headset glow 0..1
};

export const NEUTRAL_POSE: Pose = {
  headRot: 0,
  headX: 0,
  headY: 0,
  breath: 0.5,
  eyeOpen: 1,
  smileEye: 0,
  gazeX: 0,
  gazeY: 0,
  pupil: 1,
  browY: 0,
  browAngry: 0,
  browSkew: 0,
  mouthOpen: 0,
  mouthCurve: 0.3,
  mouthWidth: 1,
  mouthSkew: 0,
  blush: 0.2,
  hairSway: 0,
  ahoge: 0,
  glow: 0.6,
};

const SKIN = "#f7d6bd";
const SKIN_SHADE = "#e8b794";
const INK = "#1a1233";

function mouthShape(open: number, curve: number, width: number, skew: number) {
  const cx = 200;
  const cy = 316;
  const w = 17 * width;
  const lx = cx - w;
  const rx = cx + w;
  const base = cy - curve * 6;
  const ly = base + skew * 1.5;
  const ry = base - skew * 5;
  const avg = (ly + ry) / 2;
  if (open < 0.045) {
    return { closed: `M${lx} ${ly} Q${cx} ${cy + 3 + curve * 7} ${rx} ${ry}`, open: null, h: 0, avg, w, lx, rx };
  }
  const h = 2 + open * 26;
  const d = `M${lx} ${ly} Q${cx} ${avg - 2} ${rx} ${ry} Q${cx} ${avg + h * 2 + curve * 3} ${lx} ${ly} Z`;
  return { closed: null, open: d, h, avg, w, lx, rx };
}

function Eye({ cx, cy, flip, pose }: { cx: number; cy: number; flip: boolean; pose: Pose }) {
  const id = flip ? "R" : "L";
  const top = cy - 27;
  const s = Math.max(0.06, pose.eyeOpen);
  const dx = pose.gazeX * 7;
  const dy = pose.gazeY * 5 + (pose.eyeOpen > 1 ? -1 : 0);
  const outer = flip ? 1 : -1;
  const lidPath = `M${cx - 24} ${cy - 2} C${cx - 22} ${cy - 30} ${cx + 22} ${cy - 30} ${cx + 24} ${cy - 2}`;
  const archPath = `M${cx - 22} ${cy + 8} Q${cx} ${cy - 22} ${cx + 22} ${cy + 8}`;
  return (
    <g>
      <g opacity={Math.max(0, 1 - pose.smileEye * 1.2)} transform={`translate(0 ${top}) scale(1 ${s}) translate(0 ${-top})`}>
        <clipPath id={`eyeClip${id}`}>
          <ellipse cx={cx} cy={cy} rx={22} ry={26} />
        </clipPath>
        <ellipse cx={cx} cy={cy} rx={22} ry={26} fill="#f3f8ff" />
        <g clipPath={`url(#eyeClip${id})`}>
          <g transform={`translate(${dx} ${dy})`}>
            <ellipse cx={cx} cy={cy + 1} rx={19.5} ry={23} fill="url(#irisGrad)" />
            <ellipse cx={cx} cy={cy + 1} rx={19.5} ry={23} fill="none" stroke="#0a3a5c" strokeWidth={2} opacity={0.7} />
            <ellipse cx={cx} cy={cy + 2} rx={8.5 * pose.pupil} ry={12 * pose.pupil} fill="#07102a" />
            <ellipse cx={cx} cy={cy + 14} rx={11} ry={6} fill="#b6fbff" opacity={0.55} />
            <circle cx={cx - 7} cy={cy - 9} r={6.5} fill="#fff" />
            <circle cx={cx + 8} cy={cy + 10} r={3} fill="#fff" opacity={0.9} />
          </g>
          <ellipse cx={cx} cy={cy - 20} rx={26} ry={12} fill="#1a1233" opacity={0.28} />
        </g>
        <path d={lidPath} fill="none" stroke={INK} strokeWidth={5.5} strokeLinecap="round" />
        <path
          d={`M${cx + outer * 23} ${cy - 4} Q${cx + outer * 29} ${cy - 8} ${cx + outer * 32} ${cy - 15}`}
          fill="none"
          stroke={INK}
          strokeWidth={4}
          strokeLinecap="round"
        />
        <path
          d={`M${cx - 14} ${cy - 23} Q${cx - 18} ${cy - 29} ${cx - 22} ${cy - 30}`}
          fill="none"
          stroke={INK}
          strokeWidth={0}
        />
      </g>
      <path
        d={archPath}
        fill="none"
        stroke={INK}
        strokeWidth={5.5}
        strokeLinecap="round"
        opacity={Math.min(1, pose.smileEye * 1.2)}
      />
    </g>
  );
}

export default function AvatarSvg({ pose, className }: { pose: Pose; className?: string }) {
  const m = mouthShape(pose.mouthOpen, pose.mouthCurve, pose.mouthWidth, pose.mouthSkew);
  const bodyY = pose.breath * 3.5;
  const glow = 0.45 + pose.glow * 0.55;

  return (
    <svg viewBox="0 0 400 520" className={className} role="img" aria-label="Ada, the AI assistant">
      <defs>
        <linearGradient id="hairBack" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#14112b" />
          <stop offset="0.55" stopColor="#1c1840" />
          <stop offset="0.82" stopColor="#173a63" />
          <stop offset="1" stopColor="#14a9c9" />
        </linearGradient>
        <linearGradient id="hairFront" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#2c2660" />
          <stop offset="1" stopColor="#171335" />
        </linearGradient>
        <linearGradient id="hairLock" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#1f1b46" />
          <stop offset="0.6" stopColor="#1a2f5e" />
          <stop offset="1" stopColor="#22c7e6" />
        </linearGradient>
        <linearGradient id="irisGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#0b3d78" />
          <stop offset="0.5" stopColor="#14a3d6" />
          <stop offset="1" stopColor="#8ff6ff" />
        </linearGradient>
        <radialGradient id="skinGrad" cx="0.5" cy="0.42" r="0.65">
          <stop offset="0" stopColor="#fde4cf" />
          <stop offset="1" stopColor={SKIN} />
        </radialGradient>
        <linearGradient id="jacket" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#242e55" />
          <stop offset="1" stopColor="#0f1428" />
        </linearGradient>
        <radialGradient id="blushGrad">
          <stop offset="0" stopColor="#ff6f91" stopOpacity="0.85" />
          <stop offset="1" stopColor="#ff6f91" stopOpacity="0" />
        </radialGradient>
        <filter id="softGlow" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="3" />
        </filter>
        <filter id="blur2" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="1.6" />
        </filter>
        <clipPath id="faceClip">
          <path d="M118 218C116 150 150 104 200 104C250 104 284 150 282 218C281 282 258 336 226 356C212 365 188 365 174 356C142 336 119 282 118 218Z" />
        </clipPath>
        <clipPath id="neckClip">
          <path d="M181 340L181 398C181 414 219 414 219 398L219 340Z" />
        </clipPath>
        {m.open && (
          <clipPath id="mouthClip">
            <path d={m.open} />
          </clipPath>
        )}
      </defs>

      {/* ---------- back hair ---------- */}
      <g transform={`rotate(${pose.hairSway} 200 110)`}>
        <path
          d="M200 36C122 36 76 98 74 190C72 262 60 330 66 410C70 470 98 504 134 512L266 512C302 504 330 470 334 410C340 330 328 262 326 190C324 98 278 36 200 36Z"
          fill="url(#hairBack)"
        />
        <path d="M96 200C90 270 84 340 92 420" stroke="#4b45a0" strokeWidth={3} fill="none" opacity={0.35} strokeLinecap="round" />
        <path d="M304 200C310 270 316 340 308 420" stroke="#4b45a0" strokeWidth={3} fill="none" opacity={0.35} strokeLinecap="round" />
      </g>

      {/* ---------- body ---------- */}
      <g transform={`translate(0 ${bodyY})`}>
        <path d="M181 340L181 398C181 414 219 414 219 398L219 340Z" fill={SKIN_SHADE} />
        <g clipPath="url(#neckClip)">
          <ellipse cx={200} cy={364} rx={40} ry={20} fill="#b9714f" opacity={0.38} />
        </g>
        <g transform="translate(0 -32)">
        <path
          d="M56 560C56 468 92 440 150 428C172 438 228 438 250 428C308 440 344 468 344 560Z"
          fill="url(#jacket)"
        />
        {/* inner shirt */}
        <path d="M166 430C180 448 220 448 234 430L216 500L184 500Z" fill="#e9f7ff" />
        <path d="M184 440C196 450 204 450 216 440" stroke="#b7d6e8" strokeWidth={2} fill="none" />
        {/* lapels */}
        <path d="M150 428C160 452 178 482 198 504L168 560L104 560C104 482 126 448 150 428Z" fill="#2a3562" />
        <path d="M250 428C240 452 222 482 202 504L232 560L296 560C296 482 274 448 250 428Z" fill="#2a3562" />
        <path d="M150 428C160 452 178 482 198 504" stroke="#22d3ee" strokeWidth={2.5} fill="none" opacity={glow} />
        <path d="M250 428C240 452 222 482 202 504" stroke="#22d3ee" strokeWidth={2.5} fill="none" opacity={glow} />
        {/* shoulder tech lines */}
        <path d="M84 484L128 468" stroke="#22d3ee" strokeWidth={2} opacity={glow * 0.8} strokeLinecap="round" />
        <path d="M316 484L272 468" stroke="#22d3ee" strokeWidth={2} opacity={glow * 0.8} strokeLinecap="round" />
        <circle cx={92} cy={494} r={3} fill="#22d3ee" opacity={glow} />
        <circle cx={308} cy={494} r={3} fill="#22d3ee" opacity={glow} />
        </g>
      </g>

      {/* ---------- head ---------- */}
      <g transform={`translate(${pose.headX} ${pose.headY + bodyY * 0.6}) rotate(${pose.headRot} 200 392)`}>
        {/* face */}
        <path
          d="M118 218C116 150 150 104 200 104C250 104 284 150 282 218C281 282 258 336 226 356C212 365 188 365 174 356C142 336 119 282 118 218Z"
          fill="url(#skinGrad)"
        />
        {/* soft jaw shade + hair shadow on forehead */}
        <g clipPath="url(#faceClip)">
          <ellipse cx={200} cy={150} rx={96} ry={44} fill="#8a5a6a" opacity={0.2} />
          <path d="M118 270C140 350 260 350 282 270L282 380L118 380Z" fill="#e7a98a" opacity={0.18} />
        </g>

        {/* blush */}
        <ellipse cx={138} cy={286} rx={26} ry={12} fill="url(#blushGrad)" opacity={pose.blush} />
        <ellipse cx={262} cy={286} rx={26} ry={12} fill="url(#blushGrad)" opacity={pose.blush} />
        <g stroke="#ff5c85" strokeWidth={2} strokeLinecap="round" opacity={Math.max(0, pose.blush - 0.55) * 2}>
          <path d="M126 282l6 -8M136 284l6 -8M146 284l6 -8" />
          <path d="M254 284l6 -8M264 284l6 -8M274 282l6 -8" />
        </g>

        {/* eyes */}
        <Eye cx={160} cy={240} flip={false} pose={pose} />
        <Eye cx={240} cy={240} flip pose={pose} />

        {/* nose */}
        <path d="M197 278Q200 282 204 278" stroke="#c98563" strokeWidth={2.2} fill="none" strokeLinecap="round" opacity={0.8} />

        {/* mouth */}
        {m.closed && (
          <path d={m.closed} fill="none" stroke="#a04757" strokeWidth={3.4} strokeLinecap="round" />
        )}
        {m.open && (
          <g>
            <path d={m.open} fill="#6e1c33" />
            <g clipPath="url(#mouthClip)">
              <rect x={m.lx + 2} y={m.avg - 3} width={m.w * 2 - 4} height={Math.min(7, 2 + m.h * 0.3)} rx={2} fill="#fff" />
              <ellipse cx={200} cy={m.avg + m.h * 1.05} rx={m.w * 0.55} ry={Math.max(2, m.h * 0.42)} fill="#ff7a96" />
            </g>
            <path d={m.open} fill="none" stroke="#a04757" strokeWidth={2.6} strokeLinejoin="round" />
          </g>
        )}

        {/* ---- earcups (behind hair locks) ---- */}
        <g>
          <rect x={80} y={196} width={38} height={76} rx={18} fill="#232b4a" />
          <rect x={84} y={202} width={30} height={64} rx={14} fill="#313b66" />
          <ellipse cx={99} cy={234} rx={8} ry={22} fill="none" stroke="#22d3ee" strokeWidth={3} opacity={glow} />
          <ellipse cx={99} cy={234} rx={8} ry={22} fill="none" stroke="#22d3ee" strokeWidth={6} opacity={glow * 0.4} filter="url(#softGlow)" />
          <rect x={282} y={196} width={38} height={76} rx={18} fill="#232b4a" />
          <rect x={286} y={202} width={30} height={64} rx={14} fill="#313b66" />
          <ellipse cx={301} cy={234} rx={8} ry={22} fill="none" stroke="#22d3ee" strokeWidth={3} opacity={glow} />
          <ellipse cx={301} cy={234} rx={8} ry={22} fill="none" stroke="#22d3ee" strokeWidth={6} opacity={glow * 0.4} filter="url(#softGlow)" />
        </g>

        {/* ---- front hair: crown ---- */}
        <path
          d="M114 190C100 100 148 48 200 46C252 48 300 100 286 190C268 128 236 98 200 98C164 98 132 128 114 190Z"
          fill="url(#hairFront)"
        />
        {/* ahoge */}
        <g transform={`rotate(${pose.ahoge} 204 60)`}>
          <path d="M198 66C176 28 210 6 238 20C218 20 208 38 212 66Z" fill="#241f50" />
          <path d="M204 56C196 36 208 22 226 22" stroke="#4d46a8" strokeWidth={2} fill="none" opacity={0.6} strokeLinecap="round" />
        </g>
        {/* bangs */}
        <path
          d="M200 92C168 94 128 108 114 158C108 188 110 214 118 236C126 210 138 188 150 172C158 192 178 196 190 166C195 148 199 122 200 92Z"
          fill="url(#hairFront)"
        />
        <path
          d="M200 92C232 94 272 108 286 158C292 188 290 214 282 236C274 210 262 188 250 172C242 192 222 196 210 166C205 148 201 122 200 92Z"
          fill="url(#hairFront)"
        />
        {/* bang highlights */}
        <path d="M150 128C160 112 178 104 194 102" stroke="#6a62c8" strokeWidth={3} fill="none" opacity={0.45} strokeLinecap="round" />
        <path d="M250 128C240 112 222 104 206 102" stroke="#6a62c8" strokeWidth={3} fill="none" opacity={0.45} strokeLinecap="round" />
        <path d="M128 180C132 164 138 152 146 144" stroke="#6a62c8" strokeWidth={2.5} fill="none" opacity={0.35} strokeLinecap="round" />
        <path d="M272 180C268 164 262 152 254 144" stroke="#6a62c8" strokeWidth={2.5} fill="none" opacity={0.35} strokeLinecap="round" />
        {/* crown shine */}
        <path d="M138 92C166 66 234 66 262 92" stroke="#8d86ee" strokeWidth={6} fill="none" opacity={0.35} strokeLinecap="round" filter="url(#blur2)" />

        {/* ---- brows (on top so they stay readable) ---- */}
        <g transform={`translate(160 ${198 + pose.browY - pose.browSkew * 0}) rotate(${pose.browAngry})`}>
          <path d="M-19 3Q0 -6 19 1" stroke="#2a2250" strokeWidth={4.2} fill="none" strokeLinecap="round" />
        </g>
        <g transform={`translate(240 ${198 + pose.browY - pose.browSkew * 4}) rotate(${-pose.browAngry - pose.browSkew * 3})`}>
          <path d="M-19 1Q0 -6 19 3" stroke="#2a2250" strokeWidth={4.2} fill="none" strokeLinecap="round" />
        </g>

        {/* ---- side locks (in front of shoulders) ---- */}
        <path
          d="M116 168C98 232 98 300 86 382C78 432 86 482 110 504C126 472 134 404 130 334C128 284 126 224 116 168Z"
          fill="url(#hairLock)"
        />
        <path
          d="M284 168C302 232 302 300 314 382C322 432 314 482 290 504C274 472 266 404 270 334C272 284 274 224 284 168Z"
          fill="url(#hairLock)"
        />
        <path d="M108 230C104 300 100 360 96 420" stroke="#6a62c8" strokeWidth={2.5} fill="none" opacity={0.3} strokeLinecap="round" />
        <path d="M292 230C296 300 300 360 304 420" stroke="#6a62c8" strokeWidth={2.5} fill="none" opacity={0.3} strokeLinecap="round" />

        {/* ---- headband ---- */}
        <path
          d="M92 214C80 112 138 30 200 30C262 30 320 112 308 214"
          fill="none"
          stroke="#232b4a"
          strokeWidth={11}
          strokeLinecap="round"
        />
        <path
          d="M92 214C80 112 138 30 200 30C262 30 320 112 308 214"
          fill="none"
          stroke="#22d3ee"
          strokeWidth={2.2}
          opacity={glow}
          strokeLinecap="round"
        />
        <path
          d="M92 214C80 112 138 30 200 30C262 30 320 112 308 214"
          fill="none"
          stroke="#22d3ee"
          strokeWidth={6}
          opacity={glow * 0.35}
          strokeLinecap="round"
          filter="url(#softGlow)"
        />

        {/* hex hair clip */}
        <g transform="translate(138 138) rotate(-14)">
          <polygon points="0,-13 11.3,-6.5 11.3,6.5 0,13 -11.3,6.5 -11.3,-6.5" fill="#0f1830" stroke="#22d3ee" strokeWidth={2} />
          <polygon points="0,-13 11.3,-6.5 11.3,6.5 0,13 -11.3,6.5 -11.3,-6.5" fill="#22d3ee" opacity={glow * 0.35} filter="url(#softGlow)" />
          <path d="M-5 5L0 -6L5 5M-3 1.5H3" stroke="#aef5ff" strokeWidth={2} fill="none" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </g>
    </svg>
  );
}
