import AdaApp from "@/components/ada/AdaApp";

export default function HomePage() {
  return <AdaApp />;
}
