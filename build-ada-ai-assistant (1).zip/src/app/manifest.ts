import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Ada — Personal AI Assistant",
    short_name: "Ada",
    description: "Your personal Jarvis-style AI companion with animated avatar, voice, timers, tasks, weather, and live news.",
    start_url: "/",
    display: "standalone",
    share_target: {
      action: "/",
      method: "GET",
      enctype: "application/x-www-form-urlencoded",
      params: {
        title: "share_title",
        text: "share_text",
        url: "share_url",
      },
    },
    background_color: "#070b16",
    theme_color: "#070b16",
    orientation: "any",
    categories: ["productivity", "utilities", "entertainment"],
    icons: [
      {
        src: "/icons/icon.svg",
        sizes: "any",
        type: "image/svg+xml",
        purpose: "any",
      },
      {
        src: "/icons/icon.svg",
        sizes: "any",
        type: "image/svg+xml",
        purpose: "maskable",
      },
    ],
  };
}
