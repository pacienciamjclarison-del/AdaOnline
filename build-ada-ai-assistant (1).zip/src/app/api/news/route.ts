import { fetchLiveNews, type NewsCategory } from "@/lib/server/news";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const q = url.searchParams.get("q") ?? undefined;
  const category = (url.searchParams.get("category") || "top") as NewsCategory;
  const limit = Number(url.searchParams.get("limit") || 5);
  const country = url.searchParams.get("country") ?? undefined;

  const articles = await fetchLiveNews({
    query: q,
    category,
    limit,
    country,
  });

  return Response.json({
    articles,
    updatedAt: new Date().toISOString(),
  });
}
