import { llmChain } from "@/lib/server/llm";
import { EDGE_VOICES, ttsProvider } from "@/lib/server/tts";

export const dynamic = "force-dynamic";

export async function GET() {
  const chain = llmChain();
  const primary = chain[0];
  return Response.json({
    brain: primary ? primary.id : "local",
    model: primary ? primary.label : "offline",
    free: primary?.id === "free",
    tts: ttsProvider(),
    edgeVoices: EDGE_VOICES,
  });
}
