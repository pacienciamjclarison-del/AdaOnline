import { EDGE_VOICES, edgeSynth, elevenSynth, looksMalay, openaiSynth, ttsProvider } from "@/lib/server/tts";

export const dynamic = "force-dynamic";
export const maxDuration = 30;

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const text = typeof body.text === "string" ? body.text.trim().slice(0, 700) : "";
  if (!text) return Response.json({ error: "no text" }, { status: 400 });

  const provider = ttsProvider();
  try {
    let audio: Buffer;
    if (provider === "elevenlabs") {
      audio = await elevenSynth(text);
    } else if (provider === "openai") {
      audio = await openaiSynth(text);
    } else {
      const requested = typeof body.voice === "string" ? body.voice : "";
      let voice = EDGE_VOICES.find((v) => v.id === requested)?.id ?? "en-US-AriaNeural";
      if (looksMalay(text)) voice = "ms-MY-YasminNeural";
      audio = await edgeSynth(text, voice);
    }
    return new Response(new Uint8Array(audio), {
      headers: { "Content-Type": "audio/mpeg", "Cache-Control": "no-store" },
    });
  } catch (err) {
    console.error("[tts] failed:", err instanceof Error ? err.message : err);
    return Response.json({ error: "tts failed" }, { status: 502 });
  }
}
