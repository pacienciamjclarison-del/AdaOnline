import { getWeather } from "@/lib/server/weather";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const city = new URL(req.url).searchParams.get("city") ?? "";
  const weather = await getWeather(city || "Kuala Lumpur");
  if (!weather) return Response.json({ error: "not found" }, { status: 404 });
  return Response.json(weather);
}
