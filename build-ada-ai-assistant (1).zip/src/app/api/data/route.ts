import * as store from "@/lib/server/store";

export const dynamic = "force-dynamic";

const KINDS = ["tasks", "notes", "memories", "messages"] as const;
type Kind = (typeof KINDS)[number];

const isKind = (v: unknown): v is Kind => typeof v === "string" && (KINDS as readonly string[]).includes(v);

async function list(uid: string, kind: Kind) {
  switch (kind) {
    case "tasks":
      return store.listTasks(uid);
    case "notes":
      return store.listNotes(uid);
    case "memories":
      return store.listMemories(uid);
    case "messages":
      return store.recentMessages(uid, 60);
  }
}

export async function GET(req: Request) {
  const uid = store.getUid(req);
  const kind = new URL(req.url).searchParams.get("kind");
  if (!isKind(kind)) return Response.json({ error: "bad kind" }, { status: 400 });
  return Response.json({ items: await list(uid, kind) });
}

export async function POST(req: Request) {
  const uid = store.getUid(req);
  const body = await req.json().catch(() => ({}));
  const text = typeof body.text === "string" ? body.text.trim() : "";
  if (!isKind(body.kind) || !text) return Response.json({ error: "bad request" }, { status: 400 });
  switch (body.kind) {
    case "tasks":
      await store.addTask(uid, text);
      break;
    case "notes":
      await store.addNote(uid, text);
      break;
    case "memories":
      await store.addMemory(uid, text);
      break;
    default:
      return Response.json({ error: "not supported" }, { status: 400 });
  }
  return Response.json({ items: await list(uid, body.kind) });
}

export async function PATCH(req: Request) {
  const uid = store.getUid(req);
  const body = await req.json().catch(() => ({}));
  if (body.kind !== "tasks" || typeof body.id !== "number") return Response.json({ error: "bad request" }, { status: 400 });
  await store.setTaskDone(uid, body.id, Boolean(body.done));
  return Response.json({ items: await store.listTasks(uid) });
}

export async function DELETE(req: Request) {
  const uid = store.getUid(req);
  const params = new URL(req.url).searchParams;
  const kind = params.get("kind");
  const idRaw = params.get("id");
  if (!isKind(kind)) return Response.json({ error: "bad kind" }, { status: 400 });
  const id = idRaw ? Number(idRaw) : null;
  if (idRaw && (id === null || !Number.isInteger(id))) return Response.json({ error: "bad id" }, { status: 400 });

  if (id !== null) {
    if (kind === "tasks") await store.deleteTask(uid, id);
    else if (kind === "notes") await store.deleteNote(uid, id);
    else if (kind === "memories") await store.deleteMemory(uid, id);
    else return Response.json({ error: "not supported" }, { status: 400 });
  } else if (kind === "messages") {
    await store.clearMessages(uid);
  } else if (kind === "tasks") {
    await store.clearDoneTasks(uid);
  } else if (kind === "memories") {
    await store.clearMemories(uid);
  } else {
    return Response.json({ error: "id required" }, { status: 400 });
  }
  return Response.json({ items: await list(uid, kind) });
}
