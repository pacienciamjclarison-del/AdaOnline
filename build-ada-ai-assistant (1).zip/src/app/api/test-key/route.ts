import { explainProviderError, llmChain, streamChat, type ClientLlmConfig, type LlmConfig } from "@/lib/server/llm";

export const dynamic = "force-dynamic";
export const maxDuration = 35;

export async function POST(req: Request) {
  let target: LlmConfig | undefined;
  try {
    const body: { clientLlm?: ClientLlmConfig } = await req.json().catch(() => ({}));
    const cfg = body.clientLlm;
    if (!cfg) return Response.json({ ok: false, error: "Choose a provider first." }, { status: 400 });

    const provider = (cfg.provider || "groq").toLowerCase();
    if (provider !== "ollama" && !cfg.apiKey?.trim()) {
      return Response.json({ ok: false, error: "Paste the API key for this provider first." }, { status: 400 });
    }
    if ((cfg.apiKey?.length ?? 0) > 1000 || (cfg.model?.length ?? 0) > 200 || (cfg.baseUrl?.length ?? 0) > 500) {
      return Response.json({ ok: false, error: "The key, model or endpoint is too long. Check the value and try again." }, { status: 400 });
    }

    target = llmChain(cfg)[0];
    if (!target) return Response.json({ ok: false, error: "Could not configure that provider. Re-select it in Settings." }, { status: 400 });

    const startedAt = Date.now();
    const abort = new AbortController();
    const timer = setTimeout(() => abort.abort(), 32000);
    let text = "";
    try {
      for await (const chunk of streamChat(
        target,
        [
          { role: "system", content: "Reply with exactly: OK" },
          { role: "user", content: "Reply OK." },
        ],
        abort.signal,
      )) {
        text += chunk;
        if (text.trim().length >= 16) break;
      }
    } finally {
      clearTimeout(timer);
    }

    if (!text.trim()) {
      return Response.json({
        ok: false,
        error: `${target.label} connected but returned no text. Try another model from this provider.`,
      }, { status: 502 });
    }

    return Response.json({
      ok: true,
      provider: target.id,
      model: target.model,
      latency: Date.now() - startedAt,
      sample: text.trim().slice(0, 60),
    });
  } catch (err) {
    const message = explainProviderError(err, target);
    const status = err && typeof err === "object" && "status" in err && typeof err.status === "number" ? err.status : 502;
    return Response.json({ ok: false, error: message }, { status: status >= 400 && status < 600 ? status : 502 });
  }
}
