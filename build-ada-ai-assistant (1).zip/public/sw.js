// Simple service worker for PWA installation and cache support
const CACHE_NAME = "ada-v1";

self.addEventListener("install", (event) => {
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener("fetch", (event) => {
  // Pass-through for dynamic Next.js App Router and APIs
  event.respondWith(fetch(event.request).catch(() => caches.match(event.request)));
});
